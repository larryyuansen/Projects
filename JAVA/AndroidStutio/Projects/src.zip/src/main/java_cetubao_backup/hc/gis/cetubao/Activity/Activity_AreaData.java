package hc.gis.cetubao.Activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.Bean.AreaData;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;
import hc.gis.cetubao.widget.MaxNumEt;
import hc.gis.cetubao.widget.TimePickerDialog;

/**
 * 填写采集表页面
 * //添加注释 2018年4月8日17:59:59
 */
@ContentView(R.layout.activity_area_data)
public class Activity_AreaData extends MBaseActivity
{
    AreaData areaData;
    //    @ViewInject(R.id.tab_data_type)
    TabLayout tab_data_type;
    @ViewInject(R.id.tv_title)
    TextView tv_title;
    @ViewInject(R.id.et_traceNumber)
    EditText et_tybh;
    @ViewInject(R.id.et_dczh)
    EditText et_dczh;
    @ViewInject(R.id.et_cyxh)
    EditText et_cyxh;
    @ViewInject(R.id.et_cymd)
    EditText et_cymd;
    @ViewInject(R.id.tv_cyrq)
    TextView tv_cyrq;
    @ViewInject(R.id.tv_sccyrq)
    TextView tv_sccyrq;
    @ViewInject(R.id.et_sheng)
    EditText et_sheng;
    @ViewInject(R.id.et_shi)
    EditText et_shi;
    @ViewInject(R.id.et_xian)
    EditText et_xian;
    @ViewInject(R.id.et_xiang)
    EditText et_xiang;
    @ViewInject(R.id.et_cun)
    EditText et_cun;
    @ViewInject(R.id.et_zipcode)
    EditText et_zipcode;
    @ViewInject(R.id.et_farmname)
    EditText et_farmname;
    @ViewInject(R.id.et_areaname)
    EditText et_areaname;
    @ViewInject(R.id.et_phone)
    EditText et_phone;
    @ViewInject(R.id.et_location)
    EditText et_location;
    @ViewInject(R.id.et_lng)
    EditText et_lng;
    @ViewInject(R.id.et_lat)
    EditText et_lat;
    @ViewInject(R.id.et_distant)
    EditText et_distant;
    @ViewInject(R.id.et_height)
    EditText et_height;
    @ViewInject(R.id.scv_data_location)
    ScrollView scv_data_location;
    @ViewInject(R.id.et_dmlx)
    EditText et_dmlx;
    @ViewInject(R.id.et_dxbw)
    EditText et_dxbw;
    @ViewInject(R.id.et_dmpx)
    EditText et_dmpx;
    @ViewInject(R.id.et_tmpx)
    EditText et_tmpx;
    @ViewInject(R.id.et_px)
    EditText et_px;
    @ViewInject(R.id.et_tcdxsw)
    EditText et_tcdxsw;
    @ViewInject(R.id.et_zgdxsw)
    EditText et_zgdxsw;
    @ViewInject(R.id.et_zsdxsw)
    EditText et_zsdxsw;
    @ViewInject(R.id.et_cnjyl)
    EditText et_cnjyl;
    @ViewInject(R.id.et_cnyxjw)
    EditText et_cnyxjw;
    @ViewInject(R.id.et_cnwsq)
    MaxNumEt et_cnwsq;
    @ViewInject(R.id.scv_data_natural)
    ScrollView scv_data_natural;
    @ViewInject(R.id.et_ntjcss)
    EditText et_ntjcss;
    @ViewInject(R.id.et_psnl)
    EditText et_psnl;
    @ViewInject(R.id.et_ggnl)
    EditText et_ggnl;
    @ViewInject(R.id.et_sytj)
    EditText et_sytj;
    @ViewInject(R.id.et_ssfs)
    EditText et_ssfs;
    @ViewInject(R.id.et_ggfs)
    EditText et_ggfs;
    @ViewInject(R.id.et_sz)
    EditText et_sz;
    @ViewInject(R.id.et_dxzzzd)
    EditText et_dxzzzd;
    @ViewInject(R.id.et_cncnsp)
    EditText et_cncnsp;
    @ViewInject(R.id.scv_data_work)
    ScrollView scv_data_work;
    @ViewInject(R.id.et_tl)
    EditText et_tl;
    @ViewInject(R.id.et_yl)
    EditText et_yl;
    @ViewInject(R.id.et_ts)
    EditText et_ts;
    @ViewInject(R.id.et_tz)
    EditText et_tz;
    @ViewInject(R.id.et_sm)
    EditText et_sm;
    @ViewInject(R.id.et_cztm)
    EditText et_cztm;
    @ViewInject(R.id.et_pmjg)
    EditText et_pmjg;
    @ViewInject(R.id.et_trzd)
    EditText et_trzd;
    @ViewInject(R.id.et_trjg)
    EditText et_trjg;
    @ViewInject(R.id.et_zays)
    EditText et_zays;
    @ViewInject(R.id.et_qscd)
    EditText et_qscd;
    @ViewInject(R.id.et_gcmj)
    EditText et_gcmj;
    @ViewInject(R.id.et_cysd)
    EditText et_cysd;
    @ViewInject(R.id.et_tkmj)
    EditText et_tkmj;
    @ViewInject(R.id.et_dbmj)
    EditText et_dbmj;
    @ViewInject(R.id.scv_data_soil)
    ScrollView scv_data_soil;
    @ViewInject(R.id.et_zwmc1)
    EditText et_zwmc1;
    @ViewInject(R.id.et_pzmc1)
    EditText et_pzmc1;
    @ViewInject(R.id.et_dwcl1)
    EditText et_dwcl1;
    @ViewInject(R.id.et_zwmc2)
    EditText et_zwmc2;
    @ViewInject(R.id.et_pzmc2)
    EditText et_pzmc2;
    @ViewInject(R.id.et_dwcl2)
    EditText et_dwcl2;
    @ViewInject(R.id.et_zwmc3)
    EditText et_zwmc3;
    @ViewInject(R.id.et_pzmc3)
    EditText et_pzmc3;
    @ViewInject(R.id.et_dwcl3)
    EditText et_dwcl3;
    @ViewInject(R.id.et_zwmc4)
    EditText et_zwmc4;
    @ViewInject(R.id.et_pzmc4)
    EditText et_pzmc4;
    @ViewInject(R.id.et_dwcl4)
    EditText et_dwcl4;
    @ViewInject(R.id.et_zwmc5)
    EditText et_zwmc5;
    @ViewInject(R.id.et_pzmc5)
    EditText et_pzmc5;
    @ViewInject(R.id.et_dwcl5)
    EditText et_dwcl5;
    @ViewInject(R.id.scv_data_next_year)
    ScrollView scv_data_next_year;
    @ViewInject(R.id.et_dwmc)
    EditText et_dwmc;
    @ViewInject(R.id.et_lxr)
    EditText et_lxr;
    @ViewInject(R.id.et_yb)
    EditText et_yb;
    @ViewInject(R.id.et_dz)
    EditText et_dz;
    @ViewInject(R.id.et_dh)
    EditText et_dh;
    @ViewInject(R.id.et_cz)
    EditText et_cz;
    @ViewInject(R.id.et_cydcr)
    EditText et_cydcr;
    @ViewInject(R.id.et_email)
    EditText et_email;
    @ViewInject(R.id.scv_data_dept)
    ScrollView scv_data_dept;
    @ViewInject(R.id.sv_all)
    ScrollView sv_all;
    String year, cydNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        year = getIntent().getStringExtra("year");
        cydNumber = getIntent().getStringExtra("cydNumber");
        tab_data_type = findViewById(R.id.tab_data_type);
        et_cnwsq.setRegion(365, 0);
        et_cnwsq.setTextWatcher();
        initTab();
        initData();

    }

    private void initData()
    {
        //et_tybh.setText(cydNumber);
        // tv_title.setText(tv_title.getText() + year + "年");

        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("action", "GetDkdcb");
        params.addBodyParameter("dkbh", cydNumber);
        x.http().get(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    try
                    {
                        areaData = JSON.parseObject(mResult.getResult().replace("[", "").replace("]", ""), AreaData.class);
                        initAreaData();
                    } catch (Exception e)
                    {
                        initAreaData();
                        e.toString();
                    }

                }
            }


            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                initAreaData();
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });


    }

    private void initAreaData()
    {
        AreaData areaData_Local = DBUtils.getSingleObj(AreaData.class, WhereBuilder.b("dk_bh", "=", cydNumber), "creatorDate", true);
        if (null == areaData && areaData_Local == null)
        {
            areaData = new AreaData();
            Toast.makeText(this, "无上一次数据,重新填写", Toast.LENGTH_LONG).show();
        } else if (null == areaData && null != areaData_Local)
            areaData = areaData_Local;
        else if (null != areaData_Local && null != areaData)
        {
            try
            {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date_local = sdf.parse(areaData_Local.getCreatorDate());
                Date date_net = sdf.parse(areaData.getCreatorDate());
                if (date_net.before(date_local))
                {
                    areaData = areaData_Local;
                }
            } catch (ParseException e)
            {
                e.printStackTrace();
            }

        }
        if (areaData != null)
        {
            tv_sccyrq.setText(areaData.getDk_cyrq());
            tv_cyrq.setText(Utils.getDate(true));
            et_tybh.setText(areaData.getDk_traceNumber());
            et_dczh.setText(areaData.getDk_dczh());
            et_cyxh.setText(areaData.getDk_cyxh());
            et_cymd.setText(areaData.getDk_cymd());
            et_sheng.setText(areaData.getDk_provice());
            et_shi.setText(areaData.getDk_city());
            et_xian.setText(areaData.getDk_county());
            et_xiang.setText(areaData.getDk_town());
            et_cun.setText(areaData.getDk_village());
            et_zipcode.setText(areaData.getDk_yzbm());
            et_farmname.setText(areaData.getDk_nh());
            et_areaname.setText(areaData.getDk_name());
            et_phone.setText(areaData.getDk_nhphone());
            et_location.setText(areaData.getDk_loction());
            et_lng.setText(areaData.getDk_lon());
            et_lat.setText(areaData.getDk_lat());
            et_distant.setText(areaData.getDk_distance());
            et_height.setText(areaData.getDk_hbgd());
            et_dmlx.setText(areaData.getDk_dmlx());
            et_dxbw.setText(areaData.getDk_dxbw());
            et_dmpx.setText(areaData.getDk_dmpd());
            et_tmpx.setText(areaData.getDk_tmpd());
            et_px.setText(areaData.getDk_px());
            et_tcdxsw.setText(areaData.getDk_tcdxsw());
            et_zgdxsw.setText(areaData.getDk_zgdxsw());
            et_zsdxsw.setText(areaData.getDk_zsdxsw());
            et_cnjyl.setText(areaData.getDk_cnjyl());
            et_cnyxjw.setText(areaData.getDk_cnyxjw());
            et_cnwsq.setText(areaData.getDk_cnwsq());
            et_ntjcss.setText(areaData.getDk_ntjcss());
            et_psnl.setText(areaData.getDk_psnl());
            et_ggnl.setText(areaData.getDk_ggnl());
            et_sytj.setText(areaData.getDk_sytj());
            et_ssfs.setText(areaData.getDk_ssfs());
            et_ggfs.setText(areaData.getDk_ggfs());
            et_sz.setText(areaData.getDk_sz());
            et_dxzzzd.setText(areaData.getDk_dxzzzd());
            et_cncnsp.setText(areaData.getDk_cnclsp());
            et_tl.setText(areaData.getDk_tl());
            et_yl.setText(areaData.getDk_yl());
            et_ts.setText(areaData.getDk_ts());
            et_tz.setText(areaData.getDk_tz());
            et_sm.setText(areaData.getDk_sm());
            et_cztm.setText(areaData.getDk_ctmz());
            et_pmjg.setText(areaData.getDk_pmgx());
            et_trzd.setText(areaData.getDk_trzd());
            et_trjg.setText(areaData.getDk_trgx());
            et_zays.setText(areaData.getDk_zays());
            et_qscd.setText(areaData.getDk_qscd());
            et_gcmj.setText(areaData.getDk_gchd());
            et_cysd.setText(areaData.getDk_cysd());
            et_tkmj.setText(areaData.getDk_tkmj());
            et_dbmj.setText(areaData.getDk_dbmj());
            et_zwmc1.setText(areaData.getDk_zwmcOne());
            et_pzmc1.setText(areaData.getDk_zwpzOne());
            et_dwcl1.setText(areaData.getDk_mbclOne());
            et_zwmc2.setText(areaData.getDk_zwmcTwo());
            et_pzmc2.setText(areaData.getDk_zwpzTwo());
            et_dwcl2.setText(areaData.getDk_mbclTwo());
            et_zwmc3.setText(areaData.getDk_zwmcThree());
            et_pzmc3.setText(areaData.getDk_zwpzThree());
            et_dwcl3.setText(areaData.getDk_mbclThree());
            et_zwmc4.setText(areaData.getDk_zwmcFour());
            et_pzmc4.setText(areaData.getDk_zwpzFour());
            et_dwcl4.setText(areaData.getDk_mbclFour());
            et_zwmc5.setText(areaData.getDk_zwmcFive());
            et_pzmc5.setText(areaData.getDk_zwpzFive());
            et_dwcl5.setText(areaData.getDk_mbclFive());
            et_dwmc.setText(areaData.getDk_dcdwmc());
            et_lxr.setText(areaData.getDk_dclxr());
            et_yb.setText(areaData.getDk_dcyzbm());
            et_dz.setText(areaData.getDk_dclxdz());
            et_dh.setText(areaData.getDk_dcphone());
            et_cz.setText(areaData.getDk_dccz());
            et_cydcr.setText(areaData.getDk_cydcr());
            et_email.setText(areaData.getDk_dcEMAIL());
        }
        Lable lable = DBUtils.getSingleObj(Lable.class, WhereBuilder.b("cydnumber", "=", cydNumber), "createDate", true);
        PointState pointState = DBUtils.getSingleObj(PointState.class, WhereBuilder.b("cydNumber", "=", cydNumber));
        if (null != pointState)
        {
            et_sheng.setText(pointState.getProvinceName());
            et_shi.setText(pointState.getCityName());
            et_xian.setText(pointState.getCountyName());
            et_xiang.setText(pointState.getTownName());
            et_cun.setText(pointState.getVillageName());
            et_zipcode.setText(pointState.getPostCode());
            et_location.setText(pointState.getCydName());

        }
        if (null != lable)
        {
            if (!TextUtils.isEmpty(areaData.getCreatorDate()))
            {
                try
                {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                    Date data_lable = sdf.parse(lable.getCreateDate());
                    Date date_ateadate = sdf.parse(areaData.getCreatorDate());
                    if (data_lable.before(date_ateadate))
                    {
                        //do no thing;
                    } else
                    {

                        et_height.setText(lable.getHeight());
                        et_tybh.setText(lable.getTraceNumber());//统一编号
                        et_cyxh.setText(lable.getCollectNumber());//采样序号
                        et_cymd.setText(lable.getCollectObj());//采样目的
                        et_dczh.setText(lable.getGroupNumber());//调查组好
                        et_lxr.setText(lable.getRegistrar());
                        et_dh.setText(lable.getTelephone());
                        et_phone.setText(lable.getTelephone());
                        et_lat.setText(lable.getLat() + "");
                        et_lng.setText(lable.getLon() + "");
                        et_sheng.setText(lable.getProvinceName());
                        et_shi.setText(lable.getCityName());
                        et_xian.setText(lable.getCountyName());
                        et_xiang.setText(lable.getTownName());
                        et_cun.setText(lable.getVillageName());
                    }

                } catch (ParseException e)
                {
                    e.printStackTrace();
                }
            } else
            {

                et_height.setText(lable.getHeight());
                et_tybh.setText(lable.getTraceNumber());//统一编号
                et_cyxh.setText(lable.getCollectNumber());//采样序号
                et_cymd.setText(lable.getCollectObj());//采样目的
                et_dczh.setText(lable.getGroupNumber());//调查组好
                et_lxr.setText(lable.getRegistrar());
                et_dh.setText(lable.getTelephone());
                et_phone.setText(lable.getTelephone());
                et_lat.setText(lable.getLat() + "");
                et_lng.setText(lable.getLon() + "");
                et_sheng.setText(lable.getProvinceName());
                et_shi.setText(lable.getCityName());
                et_xian.setText(lable.getCountyName());
                et_xiang.setText(lable.getTownName());
                et_cun.setText(lable.getVillageName());
            }
        }
        areaData.setCreatorID(DBUtils.getCurrentUser().getId());
        areaData.setCreatorDate(Utils.getDate(true));
        areaData.setHasUpload(false);
    }


    ArrayList<ScrollView> list_scv = new ArrayList<>();
    int index = 0;

    private void initTab()
    {
        list_scv.add(scv_data_location);
        list_scv.add(scv_data_natural);
        list_scv.add(scv_data_work);
        list_scv.add(scv_data_soil);
        list_scv.add(scv_data_next_year);
        list_scv.add(scv_data_dept);
        ArrayList<String> list_tab = new ArrayList<>();
        list_tab.add("地理位置");
        list_tab.add("自然条件");
        list_tab.add("生产条件");
        list_tab.add("土壤情况");
        list_tab.add("来年种植意向");
        list_tab.add("采样调查单位");
        tab_data_type.addTab(tab_data_type.newTab().setText(list_tab.get(0)), true);
        tab_data_type.addTab(tab_data_type.newTab().setText(list_tab.get(1)));
        tab_data_type.addTab(tab_data_type.newTab().setText(list_tab.get(2)));
        tab_data_type.addTab(tab_data_type.newTab().setText(list_tab.get(3)));
        tab_data_type.addTab(tab_data_type.newTab().setText(list_tab.get(4)));
        tab_data_type.addTab(tab_data_type.newTab().setText(list_tab.get(5)));
        tab_data_type.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener()
        {
            @Override
            public void onTabSelected(TabLayout.Tab tab)
            {
                for (int i = 0; i < list_scv.size(); i++)
                {
                    if (tab.getPosition() == i)
                        list_scv.get(i).setVisibility(View.VISIBLE);
                    else
                        list_scv.get(i).setVisibility(View.GONE);
                }
                index = tab.getPosition();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab)
            {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab)
            {

            }
        });



        sv_all.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (event.getAction() == MotionEvent.ACTION_MOVE)
                {

                    if (isfirst_move)
                    {
                        Log.i(TAG, "onTouchEvent: 第一次点击位置" + event.getX());
                        isfirst_move = false;
                        x_touch = event.getX();
                        y_touch = event.getY();

                    } else
                    {
                            if(Math.abs(event.getX()-x_touch)>Math.abs(event.getY()))
                            {
                                return true;
                            }
                            else
                                return false;
                    }
                } else if (event.getAction() == MotionEvent.ACTION_UP)
                {
                    isfirst_move = true;
                    Log.i(TAG, "onTouchEvent: 抬起位置" + event.getX());
                    float dis_x = event.getX() - x_touch;
                    float dis_y = event.getY() - y_touch;
                    if (Math.abs(dis_x) > 35 && Math.abs(dis_y) < 300)
                    {
                        TabLayout.Tab tab;
                        if (dis_x < 0)
                        {
                            tab = tab_data_type.getTabAt(index + 1);
                        } else
                        {
                            tab = tab_data_type.getTabAt(index - 1);
                        }
                        if (tab != null)
                            tab.select();
                        return true;
                    }

                } else
                    isfirst_move = true;
                return false;
            }


        });
    }

    float x_touch = 0;
    float y_touch = 0;
    Boolean isfirst_move = true;
    AlertDialog alertDialog;

    @Event(R.id.tv_save)
    private void save(View view)
    {

        alertDialog = new AlertDialog.Builder(this).setTitle("保存中").setMessage("请稍候").setCancelable(false).create();
        alertDialog.show();
        Thread thread_save = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                areaData.setDk_bh(cydNumber);
                areaData.setDk_traceNumber(Utils.getStringOrNull(et_tybh.getText().toString().trim()));
                areaData.setDk_dczh(Utils.getStringOrNull(et_dczh.getText().toString().trim()));
                areaData.setDk_cyxh(Utils.getStringOrNull(et_cyxh.getText().toString().trim()));
                areaData.setDk_cymd(Utils.getStringOrNull(et_cymd.getText().toString().trim()));
                areaData.setDk_cyrq(Utils.getStringOrNull(tv_cyrq.getText().toString().trim()));
                areaData.setDk_oldCyrq(Utils.getStringOrNull(tv_sccyrq.getText().toString().trim()));
                areaData.setDk_provice(Utils.getStringOrNull(et_sheng.getText().toString().trim()));
                areaData.setDk_city(Utils.getStringOrNull(et_shi.getText().toString().trim()));
                areaData.setDk_county(Utils.getStringOrNull(et_xian.getText().toString().trim()));
                areaData.setDk_town(Utils.getStringOrNull(et_xiang.getText().toString().trim()));
                areaData.setDk_village(Utils.getStringOrNull(et_cun.getText().toString().trim()));
                areaData.setDk_yzbm(Utils.getStringOrNull(et_zipcode.getText().toString().trim()));
                areaData.setDk_nh(Utils.getStringOrNull(et_farmname.getText().toString().trim()));
                areaData.setDk_name(Utils.getStringOrNull(et_areaname.getText().toString().trim()));
                areaData.setDk_nhphone(Utils.getStringOrNull(et_phone.getText().toString().trim()));
                areaData.setDk_loction(Utils.getStringOrNull(et_location.getText().toString().trim()));
                areaData.setDk_lon(Utils.getStringOrNull(et_lng.getText().toString().trim()));
                areaData.setDk_lat(Utils.getStringOrNull(et_lat.getText().toString().trim()));
                areaData.setDk_distance(Utils.getStringOrNull(et_distant.getText().toString().trim()));
                areaData.setDk_hbgd(Utils.getStringOrNull(et_height.getText().toString().trim()));
                areaData.setDk_dmlx(Utils.getStringOrNull(et_dmlx.getText().toString().trim()));
                areaData.setDk_dxbw(Utils.getStringOrNull(et_dxbw.getText().toString().trim()));
                areaData.setDk_dmpd(Utils.getStringOrNull(et_dmpx.getText().toString().trim()));
                areaData.setDk_tmpd(Utils.getStringOrNull(et_tmpx.getText().toString().trim()));
                areaData.setDk_px(Utils.getStringOrNull(et_px.getText().toString().trim()));
                areaData.setDk_tcdxsw(Utils.getStringOrNull(et_tcdxsw.getText().toString().trim()));
                areaData.setDk_zgdxsw(Utils.getStringOrNull(et_zgdxsw.getText().toString().trim()));
                areaData.setDk_zsdxsw(Utils.getStringOrNull(et_zsdxsw.getText().toString().trim()));
                areaData.setDk_cnjyl(Utils.getStringOrNull(et_cnjyl.getText().toString().trim()));
                areaData.setDk_cnyxjw(Utils.getStringOrNull(et_cnyxjw.getText().toString().trim()));
                areaData.setDk_cnwsq(Utils.getStringOrNull(et_cnwsq.getText().toString().trim()));
                areaData.setDk_ntjcss(Utils.getStringOrNull(et_ntjcss.getText().toString().trim()));
                areaData.setDk_psnl(Utils.getStringOrNull(et_psnl.getText().toString().trim()));
                areaData.setDk_ggnl(Utils.getStringOrNull(et_ggnl.getText().toString().trim()));
                areaData.setDk_sytj(Utils.getStringOrNull(et_sytj.getText().toString().trim()));
                areaData.setDk_ssfs(Utils.getStringOrNull(et_ssfs.getText().toString().trim()));
                areaData.setDk_ggfs(Utils.getStringOrNull(et_ggfs.getText().toString().trim()));
                areaData.setDk_sz(Utils.getStringOrNull(et_sz.getText().toString().trim()));
                areaData.setDk_dxzzzd(Utils.getStringOrNull(et_dxzzzd.getText().toString().trim()));
                areaData.setDk_cnclsp(Utils.getStringOrNull(et_cncnsp.getText().toString().trim()));
                areaData.setDk_tl(Utils.getStringOrNull(et_tl.getText().toString().trim()));
                areaData.setDk_yl(Utils.getStringOrNull(et_yl.getText().toString().trim()));
                areaData.setDk_ts(Utils.getStringOrNull(et_ts.getText().toString().trim()));
                areaData.setDk_tz(Utils.getStringOrNull(et_tz.getText().toString().trim()));
                areaData.setDk_sm(Utils.getStringOrNull(et_sm.getText().toString().trim()));
                areaData.setDk_ctmz(Utils.getStringOrNull(et_cztm.getText().toString().trim()));
                areaData.setDk_pmgx(Utils.getStringOrNull(et_pmjg.getText().toString().trim()));
                areaData.setDk_trzd(Utils.getStringOrNull(et_trzd.getText().toString().trim()));
                areaData.setDk_trgx(Utils.getStringOrNull(et_trjg.getText().toString().trim()));
                areaData.setDk_zays(Utils.getStringOrNull(et_zays.getText().toString().trim()));
                areaData.setDk_qscd(Utils.getStringOrNull(et_qscd.getText().toString().trim()));
                areaData.setDk_gchd(Utils.getStringOrNull(et_gcmj.getText().toString().trim()));
                areaData.setDk_cysd(Utils.getStringOrNull(et_cysd.getText().toString().trim()));
                areaData.setDk_tkmj(Utils.getStringOrNull(et_tkmj.getText().toString().trim()));
                areaData.setDk_dbmj(Utils.getStringOrNull(et_dbmj.getText().toString().trim()));
                areaData.setDk_zwmcOne(Utils.getStringOrNull(et_zwmc1.getText().toString().trim()));
                areaData.setDk_zwpzOne(Utils.getStringOrNull(et_pzmc1.getText().toString().trim()));
                areaData.setDk_mbclOne(Utils.getStringOrNull(et_dwcl1.getText().toString().trim()));
                areaData.setDk_zwmcTwo(Utils.getStringOrNull(et_zwmc2.getText().toString().trim()));
                areaData.setDk_zwpzTwo(Utils.getStringOrNull(et_pzmc2.getText().toString().trim()));
                areaData.setDk_mbclTwo(Utils.getStringOrNull(et_dwcl2.getText().toString().trim()));
                areaData.setDk_zwmcThree(Utils.getStringOrNull(et_zwmc3.getText().toString().trim()));
                areaData.setDk_zwpzThree(Utils.getStringOrNull(et_pzmc3.getText().toString().trim()));
                areaData.setDk_mbclThree(Utils.getStringOrNull(et_dwcl3.getText().toString().trim()));
                areaData.setDk_zwmcFour(Utils.getStringOrNull(et_zwmc4.getText().toString().trim()));
                areaData.setDk_zwpzFour(Utils.getStringOrNull(et_pzmc4.getText().toString().trim()));
                areaData.setDk_mbclFour(Utils.getStringOrNull(et_dwcl4.getText().toString().trim()));
                areaData.setDk_zwmcFive(Utils.getStringOrNull(et_zwmc5.getText().toString().trim()));
                areaData.setDk_zwpzFive(Utils.getStringOrNull(et_pzmc5.getText().toString().trim()));
                areaData.setDk_mbclFive(Utils.getStringOrNull(et_dwcl5.getText().toString().trim()));
                areaData.setDk_dcdwmc(Utils.getStringOrNull(et_dwmc.getText().toString().trim()));
                areaData.setDk_dclxr(Utils.getStringOrNull(et_lxr.getText().toString().trim()));
                areaData.setDk_dcyzbm(Utils.getStringOrNull(et_yb.getText().toString().trim()));
                areaData.setDk_dclxdz(Utils.getStringOrNull(et_dz.getText().toString().trim()));
                areaData.setDk_dcphone(Utils.getStringOrNull(et_dh.getText().toString().trim()));
                areaData.setDk_dccz(Utils.getStringOrNull(et_cz.getText().toString().trim()));
                areaData.setDk_cydcr(Utils.getStringOrNull(et_cydcr.getText().toString().trim()));
                areaData.setDk_dcEMAIL(Utils.getStringOrNull(et_email.getText().toString().trim()));
                areaData.setAreadataID(Utils.getUUID());
                areaData.setCreatorDate(Utils.getDate(true));
                areaData.setCreatorID(DBUtils.getCurrentUser().getId());
                areaData.setHasUpload(false);
                areaData.setCjrmc(DBUtils.getCurrentUser().getRealName());
                Field[] fields = areaData.getClass().getDeclaredFields();
                boolean hasAllWrite = true;
                for (Field field : fields)
                {
                    try
                    {
                        Object obj = field.get(areaData);
                        if (obj instanceof java.lang.String)
                            if (TextUtils.isEmpty(obj.toString()))
                            {
                                hasAllWrite = false;
                                break;
                            } else
                                continue;
                    } catch (IllegalAccessException e)
                    {
                        e.printStackTrace();
                    }
                }
                final boolean finalHasAllWrite = hasAllWrite;
                runOnUiThread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (null != alertDialog && alertDialog.isShowing())
                            alertDialog.dismiss();
                        if (finalHasAllWrite)
                        {
                            DBUtils.insertOrUpdateData(areaData);
                            // uploadAreadata();
                            Toast.makeText(Activity_AreaData.this, "保存完成", Toast.LENGTH_LONG).show();
                            finish();
                        } else
                        {
                            alertDialog = new AlertDialog.Builder(Activity_AreaData.this)
                                    .setTitle("提示")
                                    .setMessage("您还有字段未记录，是否仍然保存？")
                                    .setPositiveButton("是", new DialogInterface.OnClickListener()
                                    {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which)
                                        {
                                            DBUtils.insertOrUpdateData(areaData);
                                            alertDialog.dismiss();
                                            //  uploadAreadata();
                                            Toast.makeText(Activity_AreaData.this, "保存完成", Toast.LENGTH_LONG).show();
                                            finish();
                                        }
                                    }).setNegativeButton("否", null).create();
                            alertDialog.show();
                        }
                    }
                });
            }
        });
        thread_save.start();

    }

    @Event(value = {R.id.tv_cyrq, R.id.tv_sccyrq})
    private void getDate(final View view)
    {
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.TimePickerDialogInterface()
        {
            @Override
            public void positiveListener(String dateHasTime, String dateNoTime)
            {
                switch (view.getId())
                {
                    case R.id.tv_cyrq:
                        tv_cyrq.setText(dateHasTime);
                        break;
                    case R.id.tv_sccyrq:
                        tv_sccyrq.setText(dateHasTime);
                        break;
                }
            }

            @Override
            public void negativeListener()
            {

            }
        });
        timePickerDialog.showDateAndTimePickerDialog("选择日期");
    }

    /**
     * 上传采样表
     */
    String TAG = "option_load";

    private void uploadAreadata()
    {
        //final List<AreaData> areaDatas = DBUtils.getList(AreaData.class, WhereBuilder.b("hasUpload", "is", false).and("creatorID","=",DBUtils.getCurrentUser().getId()));

        List<AreaData> areaDatas = new ArrayList<>();
        areaDatas.add(areaData);
        String areadata_json = JSON.toJSONString(areaDatas);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
        params.addBodyParameter("action", "InsertCydc");
        params.addBodyParameter("json", areadata_json);
        params.setConnectTimeout(1000 * 30);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                Log.i(TAG, "onSuccess: " + result);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if (result.indexOf("\"Result\":true") != -1)
                    {
                        areaData.setHasUpload(true);
                        DBUtils.insertOrUpdateData(areaData);
                    }
                }
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.i(TAG, "onError: " + ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });

    }

    @Event(R.id.ll_exit)
    private void exit(View view)
    {
        finish();
    }


}
