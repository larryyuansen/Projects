package hc.gis.cetubao.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.xutils.db.sqlite.WhereBuilder;

import java.util.List;

import hc.gis.cetubao.Activity.Activity_LableCheck;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2018/4/9.
 */

public class Adapter_CyLable extends RecyclerView.Adapter<Adapter_CyLable.Holder_CyLable>
{
    Context mContext;
    List<Lable> mLables;

    public Adapter_CyLable(Context context, List<Lable> Lables){
        this.mContext = context;
        this.mLables = Lables;
    }

    @Override
    public Holder_CyLable onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_cylable, parent, false);
        Holder_CyLable holder_cyLable = new Holder_CyLable(view);
        return holder_cyLable;
    }

    @Override
    public void onBindViewHolder(final Holder_CyLable holder, final int position)
    {

        final Lable lable = mLables.get(position);
        holder.tvTitle.setText(lable.getCityName()+"-"+lable.getCountyName()+"-"+lable.getTownName()+"-"+lable.getVillageName()+"."+lable.getCydname());
        holder.tvPrint.setText(lable.isHasprint() ? "" : "[未打印]");
        holder.etCytime.setText("采样时间： ");
        holder.tvDate.setText(lable.getRegDate());
        MediaAsset asset = DBUtils.getSingleObj(MediaAsset.class, WhereBuilder.b("lable_id", "=", lable.getLableID()), "data", true);
        if (asset != null)
        {
            Picasso.with(mContext).load(asset.getFilepath()).into(holder.ivPic);
        } else
        {
            holder.ivPic.setVisibility(View.INVISIBLE);
        }
        Picasso.with(mContext).load(R.drawable.ic_dialog_pointnav);
        holder.item_cylable.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent  = new Intent(mContext, Activity_LableCheck.class);
                intent.putExtra("lable",lable);
                mContext.startActivity(intent);
            }
        });

//        //item点击
//        holder.item_cylable.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v)
//            {
//                if (onItemClickListener != null)
//                    onItemClickListener.onClick(position);
//            }
//
//        });
//        holder.item_cylable.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                if (onItemLongClickListener != null)
//                    onItemLongClickListener.onLongClick(position);
//                //返回false会在长安结束后继续点击
//                return true;
//            }
//        });
    }
    @Override
    public int getItemCount()
    {
        return mLables.size();
    }

    public static class Holder_CyLable extends RecyclerView.ViewHolder
    {

       TextView tvPrint,tvTitle,etCytime,tvDate;
        ImageView ivPic,ivNav;
        LinearLayout item_cylable;
        public Holder_CyLable(View itemView)
        {
            super(itemView);
            item_cylable = itemView.findViewById(R.id.ll_item_cylable);
            tvPrint = (TextView)itemView.findViewById(R.id.tv_print);
            tvTitle = (TextView) itemView.findViewById(R.id.tv_title);
            etCytime = (TextView) itemView.findViewById(R.id.et_cytime);
            tvDate = (TextView) itemView.findViewById(R.id.tv_date);
            ivPic = (ImageView) itemView.findViewById(R.id.iv_pic);
            ivNav = (ImageView) itemView.findViewById(R.id.iv_nav);

        }

    }

//    //点击接口
//    public interface OnItemClickListener {
//        void onClick(int position);
//    }
//    public interface OnItemLongClickListener {
//        void onLongClick(int position);
//    }
//    OnItemClickListener onItemClickListener;
//    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
//        this.onItemClickListener = onItemClickListener;
//    }
//    OnItemLongClickListener onItemLongClickListener;
//    public void setOnItemLongClickListener(OnItemLongClickListener onItemLongClickListener) {
//        this.onItemLongClickListener = onItemLongClickListener;
//    }

}
