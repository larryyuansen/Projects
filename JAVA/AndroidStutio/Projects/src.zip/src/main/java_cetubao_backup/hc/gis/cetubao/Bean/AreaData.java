package hc.gis.cetubao.Bean;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

import hc.gis.cetubao.Other.Utils;

/**
 * Created by Administrator on 2017/12/24.
 */
@Table(name = "areaname")
public class AreaData
{
    public AreaData()
    {
        this.areadataID = Utils.getUUID();
        hasUpload = false;
    }

    @Column(name = "id", isId = true)
    public String areadataID;
    @Column(name = "dk_traceNumber")
    public String dk_traceNumber;
    @Column(name = "dk_dczh")
    public String dk_dczh;
    @Column(name = "dk_cyxh")
    public String dk_cyxh;
    @Column(name = "dk_cymd")
    public String dk_cymd;
    @Column(name = "dk_cyrq")
    public String dk_cyrq;
    @Column(name = "dk_oldCyrq")
    public String dk_oldCyrq;
    @Column(name = "dk_provice")
    public String dk_provice;
    @Column(name = "dk_city")
    public String dk_city;
    @Column(name = "dk_county")
    public String dk_county;
    @Column(name = "dk_town")
    public String dk_town;
    @Column(name = "dk_village")
    public String dk_village;
    @Column(name = "dk_yzbm")
    public String dk_yzbm;
    @Column(name = "dk_nh")
    public String dk_nh;
    @Column(name = "dk_name")
    public String dk_name;
    @Column(name = "dk_nhphone")
    public String dk_nhphone;
    @Column(name = "dk_loction")
    public String dk_loction;
    @Column(name = "dk_lon")
    public String dk_lon;
    @Column(name = "dk_lat")
    public String dk_lat;
    @Column(name = "dk_distance")
    public String dk_distance;
    @Column(name = "dk_hbgd")
    public String dk_hbgd;
    @Column(name = "dk_dmlx")
    public String dk_dmlx;
    @Column(name = "dk_dxbw")
    public String dk_dxbw;
    @Column(name = "dk_dmpd")
    public String dk_dmpd;
    @Column(name = "dk_tmpd")
    public String dk_tmpd;
    @Column(name = "dk_px")
    public String dk_px;
    @Column(name = "dk_tcdxsw")
    public String dk_tcdxsw;
    @Column(name = "dk_zgdxsw")
    public String dk_zgdxsw;
    @Column(name = "dk_zsdxsw")
    public String dk_zsdxsw;
    @Column(name = "dk_cnjyl")
    public String dk_cnjyl;
    @Column(name = "dk_cnyxjw")
    public String dk_cnyxjw;
    @Column(name = "dk_cnwsq")
    public String dk_cnwsq;
    @Column(name = "dk_ntjcss")
    public String dk_ntjcss;
    @Column(name = "dk_psnl")
    public String dk_psnl;
    @Column(name = "dk_ggnl")
    public String dk_ggnl;
    @Column(name = "dk_sytj")
    public String dk_sytj;
    @Column(name = "dk_ssfs")
    public String dk_ssfs;
    @Column(name = "dk_ggfs")
    public String dk_ggfs;
    @Column(name = "dk_sz")
    public String dk_sz;
    @Column(name = "dk_dxzzzd")
    public String dk_dxzzzd;
    @Column(name = "dk_cnclsp")
    public String dk_cnclsp;
    @Column(name = "dk_tl")
    public String dk_tl;
    @Column(name = "dk_yl")
    public String dk_yl;
    @Column(name = "dk_ts")
    public String dk_ts;
    @Column(name = "dk_tz")
    public String dk_tz;
    @Column(name = "dk_sm")
    public String dk_sm;
    @Column(name = "dk_ctmz")
    public String dk_ctmz;
    @Column(name = "dk_pmgx")
    public String dk_pmgx;
    @Column(name = "dk_trzd")
    public String dk_trzd;
    @Column(name = "dk_trgx")
    public String dk_trgx;
    @Column(name = "dk_zays")
    public String dk_zays;
    @Column(name = "dk_qscd")
    public String dk_qscd;
    @Column(name = "dk_gchd")
    public String dk_gchd;
    @Column(name = "dk_cysd")
    public String dk_cysd;
    @Column(name = "dk_tkmj")
    public String dk_tkmj;
    @Column(name = "dk_dbmj")
    public String dk_dbmj;
    @Column(name = "dk_zwmcOne")
    public String dk_zwmcOne;
    @Column(name = "dk_zwpzOne")
    public String dk_zwpzOne;
    @Column(name = "dk_mbclOne")
    public String dk_mbclOne;
    @Column(name = "dk_zwmcTwo")
    public String dk_zwmcTwo;
    @Column(name = "dk_zwpzTwo")
    public String dk_zwpzTwo;
    @Column(name = "dk_mbclTwo")
    public String dk_mbclTwo;
    @Column(name = "dk_zwmcThree")
    public String dk_zwmcThree;
    @Column(name = "dk_zwpzThree")
    public String dk_zwpzThree;
    @Column(name = "dk_mbclThree")
    public String dk_mbclThree;
    @Column(name = "dk_zwmcFour")
    public String dk_zwmcFour;
    @Column(name = "dk_zwpzFour")
    public String dk_zwpzFour;
    @Column(name = "dk_mbclFour")
    public String dk_mbclFour;
    @Column(name = "dk_zwmcFive")
    public String dk_zwmcFive;
    @Column(name = "dk_zwpzFive")
    public String dk_zwpzFive;
    @Column(name = "dk_mbclFive")
    public String dk_mbclFive;
    @Column(name = "dk_dcdwmc")
    public String dk_dcdwmc;
    @Column(name = "dk_dclxr")
    public String dk_dclxr;
    @Column(name = "dk_dcyzbm")
    public String dk_dcyzbm;
    @Column(name = "dk_dclxdz")
    public String dk_dclxdz;
    @Column(name = "dk_dcphone")
    public String dk_dcphone;
    @Column(name = "dk_dccz")
    public String dk_dccz;
    @Column(name = "dk_cydcr")
    public String dk_cydcr;
    @Column(name = "dk_dcEMAIL")
    public String dk_dcEMAIL;
    @Column(name = "dk_bh")
    public String dk_bh;
    @Column(name = "creatorID")
    public String creatorID;
    @Column(name = "creatorDate")
    public String creatorDate;
    //创建人名称 2018年4月4日 15:53:10 添加版本：4
    @Column(name="cjrmc")
    public String cjrmc;

    public String getCjrmc()
    {
        return cjrmc;
    }

    public void setCjrmc(String cjrmc)
    {
        this.cjrmc = cjrmc;
    }

    public String getCreatorID()
    {
        return creatorID;
    }

    public void setCreatorID(String creatorID)
    {
        this.creatorID = creatorID;
    }

    public String getCreatorDate()
    {
        return creatorDate;
    }

    public void setCreatorDate(String creatorDate)
    {
        this.creatorDate = creatorDate;
    }

    public String getDk_bh()
    {
        return dk_bh;
    }

    public void setDk_bh(String dk_bh)
    {
        this.dk_bh = dk_bh;
    }

    public String getDk_traceNumber()
    {
        return dk_traceNumber;
    }

    public void setDk_traceNumber(String dk_traceNumber)
    {
        this.dk_traceNumber = dk_traceNumber;
    }

    public String getDk_dczh()
    {
        return dk_dczh;
    }

    public void setDk_dczh(String dk_dczh)
    {
        this.dk_dczh = dk_dczh;
    }

    public String getDk_cyxh()
    {
        return dk_cyxh;
    }

    public void setDk_cyxh(String dk_cyxh)
    {
        this.dk_cyxh = dk_cyxh;
    }

    public String getDk_cymd()
    {
        return dk_cymd;
    }

    public void setDk_cymd(String dk_cymd)
    {
        this.dk_cymd = dk_cymd;
    }

    public String getDk_cyrq()
    {
        return dk_cyrq;
    }

    public void setDk_cyrq(String dk_cyrq)
    {
        this.dk_cyrq = dk_cyrq;
    }

    public String getDk_oldCyrq()
    {
        return dk_oldCyrq;
    }

    public void setDk_oldCyrq(String dk_oldCyrq)
    {
        this.dk_oldCyrq = dk_oldCyrq;
    }

    public String getDk_provice()
    {
        return dk_provice;
    }

    public void setDk_provice(String dk_provice)
    {
        this.dk_provice = dk_provice;
    }

    public String getDk_city()
    {
        return dk_city;
    }

    public void setDk_city(String dk_city)
    {
        this.dk_city = dk_city;
    }

    public String getDk_county()
    {
        return dk_county;
    }

    public void setDk_county(String dk_county)
    {
        this.dk_county = dk_county;
    }

    public String getDk_town()
    {
        return dk_town;
    }

    public void setDk_town(String dk_town)
    {
        this.dk_town = dk_town;
    }

    public String getDk_village()
    {
        return dk_village;
    }

    public void setDk_village(String dk_village)
    {
        this.dk_village = dk_village;
    }

    public String getDk_yzbm()
    {
        return dk_yzbm;
    }

    public void setDk_yzbm(String dk_yzbm)
    {
        this.dk_yzbm = dk_yzbm;
    }

    public String getDk_nh()
    {
        return dk_nh;
    }

    public void setDk_nh(String dk_nh)
    {
        this.dk_nh = dk_nh;
    }

    public String getDk_name()
    {
        return dk_name;
    }

    public void setDk_name(String dk_name)
    {
        this.dk_name = dk_name;
    }

    public String getDk_nhphone()
    {
        return dk_nhphone;
    }

    public void setDk_nhphone(String dk_nhphone)
    {
        this.dk_nhphone = dk_nhphone;
    }

    public String getDk_loction()
    {
        return dk_loction;
    }

    public void setDk_loction(String dk_loction)
    {
        this.dk_loction = dk_loction;
    }

    public String getDk_lon()
    {
        return dk_lon;
    }

    public void setDk_lon(String dk_lon)
    {
        this.dk_lon = dk_lon;
    }

    public String getDk_lat()
    {
        return dk_lat;
    }

    public void setDk_lat(String dk_lat)
    {
        this.dk_lat = dk_lat;
    }

    public String getDk_distance()
    {
        return dk_distance;
    }

    public void setDk_distance(String dk_distance)
    {
        this.dk_distance = dk_distance;
    }

    public String getDk_hbgd()
    {
        return dk_hbgd;
    }

    public void setDk_hbgd(String dk_hbgd)
    {
        this.dk_hbgd = dk_hbgd;
    }

    public String getDk_dmlx()
    {
        return dk_dmlx;
    }

    public void setDk_dmlx(String dk_dmlx)
    {
        this.dk_dmlx = dk_dmlx;
    }

    public String getDk_dxbw()
    {
        return dk_dxbw;
    }

    public void setDk_dxbw(String dk_dxbw)
    {
        this.dk_dxbw = dk_dxbw;
    }

    public String getDk_dmpd()
    {
        return dk_dmpd;
    }

    public void setDk_dmpd(String dk_dmpd)
    {
        this.dk_dmpd = dk_dmpd;
    }

    public String getDk_tmpd()
    {
        return dk_tmpd;
    }

    public void setDk_tmpd(String dk_tmpd)
    {
        this.dk_tmpd = dk_tmpd;
    }

    public String getDk_px()
    {
        return dk_px;
    }

    public void setDk_px(String dk_px)
    {
        this.dk_px = dk_px;
    }

    public String getDk_tcdxsw()
    {
        return dk_tcdxsw;
    }

    public void setDk_tcdxsw(String dk_tcdxsw)
    {
        this.dk_tcdxsw = dk_tcdxsw;
    }

    public String getDk_zgdxsw()
    {
        return dk_zgdxsw;
    }

    public void setDk_zgdxsw(String dk_zgdxsw)
    {
        this.dk_zgdxsw = dk_zgdxsw;
    }

    public String getDk_zsdxsw()
    {
        return dk_zsdxsw;
    }

    public void setDk_zsdxsw(String dk_zsdxsw)
    {
        this.dk_zsdxsw = dk_zsdxsw;
    }

    public String getDk_cnjyl()
    {
        return dk_cnjyl;
    }

    public void setDk_cnjyl(String dk_cnjyl)
    {
        this.dk_cnjyl = dk_cnjyl;
    }

    public String getDk_cnyxjw()
    {
        return dk_cnyxjw;
    }

    public void setDk_cnyxjw(String dk_cnyxjw)
    {
        this.dk_cnyxjw = dk_cnyxjw;
    }

    public String getDk_cnwsq()
    {
        return dk_cnwsq;
    }

    public void setDk_cnwsq(String dk_cnwsq)
    {
        this.dk_cnwsq = dk_cnwsq;
    }

    public String getDk_ntjcss()
    {
        return dk_ntjcss;
    }

    public void setDk_ntjcss(String dk_ntjcss)
    {
        this.dk_ntjcss = dk_ntjcss;
    }

    public String getDk_psnl()
    {
        return dk_psnl;
    }

    public void setDk_psnl(String dk_psnl)
    {
        this.dk_psnl = dk_psnl;
    }

    public String getDk_ggnl()
    {
        return dk_ggnl;
    }

    public void setDk_ggnl(String dk_ggnl)
    {
        this.dk_ggnl = dk_ggnl;
    }

    public String getDk_sytj()
    {
        return dk_sytj;
    }

    public void setDk_sytj(String dk_sytj)
    {
        this.dk_sytj = dk_sytj;
    }

    public String getDk_ssfs()
    {
        return dk_ssfs;
    }

    public void setDk_ssfs(String dk_ssfs)
    {
        this.dk_ssfs = dk_ssfs;
    }

    public String getDk_ggfs()
    {
        return dk_ggfs;
    }

    public void setDk_ggfs(String dk_ggfs)
    {
        this.dk_ggfs = dk_ggfs;
    }

    public String getDk_sz()
    {
        return dk_sz;
    }

    public void setDk_sz(String dk_sz)
    {
        this.dk_sz = dk_sz;
    }

    public String getDk_dxzzzd()
    {
        return dk_dxzzzd;
    }

    public void setDk_dxzzzd(String dk_dxzzzd)
    {
        this.dk_dxzzzd = dk_dxzzzd;
    }

    public String getDk_cnclsp()
    {
        return dk_cnclsp;
    }

    public void setDk_cnclsp(String dk_cnclsp)
    {
        this.dk_cnclsp = dk_cnclsp;
    }

    public String getDk_tl()
    {
        return dk_tl;
    }

    public void setDk_tl(String dk_tl)
    {
        this.dk_tl = dk_tl;
    }

    public String getDk_yl()
    {
        return dk_yl;
    }

    public void setDk_yl(String dk_yl)
    {
        this.dk_yl = dk_yl;
    }

    public String getDk_ts()
    {
        return dk_ts;
    }

    public void setDk_ts(String dk_ts)
    {
        this.dk_ts = dk_ts;
    }

    public String getDk_tz()
    {
        return dk_tz;
    }

    public void setDk_tz(String dk_tz)
    {
        this.dk_tz = dk_tz;
    }

    public String getDk_sm()
    {
        return dk_sm;
    }

    public void setDk_sm(String dk_sm)
    {
        this.dk_sm = dk_sm;
    }

    public String getDk_ctmz()
    {
        return dk_ctmz;
    }

    public void setDk_ctmz(String dk_ctmz)
    {
        this.dk_ctmz = dk_ctmz;
    }

    public String getDk_pmgx()
    {
        return dk_pmgx;
    }

    public void setDk_pmgx(String dk_pmgx)
    {
        this.dk_pmgx = dk_pmgx;
    }

    public String getDk_trzd()
    {
        return dk_trzd;
    }

    public void setDk_trzd(String dk_trzd)
    {
        this.dk_trzd = dk_trzd;
    }

    public String getDk_trgx()
    {
        return dk_trgx;
    }

    public void setDk_trgx(String dk_trgx)
    {
        this.dk_trgx = dk_trgx;
    }

    public String getDk_zays()
    {
        return dk_zays;
    }

    public void setDk_zays(String dk_zays)
    {
        this.dk_zays = dk_zays;
    }

    public String getDk_qscd()
    {
        return dk_qscd;
    }

    public void setDk_qscd(String dk_qscd)
    {
        this.dk_qscd = dk_qscd;
    }

    public String getDk_gchd()
    {
        return dk_gchd;
    }

    public void setDk_gchd(String dk_gchd)
    {
        this.dk_gchd = dk_gchd;
    }

    public String getDk_cysd()
    {
        return dk_cysd;
    }

    public void setDk_cysd(String dk_cysd)
    {
        this.dk_cysd = dk_cysd;
    }

    public String getDk_tkmj()
    {
        return dk_tkmj;
    }

    public void setDk_tkmj(String dk_tkmj)
    {
        this.dk_tkmj = dk_tkmj;
    }

    public String getDk_dbmj()
    {
        return dk_dbmj;
    }

    public void setDk_dbmj(String dk_dbmj)
    {
        this.dk_dbmj = dk_dbmj;
    }

    public String getDk_zwmcOne()
    {
        return dk_zwmcOne;
    }

    public void setDk_zwmcOne(String dk_zwmcOne)
    {
        this.dk_zwmcOne = dk_zwmcOne;
    }

    public String getDk_zwpzOne()
    {
        return dk_zwpzOne;
    }

    public void setDk_zwpzOne(String dk_zwpzOne)
    {
        this.dk_zwpzOne = dk_zwpzOne;
    }

    public String getDk_mbclOne()
    {
        return dk_mbclOne;
    }

    public void setDk_mbclOne(String dk_mbclOne)
    {
        this.dk_mbclOne = dk_mbclOne;
    }

    public String getDk_zwmcTwo()
    {
        return dk_zwmcTwo;
    }

    public void setDk_zwmcTwo(String dk_zwmcTwo)
    {
        this.dk_zwmcTwo = dk_zwmcTwo;
    }

    public String getDk_zwpzTwo()
    {
        return dk_zwpzTwo;
    }

    public void setDk_zwpzTwo(String dk_zwpzTwo)
    {
        this.dk_zwpzTwo = dk_zwpzTwo;
    }

    public String getDk_mbclTwo()
    {
        return dk_mbclTwo;
    }

    public void setDk_mbclTwo(String dk_mbclTwo)
    {
        this.dk_mbclTwo = dk_mbclTwo;
    }

    public String getDk_zwmcThree()
    {
        return dk_zwmcThree;
    }

    public void setDk_zwmcThree(String dk_zwmcThree)
    {
        this.dk_zwmcThree = dk_zwmcThree;
    }

    public String getDk_zwpzThree()
    {
        return dk_zwpzThree;
    }

    public void setDk_zwpzThree(String dk_zwpzThree)
    {
        this.dk_zwpzThree = dk_zwpzThree;
    }

    public String getDk_mbclThree()
    {
        return dk_mbclThree;
    }

    public void setDk_mbclThree(String dk_mbclThree)
    {
        this.dk_mbclThree = dk_mbclThree;
    }

    public String getDk_zwmcFour()
    {
        return dk_zwmcFour;
    }

    public void setDk_zwmcFour(String dk_zwmcFour)
    {
        this.dk_zwmcFour = dk_zwmcFour;
    }

    public String getDk_zwpzFour()
    {
        return dk_zwpzFour;
    }

    public void setDk_zwpzFour(String dk_zwpzFour)
    {
        this.dk_zwpzFour = dk_zwpzFour;
    }

    public String getDk_mbclFour()
    {
        return dk_mbclFour;
    }

    public void setDk_mbclFour(String dk_mbclFour)
    {
        this.dk_mbclFour = dk_mbclFour;
    }

    public String getDk_zwmcFive()
    {
        return dk_zwmcFive;
    }

    public void setDk_zwmcFive(String dk_zwmcFive)
    {
        this.dk_zwmcFive = dk_zwmcFive;
    }

    public String getDk_zwpzFive()
    {
        return dk_zwpzFive;
    }

    public void setDk_zwpzFive(String dk_zwpzFive)
    {
        this.dk_zwpzFive = dk_zwpzFive;
    }

    public String getDk_mbclFive()
    {
        return dk_mbclFive;
    }

    public void setDk_mbclFive(String dk_mbclFive)
    {
        this.dk_mbclFive = dk_mbclFive;
    }

    public String getDk_dcdwmc()
    {
        return dk_dcdwmc;
    }

    public void setDk_dcdwmc(String dk_dcdwmc)
    {
        this.dk_dcdwmc = dk_dcdwmc;
    }

    public String getDk_dclxr()
    {
        return dk_dclxr;
    }

    public void setDk_dclxr(String dk_dclxr)
    {
        this.dk_dclxr = dk_dclxr;
    }

    public String getDk_dcyzbm()
    {
        return dk_dcyzbm;
    }

    public void setDk_dcyzbm(String dk_dcyzbm)
    {
        this.dk_dcyzbm = dk_dcyzbm;
    }

    public String getDk_dclxdz()
    {
        return dk_dclxdz;
    }

    public void setDk_dclxdz(String dk_dclxdz)
    {
        this.dk_dclxdz = dk_dclxdz;
    }

    public String getDk_dcphone()
    {
        return dk_dcphone;
    }

    public void setDk_dcphone(String dk_dcphone)
    {
        this.dk_dcphone = dk_dcphone;
    }

    public String getDk_dccz()
    {
        return dk_dccz;
    }

    public void setDk_dccz(String dk_dccz)
    {
        this.dk_dccz = dk_dccz;
    }

    public String getDk_cydcr()
    {
        return dk_cydcr;
    }

    public void setDk_cydcr(String dk_cydcr)
    {
        this.dk_cydcr = dk_cydcr;
    }

    public String getDk_dcEMAIL()
    {
        return dk_dcEMAIL;
    }

    public void setDk_dcEMAIL(String dk_dcEMAIL)
    {
        this.dk_dcEMAIL = dk_dcEMAIL;
    }

    public String getAreadataID()
    {
        return areadataID;
    }

    public void setAreadataID(String id)
    {
        this.areadataID = id;
    }

    @Column(name = "hasUpload")
    public Boolean hasUpload;

    public Boolean getHasUpload()
    {
        return hasUpload;
    }

    public void setHasUpload(Boolean hasUpload)
    {
        this.hasUpload = hasUpload;
    }
}
