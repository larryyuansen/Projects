package hc.gis.cetubao.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;

import com.amap.api.maps.AMapOptions;
import com.amap.api.maps.MapView;

import hc.gis.cetubao.Activity.Activity_Navigation;

/**
 * Created by Administrator on 2017/12/10.
 */

public class MyAmap extends MapView
{
    Context mContext;
    public MyAmap(Context context)
    {
        super(context);
        this.mContext =context;
    }

    public MyAmap(Context context, AttributeSet attributeSet)
    {
        super(context, attributeSet);
    }

    public MyAmap(Context context, AttributeSet attributeSet, int i)
    {
        super(context, attributeSet, i);
    }

    public MyAmap(Context context, AMapOptions aMapOptions)
    {
        super(context, aMapOptions);
    }


}
