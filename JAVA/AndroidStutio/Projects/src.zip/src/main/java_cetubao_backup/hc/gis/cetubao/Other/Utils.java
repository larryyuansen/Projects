package hc.gis.cetubao.Other;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;

import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.RecursiveTask;

import hc.gis.cetubao.Bean.PointState;

/**
 * Created by Administrator on 2017/12/9.
 */

public class Utils
{

    public static String getUUID()
    {
        return UUID.randomUUID().toString();
    }

    public static String formatDate(long date_long, Boolean hastime)
    {
        Format simpleFormat;
        if (hastime)
            simpleFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        else
            simpleFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date(date_long);
        return simpleFormat.format(date);

    }

    public static String getStringOrNull(Object string)
    {
        if(null==string)
            return null;
        if(TextUtils.isEmpty(string.toString().trim()))
        {
            return null;
        }
        else
            return string.toString();
    }
    public static List<Integer> checkPermission(Context context, String...permissions)
    {
        List<Integer> index_NeedPermissions = new MyList();
        int i=0;
        for(String permission:permissions)
        {
            try
            {
                int result = ActivityCompat.checkSelfPermission(context,permission);
                if(result!= PackageManager.PERMISSION_GRANTED)
                    index_NeedPermissions.add(i);
            }catch (Exception e)
            {
                if(Build.VERSION.SDK_INT<23)
                {
                   continue;
                }
                else
                {
                    index_NeedPermissions.add(i);
                }
            }
            i++;
        }
        return  index_NeedPermissions;

    }
    public static boolean IntegerEquals(Object obj1, Object obj2)
    {
        try
        {
            int o1 = Integer.valueOf(obj1.toString());
            int o2 = Integer.valueOf(obj2.toString());
            return o1 == o2;
        } catch (Exception e)
        {
            return false;
        }

    }
    public static String getDate(Boolean hasTime)
    {
        long datetime = System.currentTimeMillis();
        Date date = new Date(datetime);
        SimpleDateFormat dateFormat;
        if (hasTime)
        {
            dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        } else
            dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        return dateFormat.format(date);
    }

    public static String getFullName(PointState pointState)
    {
        return pointState.getProvinceName()+"."+pointState.getCityName()+"."+pointState.getCountyName()+"."+pointState.getTownName()+pointState.getVillageName()+"."+pointState.getCydName();
    }
    public static String getFullName_Short_NoDot(PointState pointState)
    {
        return pointState.getCityName()+"-"+pointState.getCountyName()+"-"+pointState.getTownName()+pointState.getVillageName()+"-"+pointState.getCydName();
    }
    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    public static int dip2px(Context context, float dpValue)
    {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
     */
    public static int px2dip(Context context, float pxValue)
    {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * @param long1 经度1
     * @param lat1  维度1
     * @param long2 经度2
     * @param lat2  纬度2
     * @return
     * @author http://blog.csdn.net/xiaobai091220106/article/details/50879414
     */
    public static double getDistance(double long1, double lat1, double long2,
                                     double lat2)
    {
        double a, b, R;
        R = 6378137; // 地球半径
        lat1 = lat1 * Math.PI / 180.0;
        lat2 = lat2 * Math.PI / 180.0;
        a = lat1 - lat2;
        b = (long1 - long2) * Math.PI / 180.0;
        double d;
        double sa2, sb2;
        sa2 = Math.sin(a / 2.0);
        sb2 = Math.sin(b / 2.0);
        d = 2 * R * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1) * Math.cos(lat2) * sb2 * sb2));
        return d;
    }

    /**
     * @param lat_a 纬度1
     * @param lng_a 经度1
     * @param lat_b 纬度2
     * @param lng_b 经度2
     * @return
     * @author http://blog.csdn.net/xiaobai091220106/article/details/50879414
     */
    public static double getAngle(double lat_a, double lng_a, double lat_b, double lng_b)
    {

        double y = Math.sin(lng_b - lng_a) * Math.cos(lat_b);
        double x = Math.cos(lat_a) * Math.sin(lat_b) - Math.sin(lat_a) * Math.cos(lat_b) * Math.cos(lng_b - lng_a);
        double brng = Math.atan2(y, x);
        brng = Math.toDegrees(brng);
        if (brng < 0)
            brng = brng + 360;
        return brng;

    }

    public static Double getScale(double value, int scale)
    {

        return Double.valueOf(new BigDecimal(value).setScale(scale, BigDecimal.ROUND_HALF_UP).toPlainString());
    }

    public static LatLngBounds getBound(LatLng... latLngs)
    {
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        for (LatLng latLng : latLngs)
        {
            boundsBuilder.include(latLng);
        }
        return boundsBuilder.build();
    }

    public static double gps2d(double lat_a, double lng_a, double lat_b, double lng_b)
    {
        double d = 0;
        lat_a = lat_a * Math.PI / 180;
        lng_a = lng_a * Math.PI / 180;
        lat_b = lat_b * Math.PI / 180;
        lng_b = lng_b * Math.PI / 180;

        d = Math.sin(lat_a) * Math.sin(lat_b) + Math.cos(lat_a) * Math.cos(lat_b) * Math.cos(lng_b - lng_a);
        d = Math.sqrt(1 - d * d);
        d = Math.cos(lat_b) * Math.sin(lng_b - lng_a) / d;
        d = Math.asin(d) * 180 / Math.PI;

//     d = Math.round(d*10000);
        return d;
    }

    /**
     * 地球赤道半径(km)
     * */
    public final static double EARTH_RADIUS = 6378.137;
    /**
     * 地球每度的弧长(km)
     * */
    public final static double EARTH_ARC = 111.199;

    /**
     * 转化为弧度(rad)
     * */
    public static double rad(double d) {
        return d * Math.PI / 180.0;
    }


    public static double GetAzimuth(double lat1,double lon1, double lat2, double lon2)
    {

        lat1 = rad(lat1);
        lat2 = rad(lat2);
        lon1 = rad(lon1);
        lon2 = rad(lon2);
        double azimuth = Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1)
                * Math.cos(lat2) * Math.cos(lon2 - lon1);
        azimuth = Math.sqrt(1 - azimuth * azimuth);
        azimuth = Math.cos(lat2) * Math.sin(lon2 - lon1) / azimuth;
        azimuth = Math.asin(azimuth) * 180 / Math.PI;
        if (Double.isNaN(azimuth))
        {
            if (lon1 < lon2)
            {
                azimuth = 90.0;
            } else
            {
                azimuth = 270.0;
            }
        }
        if(azimuth<0)
            return azimuth+360f;
        return azimuth;
    }

    private static final int TWO_MINUTES = 1000 * 1 * 2;
    public static boolean isBetterLocation(Location location, Location currentBestLocation)
    {
        if (currentBestLocation == null)
        {
            // A new location is always better than no location
            return true;
        }

        // Check whether the new location fix is newer or older
        long timeDelta = location.getTime() - currentBestLocation.getTime();
        boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
        boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
        boolean isNewer = timeDelta > 0;

        // If it's been more than two minutes since the current location, use
        // the new location
        // because the user has likely moved
        if (isSignificantlyNewer)
        {
            return true;
            // If the new location is more than two minutes older, it must be
            // worse
        }
        else if (isSignificantlyOlder)
        {
            return false;
        }

        // Check whether the new location fix is more or less accurate
        int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
        boolean isLessAccurate = accuracyDelta > 0;
        boolean isMoreAccurate = accuracyDelta < 0;
        boolean isSignificantlyLessAccurate = accuracyDelta > 200;

        // Check if the old and new location are from the same provider
        boolean isFromSameProvider = isSameProvider(location.getProvider(), currentBestLocation.getProvider());

        // Determine location quality using a combination of timeliness and
        // accuracy
        if (isMoreAccurate)
        {
            return true;
        }
        else if (isNewer && !isLessAccurate)
        {
            return true;
        }
        else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider)
        {
            return true;
        }
        return false;
    }

    /** Checks whether two providers are the same */
    private static boolean isSameProvider(String provider1, String provider2)
    {
        if (provider1 == null)
        {
            return provider2 == null;
        }
        return provider1.equals(provider2);
    }

    public  static class BooleanUtils {

        /**
         * 除了TURE,Y和1,其他都为false
         * @param s
         * @return
         */
        public static boolean toBoolFalse(String s){
            if(s!=null&&(s.equals('Y')||s.equals("1")||s.toUpperCase().equals("TRUE")||s.toUpperCase().equals("true"))){
                return true;
            }else{
                return false;
            }
        }


        /**
         * 除了FALSE,N,0,null,其他都为true
         * @param s
         * @return
         */
        public static boolean toBoolTrue(String s){
            if(s!=null){
                if((s.equals('N')||s.equals("0")||s.toUpperCase().equals("FALSE"))){
                    return false;
                }else{
                    return true;
                }
            }else{
                return false;
            }
        }

        /**
         * 将布尔值转换为Y或者N
         * @param b
         * @return
         */
        public static String boolToStr(boolean b){
            if(b){
                return "Y";
            }else{
                return "N";
            }
        }

        /**
         * 将布尔值转换为1或者0
         * @param b
         * @return
         */
        public static int boolToInt(boolean b){
            if(b){
                return 1;
            }else{
                return 0;
            }
        }
    }
    public static SpannableString getSpannString(String str,int Color)
    {
        SpannableString spannableString = new SpannableString(str);
        spannableString.setSpan(new ForegroundColorSpan(Color),0,spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableString;
    }
    public static SpannableString getSpannString(String str,String Color)
    {
        return  getSpannString(str, android.graphics.Color.parseColor(Color));
    }
}
