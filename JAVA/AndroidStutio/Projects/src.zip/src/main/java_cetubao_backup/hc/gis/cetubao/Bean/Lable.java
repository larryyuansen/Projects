package hc.gis.cetubao.Bean;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

import java.io.Serializable;

import hc.gis.cetubao.Other.Utils;

/**
 * Created by Administrator on 2017/12/13.
 */
@Table(name = "lable")
public class Lable implements Serializable
{
    @Column(name = "lableid", isId = true)//本地主键
    String lableid;
    @Column(name = "traceNumber")
    String traceNumber;//统一编号
    @Column(name = "hasprint")
    boolean hasprint = false;//是否已打印(本地)
    @Column(name = "groupNumber")
    String groupNumber;//组号
    @Column(name = "collectNumber")
    String collectNumber;//采集序号
    @Column(name = "collectObj")
    String collectObj;//采样目的
    @Column(name = "cydnumber")
    String cydnumber;//采样点编号
    @Column(name = "regDate")
     String regDate;//采集时间
    @Column(name = "collectDeep")
    String collectDeep;//采集深度
    @Column(name = "lat")
    double lat;//纬度
    @Column(name = "lon")
    double lon;//经度
    @Column(name = "registrar")
    String registrar;//采集人
    @Column(name = "telephone")
    String telephone;//手机号
    @Column(name = "remark")
    String remark;//备注
    @Column(name = "postCode")
    String postCode;//邮编
    @Column(name = "creatorID")
    String creatorID;//创建人(可能不是采集人，服务器如果没有就不用管)
    @Column(name = "createDate")
    String createDate;//创建时间(非采集时间)
    @Column(name = "provinceid")
    public String provinceid;
    @Column(name = "provinceName")
    public String provinceName;
    @Column(name = "cityName")
    public String cityName;
    @Column(name = "countyName")
    public String countyName;
    @Column(name = "townName")
    public String townName;
    @Column(name = "villageName")
    public String villageName;
    @Column(name = "cydname")
    public String cydname;
    //海拔高度 新添加字段 添加时间 2018年2月27日 11:11:54 添加版本：3
    @Column(name="height")
    public String height;
    //创建人姓名 添加时间 2018年4月4日 15:51:52 添加版本：4
    @Column(name="cjrmc")
    public String cjrmc;
    //标签年份 添加时间 2018年4月4日 15:55:51 添加版本：4
    @Column(name = "year")
    public String year;

    public String getCydname()
    {
        return cydname;
    }

    public void setCydname(String cydname)
    {
        this.cydname = cydname;
    }

    public String getProvinceid()
    {
        return provinceid;
    }

    public void setProvinceid(String provinceid)
    {
        this.provinceid = provinceid;
    }

    public String getProvinceName()
    {
        return provinceName;
    }

    public void setProvinceName(String provinceName)
    {
        this.provinceName = provinceName;
    }

    public String getCityName()
    {
        return cityName;
    }

    public void setCityName(String cityName)
    {
        this.cityName = cityName;
    }

    public String getCountyName()
    {
        return countyName;
    }

    public void setCountyName(String countyName)
    {
        this.countyName = countyName;
    }

    public String getTownName()
    {
        return townName;
    }

    public void setTownName(String townName)
    {
        this.townName = townName;
    }

    public String getVillageName()
    {
        return villageName;
    }

    public void setVillageName(String villageName)
    {
        this.villageName = villageName;
    }

    public String getLableid()
    {
        return lableid;
    }

    public String getCjrmc()
    {
        return cjrmc;
    }

    public void setCjrmc(String cjrmc)
    {
        this.cjrmc = cjrmc;
    }

    public String getYear()
    {
        return year;
    }

    public void setYear(String year)
    {
        this.year = year;
    }

    public void setLableid(String lableid)
    {
        this.lableid = lableid;
    }

    public String getHeight()
    {
        return height;
    }

    public void setHeight(String height)
    {
        this.height = height;
    }

    public String getRegYear()
    {

        return regYear;
    }

    public void setRegYear(String regYear)
    {
        this.regYear = regYear;
    }

    @Column(name = "regYear")

    String regYear;

    public String getCreateDate()
    {
        return createDate;
    }

    public void setCreateDate(String createDate)
    {
        this.createDate = createDate;
    }

    public boolean isHasprint()
    {
        return hasprint;
    }

    public void setHasprint(boolean hasprint)
    {
        this.hasprint = hasprint;
    }

    public void setHasprint(String string)
    {
        this.hasprint = Utils.BooleanUtils.toBoolFalse(string);
    }
    public String getGroupNumber()
    {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber)
    {
        this.groupNumber = groupNumber;
    }

    public String getCollectNumber()
    {
        return collectNumber;
    }

    public void setCollectNumber(String collectNumber)
    {
        this.collectNumber = collectNumber;
    }

    public String getCollectObj()
    {
        return collectObj;
    }

    public void setCollectObj(String collectObj)
    {
        this.collectObj = collectObj;
    }


    public String getTraceNumber()
    {
        return traceNumber;
    }

    public void setTraceNumber(String traceNumber)
    {
        this.traceNumber = traceNumber;
    }


    public String getCydnumber()
    {
        return cydnumber;
    }

    public void setCydnumber(String cydnumber)
    {
        this.cydnumber = cydnumber;
    }



    public String getPostCode()
    {
        return postCode;
    }

    public void setPostCode(String postCode)
    {
        this.postCode = postCode;
    }


    public String getCreatorID()
    {
        return creatorID;
    }

    public void setCreatorID(String createrID)
    {
        this.creatorID = createrID;
    }


    public String getLableID()
    {
        return lableid;
    }

    public void setLableID(String lableid)
    {
        this.lableid = lableid;
    }

    public String getRegDate()
    {
        return regDate;
    }

    public void setRegDate(String regDate)
    {
        this.regDate = regDate;
    }

    public String getCollectDeep()
    {
        return collectDeep;
    }

    public void setCollectDeep(String collectDeep)
    {
        this.collectDeep = collectDeep;
    }

    public double getLat()
    {
        return lat;
    }

    public void setLat(double lat)
    {
        this.lat = lat;
    }

    public double getLon()
    {
        return lon;
    }

    public void setLon(double lon)
    {
        this.lon = lon;
    }

    public String getRegistrar()
    {
        return registrar;
    }

    public void setRegistrar(String registrar)
    {
        this.registrar = registrar;
    }

    public String getTelephone()
    {
        return telephone;
    }

    public void setTelephone(String telephone)
    {
        this.telephone = telephone;
    }

    public String getRemark()
    {
        return remark;
    }

    public void setRemark(String remark)
    {
        this.remark = remark;
    }

    public Lable()
    {
        this.lableid = Utils.getUUID();
        hasUpload = false;
    }

    ;
    @Column(name = "hasUpload")
    Boolean hasUpload;

    public Boolean getHasUpload()
    {
        return hasUpload;
    }

    public void setHasUpload(Boolean hasUpload)
    {
        this.hasUpload = hasUpload;

    }

    public String getAreaname()
    {
        return getCityName()+"-"+getCountyName()+"-"+getTownName()+"-"+getVillageName()+"."+getCydname();
    }
}
