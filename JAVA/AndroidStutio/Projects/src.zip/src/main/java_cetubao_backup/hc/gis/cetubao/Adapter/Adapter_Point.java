package hc.gis.cetubao.Adapter;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import hc.gis.cetubao.Activity.ActivityDialog_PointOperation;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.Fragment.Fragment_Point;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/22.
 */

public class Adapter_Point extends RecyclerView.Adapter<Adapter_Point.Holder_Point>
{
    Fragment mContext;
    List<PointState> list_pointStates;
    String keyWord=null;
    public Adapter_Point(Fragment context, List<PointState> list_pointStates)
    {
        this.list_pointStates = list_pointStates;
        this.mContext = context;
    }
    public void setKeyWord(String keyWord)
    {
        this.keyWord = keyWord;
    }

    @Override
    public Holder_Point onCreateViewHolder(ViewGroup parent, int viewType)
    {
        Holder_Point holder = new Holder_Point(LayoutInflater.from(mContext.getContext()).inflate(R.layout.item_point_list,parent,false));
        return holder;
    }

    @Override
    public void onBindViewHolder(Holder_Point holder_Point, int position)
    {
        final PointState pointState = list_pointStates.get(position);
        if(pointState.getHasSampling().equals("1"))
            holder_Point.tv_area_name.setBackground(ContextCompat.getDrawable(mContext.getContext(),R.drawable.selector_point_circle_hassampling));
        else
            holder_Point.tv_area_name.setBackground(ContextCompat.getDrawable(mContext.getContext(),R.drawable.selector_point_circle));
        holder_Point.tv_area_fullname.setText(Utils.getFullName_Short_NoDot(pointState));
        holder_Point.tv_area_name.setText(pointState.getCydName());
        holder_Point.tv_area_number.setText(TextUtils.isEmpty(pointState.getNewtybh())?pointState.getTybh():pointState.getNewtybh());
        holder_Point.btn_location.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                ((Fragment_Point)(mContext)).switchContent(false,pointState);
            }
        });
        holder_Point.ll_point_ietm.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(mContext.getContext(), ActivityDialog_PointOperation.class);
                intent.putExtra("pointState", pointState);
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return list_pointStates.size();
    }

    class Holder_Point extends RecyclerView.ViewHolder
    {
        LinearLayout ll_point_ietm;
        TextView tv_area_name,tv_area_fullname,tv_area_number;
        Button btn_location;
        public Holder_Point(View itemView)
        {
            super(itemView);
            ll_point_ietm = itemView.findViewById(R.id.ll_point_item);
            tv_area_name = itemView.findViewById(R.id.tv_area_name);
            tv_area_fullname = itemView.findViewById(R.id.tv_area_fullname);
            tv_area_number = itemView.findViewById(R.id.tv_area_number);
            btn_location = itemView.findViewById(R.id.btn_location);
        }
    }
}
