package hc.gis.cetubao.DB;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.support.v4.app.ActivityCompat;

import org.xutils.DbManager;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.ex.DbException;
import org.xutils.x;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.Bean.AreaData;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.Bean.User;

/**
 * Created by Administrator on 2017/12/9.
 */

public class DBUtils
{
    private static final int DATABASEVERSION = 6;//当前数据库版本

    private static DbManager.DaoConfig daoConfig;
    private static DbManager manager;



    private static <T> void addColumn(Class<T> c, String tablename, String column, DbManager db) {
        if (!CheckColumn(tablename, column, db)) {
            try {
                db.addColumn(c, column);
            } catch (DbException e) {
                e.printStackTrace();
            }
        }
    }

    public static Boolean CheckColumn(String table, String column, DbManager db) {
        Cursor cursor = null;
        Boolean hasColumn;
        Boolean hasTable;
        try {
            cursor = db.execQuery("select * from sqlite_master where name='" + table + "'");//先检查是否有这张表
            hasTable = cursor.moveToFirst();
        } catch (DbException e) {
            hasTable = false;
            e.printStackTrace();
        } finally {
            if (null != cursor)
                cursor.close();
        }
        if (!hasTable)//如果没有表，则不用理会新增字段，创建新数据时会自行创建
            return true;

        //继续判断表类是否有此字段
        try {
            cursor = db.execQuery("select * from sqlite_master where name='" + table + "' and sql like '%" + column + "%'");
            hasColumn = cursor.moveToFirst();
        } catch (DbException e) {
            hasColumn = false;
            e.printStackTrace();
        } finally {
            if (null != cursor)
                cursor.close();
        }

        return hasColumn;

    }


    public static <T> void DeleteTable(Class<T> c)
    {
        try
        {
            manager.delete(c);
        } catch (DbException e)
        {
            e.printStackTrace();
        }
    }
    public static <T> void DeleteTable(Class<T> c,WhereBuilder builder)
    {
        try
        {
            manager.delete(c,builder);
        } catch (DbException e)
        {
            e.printStackTrace();
        }
    }
    private static void updateDB(int oldVersion, DbManager db)
    {
        try
        {
            switch (oldVersion)
            {
                case 1:
                    db.addColumn(PointState.class, "hasUpload");
                case 2:
                    db.addColumn(Lable.class,"height");
                    db.addColumn(PointState.class,"tybh");
                case 3:
                    List<AreaData> areaData = db.findAll(AreaData.class);
                    for(AreaData data:areaData)
                    {
                        if(data.getDk_dbmj().equals("80亩"))
                            data.setDk_dbmj("80");
                    }
                    db.saveOrUpdate(areaData);

                case 4:
                    db.addColumn(PointState.class,"cjrmc");
                    db.addColumn(Lable.class,"year");
                    db.addColumn(Lable.class,"cjrmc");
                    db.addColumn(AreaData.class,"cjrmc");
                    db.addColumn(MediaAsset.class,"scrmc");
                    db.addColumn(PointState.class,"provinceid");
                    db.addColumn(PointState.class, "provinceName");
                    db.addColumn(PointState.class, "cityName");
                    db.addColumn(PointState.class, "countyName");
                    db.addColumn(PointState.class, "townName");
                    db.addColumn(PointState.class, "villageName");
                    db.addColumn(PointState.class,"newtybh");
                case 5:
                    db.addColumn(Lable.class, "provinceName");
                    db.addColumn(Lable.class, "cityName");
                    db.addColumn(Lable.class, "countyName");
                    db.addColumn(Lable.class, "townName");
                    db.addColumn(Lable.class, "villageName");
                    db.addColumn(Lable.class,"cydname");
                    break;
            }
        } catch (Exception e)
        {

        }
    }

    public static void initDB()
    {
        daoConfig = new DbManager.DaoConfig()
                .setDbName("Marks.db")
                // 不设置dbDir时, 默认存储在app的私有目录.
                .setDbVersion(DATABASEVERSION)
                .setDbOpenListener(new DbManager.DbOpenListener()
                {
                    @Override
                    public void onDbOpened(DbManager db)
                    {
                        // 开启WAL, 对写入加速提升巨大
                        db.getDatabase().enableWriteAheadLogging();
                    }
                })
                .setDbUpgradeListener(new DbManager.DbUpgradeListener()
                {
                    @Override
                    public void onUpgrade(DbManager db, int oldVersion, int newVersion)
                    {
                        updateDB(oldVersion,db);
                    }
                });
        manager = x.getDb(daoConfig);
    }

    public static <T> List<T> getList(Class<T> c, WhereBuilder builder, String order, boolean desc)
    {
        try
        {
            List<T> list;
            list = manager.selector(c).where(builder).orderBy(order, desc).findAll();
            if (list == null || list.size() == 0)
                return new ArrayList<>();
            return list;
        } catch (DbException e)
        {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static <T> List<T> getList(Class<T> c, WhereBuilder builder)
    {
        try
        {
            List<T> list;
            list = manager.selector(c).where(builder).findAll();
            if (list == null || list.size() == 0)
                return new ArrayList<>();
            return list;
        } catch (DbException e)
        {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static <T> List<T> getList(Class<T> c)
    {
        try
        {
            List<T> list;
            list = manager.selector(c).findAll();
            if (list == null || list.size() == 0)
                return new ArrayList<>();
            return list;
        } catch (DbException e)
        {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static <T> int getCount(Class<T> c, WhereBuilder builder)
    {
        try
        {
            return manager.selector(c).where(builder).findAll().size();
        } catch (DbException e)
        {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * 插入数据
     *
     * @param obj
     * @return
     */
    public static Boolean insertOrUpdateData(Object obj)
    {
        try
        {
            manager.saveOrUpdate(obj);

        } catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static void LoginSuccess(User user)
    {
        try
        {
            manager.delete(User.class);
            manager.saveOrUpdate(user);
        } catch (DbException e)
        {
            e.printStackTrace();
        }
    }

    public static void signout()
    {
        try
        {
            manager.delete(User.class);
        } catch (DbException e)
        {
            e.printStackTrace();
        }
    }

    public static User getCurrentUser()
    {
        try
        {
            return manager.selector(User.class).findFirst();
        } catch (DbException e)
        {

            e.printStackTrace();
            return null;
        }
    }

    public static <T> T getSingleObj(Class<T> c, WhereBuilder b)
    {
        try
        {
            return manager.selector(c).where(b).findFirst();
        } catch (DbException e)
        {
            e.printStackTrace();
            return null;
        }

    }

    public static <T> T getSingleObj(Class<T> c, WhereBuilder b, String order, Boolean desc)
    {
        try
        {
            return manager.selector(c).where(b).orderBy(order, desc).findFirst();
        } catch (DbException e)
        {
            e.printStackTrace();
            return null;
        }

    }

    public static boolean delPointInfo(PointState pointState)
    {
        try
        {
            manager.delete(AreaData.class, WhereBuilder.b("cydNumber", "=", pointState.getCydNumber()));
            manager.delete(Lable.class, WhereBuilder.b("cydNumber", "=", pointState.getCydNumber()));
            manager.delete(pointState);

            return true;
        } catch (DbException e)
        {
            e.printStackTrace();
            return false;
        }
    }


    public static boolean deleteLable(Lable lable)
    {
        try
        {
            manager.delete(MediaAsset.class, WhereBuilder.b("lable_id", "=", lable.getLableID()));
            manager.delete(lable);
            return true;
        } catch (DbException e)
        {
            e.printStackTrace();
            return false;
        }
    }
}
