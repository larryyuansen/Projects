package hc.gis.cetubao.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.List;

import HPRTAndroidSDKA300.HPRTPrinterHelper;
import HPRTAndroidSDKA300.PublicFunction;
import hc.gis.cetubao.Activity.Bluetooth.Activity_DeviceList;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.BuildConfig;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.R;

@ContentView(R.layout.activity_lable_details)
public class Activity_LableDetails extends MBaseActivity
{

    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;

    @ViewInject(R.id.tv_height)
    TextView tv_height;
    @ViewInject(R.id.tv_delete)
    TextView tv_delete;
    @ViewInject(R.id.title)
    LinearLayout title;
    @ViewInject(R.id.tv_bluetooth)
    TextView tv_bluetooth;
    @ViewInject(R.id.ll_choice_state)
    LinearLayout ll_choice_state;
    @ViewInject(R.id.tv_area_name)
    TextView tv_area_name;
    @ViewInject(R.id.tv_zipcode)
    TextView tv_zipcode;
    @ViewInject(R.id.tv_area_bearing)
    TextView tv_area_bearing;
    @ViewInject(R.id.line)
    ImageView line;
    @ViewInject(R.id.layout_topinfo)
    RelativeLayout layout_topinfo;
    @ViewInject(R.id.tv_lablenumber)
    TextView tv_lablenumber;
    @ViewInject(R.id.tv_date)
    TextView tv_date;
    @ViewInject(R.id.tv_deep_input)
    TextView tv_deep_input;
    @ViewInject(R.id.ll_collect_input)
    LinearLayout ll_collect_input;
    @ViewInject(R.id.tv_latlng)
    TextView tv_latlng;
    @ViewInject(R.id.tv_collecter)
    TextView tv_collecter;
    @ViewInject(R.id.tv_pohne)
    TextView tv_pohne;
    @ViewInject(R.id.ll_pic)
    LinearLayout ll_pic;
    @ViewInject(R.id.tv_remark)
    TextView tv_remark;
    @ViewInject(R.id.btn_lable_print)
    Button btn_lable_print;
    @ViewInject(R.id.rl_save)
    RelativeLayout rl_save;
    @ViewInject(R.id.tv_title_lable)
    TextView tv_title_lable;
    @ViewInject(R.id.ll_img)
    LinearLayout ll_img;
    Lable lable;
    private static HPRTPrinterHelper HPRTPrinter = new HPRTPrinterHelper();

    String LableID;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        x.view().inject(this);
        super.onCreate(savedInstanceState);
        try
        {
            lable = (Lable) getIntent().getSerializableExtra("lable");
            if (null==lable)
                finish();
        } catch (Exception e)
        {
            finish();
        }
        changePageContent();
    }

    Boolean bleConnected = false;






    @Event(value = {R.id.ll_exit, R.id.tv_bluetooth, R.id.btn_lable_print, R.id.tv_delete})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.ll_exit:
                finish();
                break;
            case R.id.tv_bluetooth:
                checkBluetooth();
                break;
            case R.id.btn_lable_print:
                print();
                break;
            case R.id.tv_delete:
                DeleteLable();
                break;
        }
    }

    AlertDialog alterdialog;

    private void DeleteLable()
    {
        alterdialog = new AlertDialog.Builder(this).setTitle("是否删除此标签").setNegativeButton("否", null)
                .setPositiveButton("是", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        DBUtils.deleteLable(lable);
                        //initView();
                        finish();
                        alterdialog.dismiss();
                    }
                }).create();
        alterdialog.show();
    }

    private String ConnectType = "";
    private Context thisCon = null;

    private void checkBluetooth()
    {
        if (bleConnected)
        {
            tv_bluetooth.setText(getString(R.string.activity_main_tips));
            bleConnected = false;
            try
            {
                HPRTPrinterHelper.PortClose();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
            return;
        }
        if (Build.VERSION.SDK_INT >= 23)
        {
            //校验是否已具有模糊定位权限
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION},
                        100);
            } else
            {

                //具有权限
                ConnectType = "Bluetooth";
                Intent serverIntent = new Intent(getApplicationContext(), Activity_DeviceList.class);
                startActivityForResult(serverIntent, HPRTPrinterHelper.ACTIVITY_CONNECT_BT);
                return;

            }
        } else
        {
            //系统不高于6.0直接执行
            ConnectType = "Bluetooth";
            Intent serverIntent = new Intent(getApplicationContext(), Activity_DeviceList.class);
            startActivityForResult(serverIntent, HPRTPrinterHelper.ACTIVITY_CONNECT_BT);
        }
    }


    protected void onActivityResult(int requestCode, int resultCode, final Intent data)
    {
        try
        {

            switch (resultCode)
            {
                case HPRTPrinterHelper.ACTIVITY_CONNECT_BT:
                    int result = data.getExtras().getInt("is_connected");
                    if (result == 0)
                    {
                        tv_bluetooth.setText(getString(R.string.activity_main_connected));
                        tv_bluetooth.setText(getString(R.string.ble_close));
                        bleConnected = true;
                    } else
                    {
                        tv_bluetooth.setText(getString(R.string.activity_main_connecterr) + result);
                        bleConnected = false;
                    }
                    break;
            }
        } catch (Exception e)
        {
            Log.e("HPRTSDKSample", (new StringBuilder("Activity_Main --> onActivityResult ")).append(e.getMessage()).toString());
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    private void changePageContent()
    {
        StringBuilder builder = new StringBuilder("土壤采样标签");
        builder.append(lable.isHasprint() ? "(已打印)" : "(未打印)");
        builder.append(lable.getHasUpload() ? "(来自服务器)" : "(来自本地)");
        tv_title_lable.setText(builder.toString());
        if (lable.getHasUpload())
        {
            tv_delete.setVisibility(View.INVISIBLE);
            ll_img.setVisibility(View.GONE);
        } else
        {
            tv_delete.setVisibility(View.VISIBLE);
            ll_img.setVisibility(View.VISIBLE);
        }
        tv_lablenumber.setText(lable.getTraceNumber());
        tv_area_name.setText(TextUtils.isEmpty(lable.getAreaname()) ? "历史数据，无名称" : lable.getAreaname());
        tv_date.setText(lable.getRegDate());
        tv_height.setText(lable.getHeight());
        tv_deep_input.setText(lable.getCollectDeep()==null||lable.getCollectDeep().equals("-1") ? "0~20" : lable.getCollectDeep());
        tv_latlng.setText("（" + lable.getLon() + "，" + lable.getLat() + "）");
        tv_collecter.setText(lable.getRegistrar());
        tv_pohne.setText(lable.getTelephone());
        tv_remark.setText(lable.getRemark());
        tv_zipcode.setText(getString(R.string.postCode) + lable.getPostCode());
        List<MediaAsset> assets = DBUtils.getList(MediaAsset.class, WhereBuilder.b("lable_id", "=", lable.getLableID()));
        addPicture(assets);
    }

    public void addPicture(final List<MediaAsset> list_media)
    {
        ll_pic.removeAllViews();
        for (int i = 0; i < list_media.size(); i++)
        {

            //加载图片，并设置tag
            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.MATCH_PARENT, 0);
            lp.setMargins(25, 4, 0, 4);
            imageView.setLayoutParams(lp);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            x.image().bind(imageView, list_media.get(i).getFilepath());
            imageView.setTag(list_media.get(i).getFilepath());
            ll_pic.addView(imageView);
            final int finalIndex = i;
            imageView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    File file = new File(list_media.get(finalIndex).getFilepath());
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    if (Build.VERSION.SDK_INT < 24)
                        intent.setDataAndType(Uri.fromFile(file), "image/*");
                    else
                    {
                        intent.setData(FileProvider.getUriForFile(Activity_LableDetails.this, BuildConfig.APPLICATION_ID + ".provider", file));
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }
                    startActivity(intent);
                }
            });
        }
    }


    private void print()
    {
        if (!HPRTPrinterHelper.IsOpened())
        {
            Toast.makeText(this, getString(R.string.activity_main_tips), Toast.LENGTH_SHORT).show();
            return;
        }
        try
        {
            HPRTPrinterHelper.LanguageEncode = "GBK";
            HPRTPrinterHelper.RowSetX("5");//设置X坐标,只需设置一次
            HPRTPrinterHelper.RowSetBold("2");//字体加粗  1是倍数  只需设置一次
            HPRTPrinterHelper.Setlp("5", "2", "26");
            HPRTPrinterHelper.PrintData("  " + "\r\n");
            HPRTPrinterHelper.PrintData("统一编码:\r\n" + lable.getTraceNumber() + "\r\n");
            HPRTPrinterHelper.PrintData("地块名称:\r\n" + lable.getAreaname() + "\r\n");
            HPRTPrinterHelper.PrintData("邮编:" + lable.getPostCode() + "\r\n");
            HPRTPrinterHelper.Setlp("5", "0", "26");//s:字体这个是默认值。s1：字体大小。s2：设置的整行的行高。
            HPRTPrinterHelper.RowSetBold("1");//字体加粗  1是倍数  只需设置一次
            HPRTPrinterHelper.PrintData("采样时间:" + lable.getRegDate() + "\r\n");
            HPRTPrinterHelper.PrintData("采样深度:" + lable.getCollectDeep() + "cm" + "\r\n");
            HPRTPrinterHelper.PrintData("经纬度:" + "   ( " + lable.getLon() + " , " + lable.getLat() + " ) " + "\r\n");
            HPRTPrinterHelper.PrintData("海拔(米):" + lable.getHeight() + "\r\n");
            HPRTPrinterHelper.PrintData("采样人:" + (TextUtils.isEmpty(lable.getRegistrar()) ? "无" : lable.getRegistrar()) + "\r\n");
            HPRTPrinterHelper.PrintData("联系电话:" + (TextUtils.isEmpty(lable.getTelephone()) ? "无" : lable.getTelephone()) + "\r\n");
            HPRTPrinterHelper.PrintData("备注信息:" + (TextUtils.isEmpty(lable.getRemark()) ? "无" : lable.getRemark()) + "\r\n");
            HPRTPrinterHelper.PrintData("  " + "\r\n");
            HPRTPrinterHelper.RowSetX("0");
            if (lable.getHasUpload() == false)
            {
                lable.setHasprint(true);
                DBUtils.insertOrUpdateData(lable);
            }
            changePageContent();
        } catch (Exception e)
        {


        }


    }

    private void Print1()
    {
        if (!HPRTPrinterHelper.IsOpened())
        {
            Toast.makeText(this, getString(R.string.activity_main_tips), Toast.LENGTH_SHORT).show();
            return;
        } else
        {

            try
            {
//                Command： 文字的方向， 总的有两种：
//                HPRTPrinterHelper.TEXT： 水平。
//                HPRTPrinterHelper.TEXT270： 垂直。
//                Font： 字体点阵大小
//                1： 打印繁体字（24x24 或者 12x24， 视中英文而定。）
//                16： 16x16 或 8x16， 视中英文而定。
//                24： 24x24 或 12x24， 视中英文而定。
//                32： 32x32 或 16x32， 由 ID3 字体宽高各放大 2 倍。
//                X： 起始点的横坐标。
//                Y： 起始点的纵坐标。
//                Data： 文本数据。
//                N： 字体的特效(十进制/二进制)  1/0001 加粗 2/0010.反白 4/0100 倍宽 8/1000倍高  如想组合，相加即可
//                Iscenter： 是否居中。
//                True： 是。
//                False： 否。
//                Width： 要居中的范围。（Iscenter=true 时才生效） 单位： 8=1mm。
                PublicFunction PFun = new PublicFunction(getApplicationContext());
                String paper = PFun.ReadSharedPreferencesData("papertype");
                HPRTPrinterHelper.printAreaSize("0", "200", "200", "50", "1");
                HPRTPrinterHelper.PrintTextCPCL(HPRTPrinterHelper.TEXT, 24, "10", "10", lable.getAreaname(), 1, false, 0);
                if (paper.equals("1"))
                    HPRTPrinterHelper.Form();
                HPRTPrinterHelper.Print();
                HPRTPrinterHelper.printAreaSize("0", "200", "200", "50", "1");
                if (HPRTPrinterHelper.isHex)
                    HPRTPrinterHelper.PrintTextCPCL(HPRTPrinterHelper.TEXT, 24, "10", "10", lable.getCydnumber(), 1, false, 0);
                if (paper.equals("1"))
                    HPRTPrinterHelper.Form();
                HPRTPrinterHelper.Print();
                HPRTPrinterHelper.printAreaSize("0", "200", "200", "50", "1");
                HPRTPrinterHelper.PrintTextCPCL(HPRTPrinterHelper.TEXT, 24, "10", "10", lable.getRegDate(), 1, false, 0);
                if (paper.equals("1"))
                    HPRTPrinterHelper.Form();
                HPRTPrinterHelper.Print();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }


}
