package hc.gis.cetubao.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;

import org.w3c.dom.Text;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.Bean.AreaData;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/10.
 */

@ContentView(R.layout.activity_dialog_operation)
public class ActivityDialog_PointOperation extends Activity
{
    PointState pointState;
    String year;
    Lable lable;
    @ViewInject(R.id.tv_point_name)
    TextView tv_point_name;
    @ViewInject(R.id.tv_point_number)
    TextView tv_point_number;
    @ViewInject(R.id.ll_number)
    LinearLayout ll_number;
    @ViewInject(R.id.delete_point)
    TextView delete_point;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        x.view().inject(this);
        ActivityManager.getAppManager().addActivity(this);
        super.onCreate(savedInstanceState);
        initManager();
        this.pointState = (PointState) getIntent().getSerializableExtra("pointState");
        this.year = getIntent().getStringExtra("year");
        setView();

    }

    private void setView()
    {

        if(pointState.isZyd.equals("True")&&pointState.getHasUpload()==0)
        {
            delete_point.setVisibility(View.VISIBLE);
        }
        else
        {
            delete_point.setVisibility(View.GONE);
        }
        tv_point_name.setText(Utils.getFullName_Short_NoDot(pointState));
        tv_point_number.setText(TextUtils.isEmpty(pointState.getNewtybh())?pointState.getTybh():pointState.getNewtybh());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {

        if (isOutBond(event))
        {
            setResult(9999,new Intent().putExtra("refresh",false));
            ActivityManager.getAppManager().finishActivity(this);
        }
        return true;
    }

    private boolean isOutBond(MotionEvent event)
    {
        final int x = (int) event.getX();
        final int y = (int) event.getY();
        final int slop = ViewConfiguration.get(this).getScaledWindowTouchSlop();
        final View decorView = getWindow().getDecorView();
        return (x < -slop) || (y < -slop)
                || (x > (decorView.getWidth() + slop))
                || (y > (decorView.getHeight() + slop));
    }

    @Event(value = {R.id.ll_navi, R.id.ll_lable, R.id.ll_print,R.id.ll_data})
    private void operation(View view)
    {
        Intent intent;
        switch (view.getId())
        {
            case R.id.ll_navi:
                intent = new Intent(this, Activity_Navigation.class);
                intent.putExtra("pointState", pointState);
                startActivity(intent);
                break;
            case R.id.ll_lable:
                //intent = new Intent(this, Activity_LableHistory.class);
                intent = new Intent(this, Activity_LableWirte.class);
                //intent = new Intent(this, Activity_LablePrint.class);
                intent.putExtra("cydNumber", pointState.getCydNumber());
                intent.putExtra("pointState", pointState);
                startActivity(intent);
                break;
            case R.id.ll_print:
               //intent = new Intent(this, Activity_Lable.class);
                intent = new Intent(this, Activity_LableList.class);
                intent.putExtra("year", year);
                intent.putExtra("pointState", pointState);
                //intent.putExtra("lable", lable);
                startActivity(intent);
            break;
            case R.id.ll_data:
                intent = new Intent(this, Activity_AreaData.class);
                intent.putExtra("year", year);
                intent.putExtra("cydNumber", pointState.getCydNumber());
                startActivity(intent);
                break;
        }
    }


    @Override
    public void onBackPressed()
    {
        ActivityManager.getAppManager().finishActivity(this);
        super.onBackPressed();
    }

    @Event(R.id.delete_point)
    private void deletePointInfo(View view)
    {
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("是否删除该点").setPositiveButton("是", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                DBUtils.delPointInfo(pointState);
                setResult(9999,new Intent().putExtra("refresh",true));
                ActivityManager.getAppManager().finishActivity(ActivityDialog_PointOperation.this);
            }
        }).setNegativeButton("否",null).create();
        dialog.show();

    }

    private void initManager()
    {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        WindowManager.LayoutParams p = getWindow().getAttributes();  //获取对话框当前的参数值
        p.height = (int) (dm.heightPixels * 0.45);   //高度设置为屏幕的比例
        p.width = (int) (dm.widthPixels * 0.78);    //宽度设置为屏幕的比例
        p.alpha = 1.0f;      //设置本身透明度
        p.dimAmount = 0.6f;      //设置黑暗度
        getWindow().setAttributes(p);     //设置生效
        getWindow().setGravity(Gravity.CENTER);       //设置靠居中(宽高1比1的情况下用处不大)
    }
}
