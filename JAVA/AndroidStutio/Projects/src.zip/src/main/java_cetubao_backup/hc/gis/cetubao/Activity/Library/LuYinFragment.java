/*
 * Copyright 2013 - learnNcode (learnncode@gmail.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package hc.gis.cetubao.Activity.Library;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.Toast;

import hc.gis.cetubao.R;

import java.io.File;
import java.util.ArrayList;

public class LuYinFragment extends Fragment
{
	private ArrayList<String> mSelectedItems = new ArrayList<String>();
	private ArrayList<MediaModel> mGalleryModelList;
	private ListView audioListView;
	private View mView;
	private OnLuYinSelectedListener mCallback;
	private AudioListViewAdapter mImageAdapter;
	private Cursor mImageCursor;

	// Container Activity must implement this interface
	public interface OnLuYinSelectedListener
	{
		public void onLuYinSelected(int count);
	}

	@Override
	public void onAttach(Activity activity)
	{
		super.onAttach(activity);

		// This makes sure that the container activity has implemented
		// the callback interface. If not, it throws an exception
		try
		{
			mCallback = (OnLuYinSelectedListener) activity;
		} catch (ClassCastException e)
		{
			throw new ClassCastException(activity.toString() + " must implement OnLuYinSelectedListener");
		}
	}

	public LuYinFragment()
	{
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		if (mView == null)
		{
			mView = inflater.inflate(R.layout.view_list_layout_media_chooser, container, false);

			audioListView = (ListView) mView.findViewById(R.id.listViewFromMediaChooser);
			if (getArguments() != null)
			{
				initPhoneImages(getArguments().getString("name"));
			} else
			{
				initPhoneImages();
			}

		} else
		{
			((ViewGroup) mView.getParent()).removeView(mView);
			if (mImageAdapter == null || mImageAdapter.getCount() == 0)
			{
				Toast.makeText(getActivity(), getActivity().getString(R.string.no_media_file_available), Toast.LENGTH_SHORT).show();
			}
		}

		return mView;
	}

	private void initPhoneImages(String bucketName)
	{
		try
		{
			final String orderBy = MediaStore.Images.Media.DATE_TAKEN;
			String searchParams = null;
			String bucket = bucketName;
			searchParams = "bucket_display_name = \"" + bucket + "\"";

			final String[] columns = { MediaStore.Images.Media.DATA, MediaStore.Images.Media._ID };
			mImageCursor = getActivity().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, searchParams, null, orderBy + " DESC");

			setAdapter(mImageCursor);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private void initPhoneImages()
	{
		try
		{
			final String orderBy = MediaStore.Audio.Media.DATE_ADDED;
			final String[] columns = { MediaStore.Audio.Media.DATA, MediaStore.Audio.Media._ID };
			mImageCursor = getActivity().getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, columns, null, null, orderBy + " DESC");

			setAdapter(mImageCursor);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private void setAdapter(Cursor imagecursor)
	{
		if (imagecursor.getCount() > 0)
		{

			mGalleryModelList = new ArrayList<MediaModel>();

			for (int i = 0; i < imagecursor.getCount(); i++)
			{
				imagecursor.moveToPosition(i);
				int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Audio.Media.DATA);
				MediaModel galleryModel = new MediaModel(imagecursor.getString(dataColumnIndex).toString(), false);
				mGalleryModelList.add(galleryModel);
			}

			mImageAdapter = new AudioListViewAdapter(getActivity(), 0, mGalleryModelList, false);
			audioListView.setAdapter(mImageAdapter);
		} else
		{
			Toast.makeText(getActivity(), getActivity().getString(R.string.no_media_file_available), Toast.LENGTH_SHORT).show();
		}

		audioListView.setOnItemLongClickListener(new OnItemLongClickListener()
		{

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
			{
				AudioListViewAdapter adapter = (AudioListViewAdapter) parent.getAdapter();
				MediaModel galleryModel = (MediaModel) adapter.getItem(position);
				File file = new File(galleryModel.url);
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(Uri.fromFile(file), "audio/*");
				startActivity(intent);
				return true;
			}
		});

		audioListView.setOnItemClickListener(new OnItemClickListener()
		{

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				// update the mStatus of each category in the adapter
				AudioListViewAdapter adapter = (AudioListViewAdapter) parent.getAdapter();
				MediaModel galleryModel = (MediaModel) adapter.getItem(position);

				if (!galleryModel.status)
				{
					long size = MediaChooserConstants.ChekcMediaFileSize(new File(galleryModel.url.toString()), false);
					if (size != 0)
					{
						Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.file_size_exeeded) + "  " + MediaChooserConstants.SELECTED_IMAGE_SIZE_IN_MB + " " + getActivity().getResources().getString(R.string.mb), Toast.LENGTH_SHORT).show();
						return;
					}

					if ((MediaChooserConstants.MAX_MEDIA_LIMIT == MediaChooserConstants.SELECTED_MEDIA_COUNT))
					{
						if (MediaChooserConstants.SELECTED_MEDIA_COUNT < 2)
						{
							Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.max_limit_file) + "  " + MediaChooserConstants.SELECTED_MEDIA_COUNT + " " + getActivity().getResources().getString(R.string.file), Toast.LENGTH_SHORT).show();
							return;
						} else
						{
							Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.max_limit_file) + "  " + MediaChooserConstants.SELECTED_MEDIA_COUNT + " " + getActivity().getResources().getString(R.string.files), Toast.LENGTH_SHORT).show();
							return;
						}

					}
				}

				// inverse the status
				galleryModel.status = !galleryModel.status;

				adapter.notifyDataSetChanged();

				if (galleryModel.status)
				{
					mSelectedItems.add(galleryModel.url.toString());
					MediaChooserConstants.SELECTED_MEDIA_COUNT++;

				} else
				{
					mSelectedItems.remove(galleryModel.url.toString().trim());
					MediaChooserConstants.SELECTED_MEDIA_COUNT--;
				}

				if (mCallback != null)
				{
					mCallback.onLuYinSelected(mSelectedItems.size());
					Intent intent = new Intent();
					intent.putStringArrayListExtra("list", mSelectedItems);
					getActivity().setResult(Activity.RESULT_OK, intent);
				}

			}
		});
	}

	public ArrayList<String> getSelectedImageList()
	{
		return mSelectedItems;
	}

	public void addItem(String item)
	{
		if (mImageAdapter != null)
		{
			MediaModel model = new MediaModel(item, false);
			mGalleryModelList.add(0, model);
			mImageAdapter.notifyDataSetChanged();
		} else
		{
			initPhoneImages();
		}
	}
}
