package hc.gis.cetubao.Activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.Adapter.Adapter_CyLable;
import hc.gis.cetubao.Adapter.Decoration.NewsDecoration;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2018/4/9.
 */

@ContentView(R.layout.activity_cylable)
public class Activity_LableList extends MBaseActivity
{
    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;
    @ViewInject(R.id.tv_addlable)
    TextView tv_addlable;
    @ViewInject(R.id.title)
    LinearLayout title;
    @ViewInject(R.id.rl_item_cylable)
    RecyclerView rcv_item_cylable;
    @ViewInject(R.id.rl_list)
    RelativeLayout rl_list;
    Adapter_CyLable cyLableAdapter;
    PointState pointState;
    List<Lable> mLables;
    @ViewInject(R.id.rl_nolable)
    RelativeLayout rl_nolable;
    @ViewInject(R.id.rl_progress)
    LinearLayout rl_progress;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        x.view().inject(this);
        super.onCreate(savedInstanceState);
        pointState = (PointState) getIntent().getSerializableExtra("pointState");
        getDate();
    }

    private void initListen()
    {

//        cyLableAdapter.setOnItemClickListener(new Adapter_CyLable.OnItemClickListener()
//        {
//            @Override
//            public void onClick(int position)
//            {
//                Intent intent  = new Intent(Activity_LableList.this, Activity_LableHistory.class);
//                intent.putExtra("lableid",mLables.get(position).getLableID());
//                startActivity(intent);
//                //Toast.makeText(mContext,position+"",Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        cyLableAdapter.setOnItemLongClickListener(new Adapter_CyLable.OnItemLongClickListener()
//        {
//            @Override
//            public void onLongClick(int position)
//            {
//
//            }
//        });

    }

    private void initView()
    {
        rl_list.setVisibility(View.VISIBLE);
        cyLableAdapter = new Adapter_CyLable(this, mLables);
        rcv_item_cylable.setLayoutManager(new LinearLayoutManager(this));
        rcv_item_cylable.addItemDecoration(new NewsDecoration(1));
        rcv_item_cylable.setAdapter(cyLableAdapter);
        cyLableAdapter.notifyDataSetChanged();
        initListen();
    }

    @Event(value = {R.id.ll_exit, R.id.tv_addlable, R.id.title, R.id.rl_item_cylable, R.id.rl_list})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.ll_exit:
                finish();
                break;
            case R.id.tv_addlable:
                break;
            case R.id.title:
                break;
            case R.id.rl_item_cylable:
                break;
            case R.id.rl_list:
                break;
        }
    }

    public void getDate()
    {
        mLables = new ArrayList<>();
        rl_progress.setVisibility(View.VISIBLE);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("action", APPConfig.ACTION_GETALLCYDDATA);
         params.addQueryStringParameter("cydNumber", pointState.getCydNumber());
        params.setCacheMaxAge(1000 * 3);//默认使用10秒内的缓存
        x.http().get(params, new Callback.CacheCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                List<Lable> lables_local = DBUtils.getList(Lable.class, WhereBuilder.b("cydNumber", "=", pointState.getCydNumber()).and(WhereBuilder.b("hasUpload","=","0")), "regDate", true);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    mLables = JSON.parseArray(mResult.getResult(), Lable.class);
                    mLables.addAll(0, lables_local);
                    if (mLables.size() == 0)
                    {
                        rl_nolable.setVisibility(View.VISIBLE);
                        rl_progress.setVisibility(View.GONE);
                    } else
                    {
                        rl_nolable.setVisibility(View.GONE);
                        rl_progress.setVisibility(View.GONE);
                        initView();

                    }
                }
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.w("服务器错误", ex.toString());
                List<Lable> lables_local = DBUtils.getList(Lable.class, WhereBuilder.b("cydNumber", "=", pointState.getCydNumber()), "regDate", true);
                if(lables_local.size()==0)
                {
                    rl_nolable.setVisibility(View.VISIBLE);
                    rl_progress.setVisibility(View.GONE);
                }else
                {
                    mLables.addAll(0, lables_local);
                    rl_nolable.setVisibility(View.GONE);
                    rl_progress.setVisibility(View.GONE);
                    initView();
                }
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }

            @Override
            public boolean onCache(String result)
            {
                return false;
            }
        });
    }

}
