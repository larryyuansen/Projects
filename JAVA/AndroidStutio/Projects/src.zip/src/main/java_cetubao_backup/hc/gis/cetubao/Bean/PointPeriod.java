package hc.gis.cetubao.Bean;

/**
 * Created by Administrator on 2017/12/5.
 */

import java.io.Serializable;

/**
 * 采集计划 例:2016-2017
 */
public class PointPeriod implements Serializable
{
    public String  year;

    public String getYear()
    {
        return year;
    }

    public void setYear(String year)
    {
        this.year = year;
    }

    public String getCoun()
    {
        return coun;
    }

    public void setCoun(String coun)
    {
        this.coun = coun;
    }

    public String coun;




    public PointPeriod()
    {

    }

    @Override
    public String toString()
    {
        return year +"年";
    }
}
