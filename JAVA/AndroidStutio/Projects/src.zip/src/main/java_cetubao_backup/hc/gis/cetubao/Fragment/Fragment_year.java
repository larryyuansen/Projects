package hc.gis.cetubao.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.Adapter.Adapter_year;
import hc.gis.cetubao.Adapter.Decoration.NewsDecoration;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.PointPeriod;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2018/4/12.
 */
@ContentView(R.layout.fragmeng_year)
public class Fragment_year extends Fragment
{
    View mView;
    List<PointPeriod> list_period;
    static String year;
    @ViewInject(R.id.rcv_years)
    RecyclerView rcv_years;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mView = x.view().inject(this, inflater, container);
        rcv_years.addItemDecoration(new NewsDecoration(10));
        setYear();
        return mView;
    }


    @Override
    public void onHiddenChanged(boolean hidden)
    {
        super.onHiddenChanged(hidden);
       if(!hidden)
            setYear();
    }

    private void setYear()
    {
        RequestParams requestParams = new RequestParams(APPConfig.MainUrl);
        requestParams.addQueryStringParameter("action", "GetMaxMinYear");
        requestParams.addBodyParameter("areaID", DBUtils.getCurrentUser().getAreaID());
        requestParams.addBodyParameter("areaLevel", DBUtils.getCurrentUser().getUserlevel());
        x.http().get(requestParams, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                    setYear(mResult.getResult());
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.i("sync_error",ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });
    }

    /**
     * 设置年份区间
     *{"ResultCode": 200,"Exception": null,"Result":[{"year":2017;"coun":15},{"year":2018;"coun":10}]}
     * @param json
     */
    public void setYear(String json)
    {
        try
        {
            list_period =  JSON.parseArray(json,PointPeriod.class);
            Adapter_year adapter_year = new Adapter_year(getActivity(),list_period);
            rcv_years.setLayoutManager(new LinearLayoutManager(getActivity()));
            rcv_years.setAdapter(adapter_year);
        }catch (Exception e)
        {
            Log.i("sync_error",e.toString());
        }



    }

}
