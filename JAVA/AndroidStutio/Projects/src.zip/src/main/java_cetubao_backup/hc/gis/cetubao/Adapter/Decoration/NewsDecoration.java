package hc.gis.cetubao.Adapter.Decoration;

import android.graphics.Rect;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by Administrator on 2017/12/5.
 */

public class NewsDecoration extends RecyclerView.ItemDecoration
{
    private int space;

    public NewsDecoration(int space)
    {
        this.space = space;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state)
    {
        LinearLayoutManager layoutManager = (LinearLayoutManager) parent.getLayoutManager();
        //竖直方向的
        if (layoutManager.getOrientation() == LinearLayoutManager.VERTICAL)
        {
            //最后一项需要 bottom
            outRect.bottom = space;
        } else
        {
            //最后一项需要right

            outRect.bottom = space;
        }
    }

}
