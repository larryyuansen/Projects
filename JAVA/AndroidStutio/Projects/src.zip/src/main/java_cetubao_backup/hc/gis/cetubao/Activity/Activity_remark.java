package hc.gis.cetubao.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2018/4/12.
 */

@ContentView(R.layout.activity_remark)
public class Activity_remark extends MBaseActivity
{

    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;
    @ViewInject(R.id.tv_finish)
    TextView tv_finish;
    @ViewInject(R.id.title)
    LinearLayout title;
    @ViewInject(R.id.et_remark)
    EditText et_remark;//定义一个文本输入框
  //  @ViewInject(R.id.tv_remakenum)
    TextView tv_remakenum;// 用来显示剩余字数
    String data;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {

        x.view().inject(this);
        et_remark.setInputType(InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        et_remark.setSingleLine(false);
        et_remark.setHorizontallyScrolling(false);
        data = getIntent().getStringExtra("remark");
        tv_remakenum = findViewById(R.id.tv_remakenum);
        et_remark.setText(data);
        tv_remakenum.setText("80");
        final int num = 80;//限制的最大字数
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        et_remark.addTextChangedListener(new TextWatcher()
        {
            private CharSequence temp;
            private int selectionStart;
            private int selectionEnd;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {
                temp = s;
                System.out.println("s="+s);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                int number = num - s.length();
                tv_remakenum.setText("" + number);
                selectionStart = et_remark.getSelectionStart();
                selectionEnd = et_remark.getSelectionEnd();
                //System.out.println("start="+selectionStart+",end="+selectionEnd);
                if (temp.length() > num) {
                    Toast.makeText(getApplicationContext(),"超过最大输入字数", Toast.LENGTH_SHORT).show();
                    s.delete(selectionStart - 1, selectionEnd);
                    int tempSelection = selectionStart;
                    et_remark.setText(s);
                    et_remark.setSelection(tempSelection);//设置光标在最后
                }


            }
        });
        super.onCreate(savedInstanceState);
    }

    @Event(value = {R.id.ll_exit, R.id.tv_finish, R.id.et_remark})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.ll_exit:
                setResult(RESULT_CANCELED);
                ActivityManager.getAppManager().finishActivity(this);
                break;
            case R.id.tv_finish:
                data = et_remark.getText().toString().trim();
                Intent intent = new Intent();
                intent.putExtra("remark",data);
                setResult(RESULT_OK,intent);
                ActivityManager.getAppManager().finishActivity(this);
                break;
            case R.id.et_remark:
                break;
        }
    }
}
