package hc.gis.cetubao.Fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdate;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;

import org.xutils.common.Callback;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Activity.ActivityDialog_CiitySelect;
import hc.gis.cetubao.Activity.ActivityDialog_PointOperation;
import hc.gis.cetubao.Activity.Activity_Main;
import hc.gis.cetubao.Adapter.Adapter_Point;
import hc.gis.cetubao.Adapter.Decoration.NewsDecoration;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.PointPeriod;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.MarkerDrawUtils;
import hc.gis.cetubao.Other.MyList;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;

import static hc.gis.cetubao.APP.APPConfig.ACTION_CHANGE_MAINPAGE;

/**
 * Created by Administrator on 2017/12/3.
 */
public class Fragment_Point extends Fragment implements View.OnClickListener
{
    View mView;
    AMap aMap;
    MapView mapView;
    /**
     * 切换影像图
     */
    Button btn_image;
    /**
     * 定位我的位置
     */
    Button btn_select_mode;//地图选点模式开关
    Button btn_location;

    Button btn_flash;
    /**
     * 地图的UI设置
     */
    UiSettings mUisettings;
    /**
     * 用于移动地图中心
     */
    CameraUpdate mCameraUpdate;
    TextView tv_city_name, tv_hasSampling, tv_total;
    TextView tv_town;
    Spinner sp_state;
    /**
     * 采集计划
     */
    MyList<PointPeriod> list_period;
    /**
     * 样点总列表
     */
    List<PointState> list_pointstate;
    /**
     * 当前显示列表
     */
    List<PointState> list_pointstate_show;
    // 已采集和未采集列表
    List<PointState> list_pointstate_hasSampling = new ArrayList<>(), list_pointstate_noSampling = new ArrayList<>();
    static int hasSampling;
    public static String year;
    ArrayList<MarkerOptions> markerOptions;//点标记集合
    ArrayList<Marker> markers;//地图标集合
    AMap.InfoWindowAdapter infoWindowAdapter;//设置点击事件的适配器
    LinearLayout ll_couting, ll_NoSampling, ll_HasSampling, ll_marker_tip, ll_back, ll_couting_zyd, ll_couting_gdd;
    RelativeLayout rl_list;//查看点列表
    FrameLayout layout_map;
    ScrollView scv_point_list;
    RelativeLayout rl_map;
    RecyclerView rcv_noSampling, rcv_hasSampling;
    TextView tv_points_noSampling, tv_points_hasSampling, tv_tip_hide, tv_tip_hide2, tv_hasdata_gdd, tv_hasdata_zyd, tv_nodata_gdd, tv_nodata_zyd;
    Adapter_Point adapter_HasSampling, adapter_NoSampling;
    Boolean isSelectMode = false;
    PointState pointState_Custom;
    boolean isFirst;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mView = inflater.inflate(R.layout.fragment_point, container, false);
        mapView = mView.findViewById(R.id.mapview);
        mapView.onCreate(savedInstanceState);
        if (mapView != null)//首先初始化地图
        {
            if (aMap == null)
            {
                aMap = mapView.getMap();
            }
        }
        initView();
        initMapSetting();
        initData();
        setListener();
        drawPoint(null);
        sp_state.setSelection(MApplication.mainSp.getInt("index_state", 0));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(receiver, new IntentFilter(APPConfig.ACTION_CHANGE_MAINPAGE));
        x.view().inject(this, mView);
        return mView;
    }


    private void initView()
    {
        tv_hasdata_gdd = mView.findViewById(R.id.tv_hasdata_gdd);
        tv_hasdata_zyd = mView.findViewById(R.id.tv_hasdata_zyd);
        tv_nodata_zyd = mView.findViewById(R.id.tv_nodata_zyd);
        tv_nodata_gdd = mView.findViewById(R.id.tv_nodata_gdd);
        ll_couting = mView.findViewById(R.id.ll_couting);
        ll_couting_gdd = mView.findViewById(R.id.ll_count_gdd);
        ll_couting_zyd = mView.findViewById(R.id.ll_count_zyd);
        btn_image = mView.findViewById(R.id.btn_image);
        btn_location = mView.findViewById(R.id.btn_location);
        tv_hasSampling = mView.findViewById(R.id.tv_hasSampling);
        tv_total = mView.findViewById(R.id.tv_total);
        tv_town = mView.findViewById(R.id.tv_town);
        ll_marker_tip = mView.findViewById(R.id.ll_marker_tip);
        sp_state = mView.findViewById(R.id.sp_state);
        rl_list = mView.findViewById(R.id.rl_list);
        rl_map = mView.findViewById(R.id.rl_map);
        ll_back = mView.findViewById(R.id.ll_back);
        layout_map = mView.findViewById(R.id.layout_map);
        scv_point_list = mView.findViewById(R.id.scv_point_list);
        rcv_hasSampling = mView.findViewById(R.id.rcv_hasSampling);
        rcv_noSampling = mView.findViewById(R.id.rcv_noSampling);
        tv_points_hasSampling = mView.findViewById(R.id.tv_points_hasSampling);
        tv_points_noSampling = mView.findViewById(R.id.tv_points_noSampling);
        ll_NoSampling = mView.findViewById(R.id.ll_nosampling);
        ll_HasSampling = mView.findViewById(R.id.ll_hasSampling);
        tv_tip_hide = mView.findViewById(R.id.tv_tip_hide);
        tv_tip_hide2 = mView.findViewById(R.id.tv_tip_hide2);
        btn_flash = mView.findViewById(R.id.btn_flash);
        btn_select_mode = mView.findViewById(R.id.btn_select_mode);
        btn_image.setOnClickListener(this);
        btn_location.setOnClickListener(this);
        tv_town.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(getActivity(), ActivityDialog_CiitySelect.class);
                String id = DBUtils.getCurrentUser().getAreaID();
                intent.putExtra("parentid", id);
                startActivityForResult(intent, 101);
            }
        });
        btn_select_mode.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                isSelectMode = !isSelectMode;
                if (isSelectMode)
                {
                    Snackbar.make(rl_map, "请在地图上点击或长按自采点的位置", Snackbar.LENGTH_INDEFINITE).show();
                    btn_select_mode.setCompoundDrawablesWithIntrinsicBounds(null, ActivityCompat.getDrawable(getActivity(), R.drawable.gis_cyd2), null, null);
                    btn_select_mode.setSelected(true);
                } else
                {
                    Snackbar.make(rl_map, "退出采点模式", Snackbar.LENGTH_LONG).show();
                    btn_select_mode.setCompoundDrawablesWithIntrinsicBounds(null, ActivityCompat.getDrawable(getActivity(), R.drawable.gis_cyd1), null, null);
                    btn_select_mode.setSelected(false);
                }
            }
        });
        ll_back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(APPConfig.ACTION_CHANGE_MAINPAGE);
                intent.putExtra("pageindex", 0);
                intent.putExtra("isFirst",true);
                LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
            }
        });

        btn_flash.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                drawPoint(null);
            }
        });
    }

    /**
     * 发送请求获取当前选择的区域所有的点信息
     */
    private void getPoint()
    {
        if (MApplication.area_Points == null)
            return;
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        //  params.addQueryStringParameter("action", APPConfig.ACTION_GETAllCYD);
        params.addQueryStringParameter("action", APPConfig.Get_AllCYD_BYLEVEL);
        params.addBodyParameter("year", year);
        //去掉是否有数据的参数，统一拿到所有点然后本地根据是否有采集做拆分
        //     if (hasSampling != -1)
//            params.addBodyParameter("hasSampling", hasSampling + "");
        params.addBodyParameter("User_AreaID", DBUtils.getCurrentUser().getAreaID());
        params.addBodyParameter("ID", MApplication.area_Points.getId());
        params.addBodyParameter("Level", (Integer.valueOf(MApplication.area_Points.getArealevel()) + 1) + "");
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {

                    if (list_pointstate != null && list_pointstate.size() != 0)
                        list_pointstate.clear();
                    list_pointstate = JSON.parseArray(mResult.getResult(), PointState.class);
                    list_pointstate_hasSampling.clear();
                    list_pointstate_show.clear();
                    list_pointstate_noSampling.clear();
                    drawPoint(null);
                }
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.i("sync_error", ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {
                Log.i("sync_error", cex.toString());
            }

            @Override
            public void onFinished()
            {

            }


        });
    }

    boolean isShowList = false;

    /**
     * 切换样点视图
     *
     * @param islist     是否列表
     * @param pointState 是否需要跳转
     */
    public void switchContent(boolean islist, @Nullable PointState pointState)
    {

        if (islist && !isShowList)
        {
            mapView.onPause();
            isShowList = true;
            layout_map.setVisibility(View.GONE);
            scv_point_list.setVisibility(View.VISIBLE);
            sp_state.setVisibility(View.GONE);
            rl_list.setVisibility(View.GONE);
            rl_map.setVisibility(View.VISIBLE);
            hasSampling = -1;
            initList();

        }
        if (!islist)
        {

            isShowList = false;
            mapView.onResume();
            layout_map.setVisibility(View.VISIBLE);
            rl_list.setVisibility(View.VISIBLE);
            rl_map.setVisibility(View.GONE);
            sp_state.setVisibility(View.VISIBLE);
            scv_point_list.setVisibility(View.GONE);
            drawPoint(pointState);
        }
    }

    private void initList()
    {
        adapter_HasSampling.notifyDataSetChanged();
        adapter_NoSampling.notifyDataSetChanged();
        tv_points_hasSampling.setText(getString(R.string.hasSampling) + "(" + list_pointstate_hasSampling.size() + ")");
        tv_points_noSampling.setText(getString(R.string.noSampling) + "(" + list_pointstate_noSampling.size() + ")");
    }


    private void setListener()
    {

        sp_state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                switch (position)
                {
                    case 0://全部
                        hasSampling = -1;
                        break;
                    case 1://未采
                        hasSampling = 0;
                        break;
                    case 2:
                        hasSampling = 1;
                        break;//已采集
                }
                getPoint();
                MApplication.mainSp.edit().putInt("index_state", position).commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        rl_list.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switchContent(true, null);

            }
        });
        rl_map.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switchContent(false, null);
            }
        });
        ll_NoSampling.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                rcv_noSampling.setVisibility(rcv_noSampling.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                tv_tip_hide.setText(rcv_noSampling.getVisibility() == View.VISIBLE ? R.string.click_hide : R.string.click_show);
            }
        });
        ll_HasSampling.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                rcv_hasSampling.setVisibility(rcv_hasSampling.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                tv_tip_hide2.setText(rcv_hasSampling.getVisibility() == View.VISIBLE ? R.string.click_hide : R.string.click_show);

            }
        });
    }

    private void initData()
    {
        list_pointstate = new ArrayList<>();
        list_pointstate_show = new ArrayList<>();
        markers = new ArrayList<>();
        markerOptions = new ArrayList<>();

        tv_town.setText(MApplication.area_Points == null ? "" : MApplication.area_Points.getAreaName());//如果SP里有上次显示的区域信息则显示
        String[] array_point_state = getActivity().getResources().getStringArray(R.array.array_poiont_state);//三个状态
        ArrayAdapter<String> adapter_state = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, array_point_state);
        sp_state.setAdapter(adapter_state);

        adapter_NoSampling = new Adapter_Point(this, list_pointstate_noSampling);
        adapter_HasSampling = new Adapter_Point(this, list_pointstate_hasSampling);
        rcv_noSampling.setAdapter(adapter_NoSampling);
        rcv_noSampling.setLayoutManager(new LinearLayoutManager(getActivity()));
        rcv_noSampling.addItemDecoration(new NewsDecoration(1));
        rcv_hasSampling.setAdapter(adapter_HasSampling);
        rcv_hasSampling.setLayoutManager(new LinearLayoutManager(getActivity()));
        rcv_hasSampling.addItemDecoration(new NewsDecoration(1));
    }


    private void initMapSetting()
    {

        MyLocationStyle myLocationStyle;
        myLocationStyle = new MyLocationStyle();//初始化定位蓝点样式类myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE);//连续定位、且将视角移动到地图中心点，定位点依照设备方向旋转，并且会跟随设备移动。（1秒1次定位）如果不设置myLocationType，默认也会执行此种模式。
        myLocationStyle.interval(2000); //设置连续定位模式下的定位间隔，只在连续定位模式下生效，单次定位模式下不会生效。单位为毫秒。
        myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE_NO_CENTER);
        myLocationStyle.anchor(0.5f, 0.5f);//图标偏移，箭头图标中心点不在圆的中心，所有做了一个偏移
        myLocationStyle.myLocationIcon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.icon_myself)));
        aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
        aMap.setMyLocationEnabled(true);// 设置为true表示启动显示定位蓝点，false表示隐藏定位蓝点并不进行定位，默认是false。
        mUisettings = aMap.getUiSettings();
        mUisettings.setCompassEnabled(true);
        mUisettings.setScaleControlsEnabled(true);
        mUisettings.setTiltGesturesEnabled(false);//设置禁止倾斜
        mUisettings.setRotateGesturesEnabled(false);//设置禁止旋转
        //参数依次是：视角调整区域的中心点坐标、希望调整到的缩放级别、俯仰角0°~45°（垂直与地图时为0）、偏航角 0~360° (正北方为0)
        mCameraUpdate = CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(MApplication.lat, MApplication.lng), 18, 0, 0));
        aMap.moveCamera(mCameraUpdate);
        infoWindowAdapter = new AMap.InfoWindowAdapter()
        {
            @Override
            public View getInfoWindow(Marker marker)
            {
                View custInfowindow = LayoutInflater.from(getActivity()).inflate(R.layout.layout_point_info, null);
                TextView textView = custInfowindow.findViewById(R.id.tv_title);
                textView.setText(marker.getTitle());
                return custInfowindow;
            }

            @Override
            public View getInfoContents(Marker marker)
            {
                return null;
            }
        };
        aMap.setOnMarkerClickListener(new AMap.OnMarkerClickListener()
        {
            @Override
            public boolean onMarkerClick(Marker marker)
            {
                for (PointState pointState : list_pointstate_show)
                {
                    if (TextUtils.equals(pointState.getCydNumber(), marker.getSnippet()))
                    {
                        Intent intent = new Intent(getActivity(), ActivityDialog_PointOperation.class);
                        intent.putExtra("pointState", pointState);
                        intent.putExtra("year", year);
                        startActivityForResult(intent, 9999);
                        break;
                    }
                }


                return true;
            }
        });
        aMap.setInfoWindowAdapter(infoWindowAdapter);
        aMap.setOnMapLongClickListener(new AMap.OnMapLongClickListener()
        {
            @Override
            public void onMapLongClick(final LatLng latLng)
            {
                AlertDialog dialog = new AlertDialog.Builder(getActivity())
                        .setTitle("提示")
                        .setMessage("是否在此处添加自采点")
                        .setPositiveButton("是", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                dialog.dismiss();
                                addNewPoin(latLng);
                            }
                        }).setNegativeButton("否", null).create();
                dialog.show();

            }
        });
        aMap.setOnMapClickListener(new AMap.OnMapClickListener()
        {
            @Override
            public void onMapClick(final LatLng latLng)
            {
                if (!isSelectMode)
                {
                    return;
                }
                AlertDialog dialog = new AlertDialog.Builder(getActivity())
                        .setTitle("提示")
                        .setMessage("是否在此处添加自采点")
                        .setPositiveButton("是", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                dialog.dismiss();
                                addNewPoin(latLng);
                            }
                        }).setNegativeButton("否", null).create();


                dialog.show();
            }
        });

    }

    private void addNewPoin(LatLng latLng)
    {
        LatLng latlng_click = MarkerDrawUtils.GCJ2WGS.delta(latLng.latitude, latLng.longitude);
        PointState pointstate_near = null;

        if (list_pointstate_show.size() != 0)
        {
            pointstate_near = list_pointstate_show.get(0);
        } else
        {
            Toast.makeText(getActivity(), "请先从服务器添加固定点！", Toast.LENGTH_LONG).show();
            return;
        }
        pointState_Custom = new PointState();
        pointState_Custom.setCydNumber(Utils.getUUID());
        pointState_Custom.setProvinceName(pointstate_near.getProvinceName());
        pointState_Custom.setCityName(pointstate_near.getCityName());
        pointState_Custom.setTownName(pointstate_near.getTownName());
        pointState_Custom.setCountyName(pointstate_near.getCountyName());
        pointState_Custom.setVillageName(pointstate_near.getVillageName());
        pointState_Custom.setCreatDate(Utils.getDate(true));
        pointState_Custom.setCreatorID(DBUtils.getCurrentUser().getId());
        pointState_Custom.setCityID(pointstate_near.getCityID());
        pointState_Custom.setCountyID(pointstate_near.getCountyID());
        pointState_Custom.setTownID(pointstate_near.getTownID());
        pointState_Custom.setArea(pointstate_near.getArea());
        pointState_Custom.setAreaID(pointstate_near.getAreaID());
        pointState_Custom.setProvinceid(pointstate_near.getProvinceid());
        pointState_Custom.setIsDeleted("0");
        pointState_Custom.setNhName("自采点");
        pointState_Custom.setDistance(pointstate_near.getDistance());
        pointState_Custom.setStartYear(pointstate_near.getStartYear());
        pointState_Custom.setHasSampling("0");
        pointState_Custom.setIsZyd("True");
        pointState_Custom.setCydName("自采点");
        pointState_Custom.setLat(latlng_click.latitude + "");
        pointState_Custom.setLon(latlng_click.longitude + "");
        pointState_Custom.setUnitCode(pointstate_near.getUnitCode());
        pointState_Custom.setPostCode(pointstate_near.getPostCode());
        pointState_Custom.setVillageID(pointstate_near.getVillageID());
        pointState_Custom.setCydArea("自采点");
        pointState_Custom.setRegDate(Utils.getDate(true));
        pointState_Custom.setHasUpload(0);
        pointState_Custom.setTybh(Utils.getUUID());
        pointState_Custom.setCjrmc(DBUtils.getCurrentUser().getRealName());
        DBUtils.insertOrUpdateData(pointState_Custom);
        //上传自采点
        // uploadPoint(pointState_Custom);
        isAddOrDelPoint = true;
        getPoint();
        //新添加的点

    }
drawTask drawTask;
    private void drawPoint(@Nullable PointState pointState)
    {


        drawTask = new drawTask();//多线程读写arraylist会出现数组越界，故暂时用异步任务类代替手写线程，后期会修改
        drawTask.execute(pointState);
    }


    @Override
    public void onDestroy()
    {

        super.onDestroy();
        mapView.onDestroy();
        drawTask.cancel(true);
    }


    @Override
    public void onPause()
    {

        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onSaveInstanceState(Bundle outState)
    {

        mapView.onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }


    @Override
    public void onHiddenChanged(boolean hidden)
    {
        if (hidden)
        {
            mapView.onPause();
            if(isSelectMode)
                btn_select_mode.callOnClick();
        }
            else
            mapView.onResume();
        super.onHiddenChanged(hidden);
    }



    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.btn_image:
                if (aMap.getMapType() == AMap.MAP_TYPE_NORMAL)
                    aMap.setMapType(AMap.MAP_TYPE_SATELLITE);
                else
                    aMap.setMapType(AMap.MAP_TYPE_NORMAL);
                break;
            case R.id.btn_location:
                mCameraUpdate = CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(MApplication.lat, MApplication.lng), 18, 0, 0));
                aMap.moveCamera(mCameraUpdate);
                break;
        }
    }

    /**
     * 此处是让承载这个fragment的{@link Activity_Main}调用，更新使用者所在区域的城市名
     *
     * @param name
     */
    public void setLocationName(String name)
    {

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101)//当选择完城市列表后
        {
            if (resultCode == Activity.RESULT_OK)
            {
                String area = JSON.toJSONString(MApplication.area_Points).toString();
                MApplication.mainSp.edit().putString("area", area).commit();
                tv_town.setText(data.getStringExtra("townName"));
                getPoint();
            }
        }
        if (requestCode == 9999)
        {
            if (requestCode == 9999)
            {
                if (null != data && data.getBooleanExtra("refresh", false))
                {
                    isAddOrDelPoint = true;
                    getPoint();
                }
            }
        }
    }

    /**
     * 标记符，判断是否是添加或删除自采点引发的刷新，为true时则不会将地图缩放到能显示所有点
     * 添加/删除自采点后变为true，点列表刷新完成后自动改为false
     */
    Boolean isAddOrDelPoint = false;

    /**
     * 此处异步第一个参数不选择空的原因是用于在列表页面,点击某个样点后传入该样点的信息用于地图跳转，其他场合传空也可正常使用
     */
    class drawTask extends AsyncTask<PointState,Void,Void>
    {
        PointState pointState;

        @Override
        protected void onPreExecute()
        {
            List<PointState> pointStates_custom = new ArrayList<>();
            list_pointstate_hasSampling.clear();
            list_pointstate_noSampling.clear();
            list_pointstate_show.clear();
            list_pointstate_show.addAll(list_pointstate);
            if (list_pointstate_show.size() != 0)
                pointStates_custom = DBUtils.getList(PointState.class, WhereBuilder.b("isZyd", "=", "True").and("villageID", "=", list_pointstate_show.get(0).getVillageID()).and("hasUpload", "=", "0"));
            list_pointstate_show.addAll(pointStates_custom);
            for (PointState pointstate : list_pointstate_show)
            {
                if (pointstate.getHasSampling().equals("1"))
                {
                    list_pointstate_hasSampling.add(pointstate);
                } else
                    list_pointstate_noSampling.add(pointstate);
            }


            if (hasSampling == -1)
            {
                ll_couting_gdd.setVisibility(View.VISIBLE);
                ll_couting_zyd.setVisibility(View.VISIBLE);
                int zyd_has = 0, zyd_no = 0, gdd_has = 0, gdd_no = 0;
                for (PointState pointState : list_pointstate_show)
                {
                    if (pointState.getHasSampling().equals("1"))//含数据
                    {
                        if (pointState.getIsZyd().equals("1") || pointState.getIsZyd().equals("True") || pointState.getIsZyd().equals("true"))
                            zyd_has++;//自采点
                        else
                            gdd_has++;//固定点
                    } else//不含数据
                    {
                        if (pointState.getIsZyd().equals("1") || pointState.getIsZyd().equals("True") || pointState.getIsZyd().equals("true"))
                            zyd_no++;//自采点
                        else
                            gdd_no++;//固定点
                    }
                }
                tv_hasdata_zyd.setText("" + zyd_has);
                tv_nodata_zyd.setText("" + zyd_no);
                tv_hasdata_gdd.setText("" + gdd_has);
                tv_nodata_gdd.setText("" + gdd_no);
            } else
            {
                ll_couting_gdd.setVisibility(View.GONE);
                ll_couting_zyd.setVisibility(View.GONE);
            }
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(PointState... params)
        {
            if(null==getActivity())
                return null;
            if (null != params[0])//当第一个参数不为空，也就是需要地图跳转时赋值,然后在onPostExecute中地图绘制完成后跳转
                pointState = params[0];
            if (null != markerOptions && markerOptions.size() != 0)
                markerOptions.clear();
            if (hasSampling == -1)
            {
                for (int i = 0; i < list_pointstate_show.size(); i++)
                {
                    markerOptions.add(MarkerDrawUtils.getMarkerByState(list_pointstate_show.get(i), getActivity()));
                }
            } else
            {
                if (hasSampling == 1)
                    for (int i = 0; i < list_pointstate_hasSampling.size(); i++)
                    {
                        markerOptions.add(MarkerDrawUtils.getMarkerByState(list_pointstate_hasSampling.get(i), getActivity()));
                    }
                else if (hasSampling == 0)
                    for (int i = 0; i < list_pointstate_noSampling.size(); i++)
                    {
                        markerOptions.add(MarkerDrawUtils.getMarkerByState(list_pointstate_noSampling.get(i), getActivity()));
                    }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {
            if(null==getActivity())
                return;
            aMap.clear(true);
            if (null != markers && markers.size() != 0)
                markers.clear();
            if (!isAddOrDelPoint)
                markers = aMap.addMarkers(markerOptions, null == pointState);
            else
            {
                markers = aMap.addMarkers(markerOptions, false);
                isAddOrDelPoint = false;
            }
            if (isShowList)//如果是列表视图，则同时更新列表
            {
                initList();
            }
            if (null != pointState)
            {
                CameraUpdate nCameraUpdate = CameraUpdateFactory.newCameraPosition(new CameraPosition(MarkerDrawUtils.convertPoint(Double.valueOf(pointState.getLat()), Double.valueOf(pointState.getLon()), getActivity()), 18, 0, 0));
                aMap.moveCamera(nCameraUpdate);
            }
            super.onPostExecute(aVoid);
        }
    }


    BroadcastReceiver receiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if (intent.getAction().equals(ACTION_CHANGE_MAINPAGE))
            {
                year = intent.getStringExtra("year");
                isFirst = intent.getBooleanExtra("isFirst",false);
                getPoint();
                MApplication.mainSp.edit().putString("last_year", year).commit();
            }
        }
    };

    //上传点
    String TAG = "option_load";

    private void uploadPoint(final PointState pointState_Custom_1)
    {
        //final List<PointState> pointStates = DBUtils.getList(PointState.class, WhereBuilder.b("hasUpload", "=", 0).and("creatorID","=",DBUtils.getCurrentUser().getId()));
        List<PointState> pointStates = new ArrayList<>();
        pointStates.add(pointState_Custom_1);
        String point_json = JSON.toJSONString(pointStates);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addBodyParameter("action", "InsertZyCyd");
        params.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
        params.addBodyParameter("json", point_json);
        params.setConnectTimeout(1000 * 30);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                Log.i(TAG, "onSuccess: " + result);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if (result.indexOf("\"Result\":true") != -1)
                    {
                        pointState_Custom_1.setHasUpload(1);
                        DBUtils.insertOrUpdateData(pointState_Custom_1);
                    }
                }

            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {

                Log.i(TAG, "onError: " + ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });

    }

}
