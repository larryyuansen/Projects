package hc.gis.cetubao.Activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.TextView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/10.
 */

@ContentView(R.layout.activity_dialog_choosecontacts)
public class ActivityDialog_ChooseContacts extends Activity
{
    PointState pointState;
    String year;
    Lable lable;
    @ViewInject(R.id.tv_zxlxr)
    TextView tv_zxlxr;
    @ViewInject(R.id.tv_bdlxr)
    TextView tv_bdlxr;

    private static final int CHOOSECONTACTS = 997;
    private static final int LOCALCONTACTS = 996;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        x.view().inject(this);
        ActivityManager.getAppManager().addActivity(this);
        super.onCreate(savedInstanceState);
        initManager();

    }


    @Override
    public boolean onTouchEvent(MotionEvent event)
    {

        if (isOutBond(event))
        {
            ActivityManager.getAppManager().finishActivity(this);
        }
        return true;
    }

    private boolean isOutBond(MotionEvent event)
    {
        final int x = (int) event.getX();
        final int y = (int) event.getY();
        final int slop = ViewConfiguration.get(this).getScaledWindowTouchSlop();
        final View decorView = getWindow().getDecorView();
        return (x < -slop) || (y < -slop)
                || (x > (decorView.getWidth() + slop))
                || (y > (decorView.getHeight() + slop));
    }


    @Override
    public void onBackPressed()
    {
        ActivityManager.getAppManager().finishActivity(this);
        super.onBackPressed();
    }


    private void initManager()
    {
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay();  //为获取屏幕宽、高
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        WindowManager.LayoutParams p = getWindow().getAttributes();  //获取对话框当前的参数值
        p.height = (int) (dm.heightPixels * 0.35);   //高度设置为屏幕的比例
        p.width = (int) (dm.widthPixels * 0.70);    //宽度设置为屏幕的比例
        p.alpha = 1.0f;      //设置本身透明度
        p.dimAmount = 0.6f;      //设置黑暗度
        getWindow().setAttributes(p);     //设置生效
        getWindow().setGravity(Gravity.CENTER);       //设置靠居中(宽高1比1的情况下用处不大)
    }
 
    @Event(value = {R.id.tv_zxlxr, R.id.tv_bdlxr})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.tv_zxlxr:
                Intent intent = new Intent(ActivityDialog_ChooseContacts.this, Activity_LocalContacts.class);
                //startActivity(intent);
                startActivityForResult(intent, LOCALCONTACTS);
                break;
            case R.id.tv_bdlxr:
                startActivityForResult(new Intent(Intent.ACTION_PICK,
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI), CHOOSECONTACTS);
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch (requestCode)
        {
            case CHOOSECONTACTS:
                if (resultCode == RESULT_OK)
                {
                    // ContentProvider展示数据类似一个单个数据库表
                    // ContentResolver实例带的方法可实现找到指定的ContentProvider并获取到ContentProvider的数据
                    ContentResolver reContentResolverol = getContentResolver();
                    // URI,每个ContentProvider定义一个唯一的公开的URI,用于指定到它的数据集
                    Uri contactData = data.getData();
                    // 查询就是输入URI等参数,其中URI是必须的,其他是可选的,如果系统能找到URI对应的ContentProvider将返回一个Cursor对象.
                    Cursor cursor = reContentResolverol.query(contactData, null, null, null, null);

                    if (null != cursor && cursor.moveToFirst())
                    {
                        int nameFieldIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        String name = cursor.getString(nameFieldIndex);
                        int phoneFieldindex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                        String phone = cursor.getString(phoneFieldindex);
                        // Intent intent = new Intent(ActivityDialog_ChooseContacts.this,Activity_LableWirte.class);
                        Intent intent = new Intent();
                        intent.putExtra("name", name);
                        intent.putExtra("phone", phone);
                        setResult(RESULT_OK, intent);
                        ActivityManager.getAppManager().finishActivity(this);
                    }

                    cursor.close();
                }

            case LOCALCONTACTS:
                if (data == null)
                {
                    ActivityManager.getAppManager().finishActivity(this);
                    return;
                } else
                {
                    String phone = data.getStringExtra("phone");
                    String name = data.getStringExtra("name");
                    //Intent intent = new Intent(ActivityDialog_ChooseContacts.this,Activity_LableWirte.class);
                    Intent intent = new Intent();
                    intent.putExtra("name", name);
                    intent.putExtra("phone", phone);
                    setResult(RESULT_OK, intent);
                    ActivityManager.getAppManager().finishActivity(this);
                }
             }
        }
}
