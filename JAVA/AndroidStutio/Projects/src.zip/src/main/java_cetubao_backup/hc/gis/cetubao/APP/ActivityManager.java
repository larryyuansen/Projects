package hc.gis.cetubao.APP;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import com.alibaba.fastjson.JSON;

import org.xutils.db.sqlite.WhereBuilder;

import java.io.File;
import java.util.Stack;

import hc.gis.cetubao.Activity.Activity_Login;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.DB.DBUtils;

/**
 * Created by Administrator on 2017/1/19.
 */

/**
 * Activity管理器
 */
public class ActivityManager
{
    private static  ActivityManager manager;
    private static Stack<Activity> stack;
    private ActivityManager()
    {
    }

    /**
     * 单例
     */
    public static ActivityManager getAppManager()
    {
        if (manager == null)
        {
            manager = new ActivityManager();
        }
        return manager;
    }




    public void addActivity(Activity activity)
    {
        if (stack == null)
        {
            stack = new Stack<Activity>();
        }
        stack.add(activity);
    }

    /**
     * 获取当前Activity（堆栈中最后一个压入的）
     */
    public Activity currentActivity()
    {
        Activity activity = stack.lastElement();
        return activity;
    }

    /**
     * 结束当前Activity（堆栈中最后一个压入的）
     */
    public void finishActivity()
    {
        Activity activity = stack.lastElement();
        finishActivity(activity);
    }

    /**
     * 结束指定的Activity
     */
    public void finishActivity(Activity activity)
    {
        if (activity != null)
        {
            stack.remove(activity);
            activity.finish();

        }
    }

    /**
     * 结束指定类名的Activity
     */
    public void finishActivity(Class<?> cls)
    {
        for (Activity activity : stack)
        {
            if (activity.getClass().equals(cls))
            {
                finishActivity(activity);
            }
        }
    }

    /**
     * 结束所有Activity
     */
    public void finishAllActivity()
    {
        MApplication.mainSp.edit().putString("lat", MApplication.lat + "").commit();
        MApplication.mainSp.edit().putString("lng", MApplication.lng + "").commit();
        if(!MApplication.mainSp.getBoolean("autoLogin",false))
        {
            DBUtils.signout();
        }
        DBUtils.DeleteTable(PointState.class, WhereBuilder.b("isZyd","=","0"));
        for (int i = 0, size = stack.size(); i < size; i++)
        {
            if (null != stack.get(i))
            {

                stack.get(i).finish();
            }
        }
        stack.clear();
        System.exit(0);
    }
    public void finishAllActivityWithout(Class<?> cls)
    {
        MApplication.mainSp.edit().putString("lat", MApplication.lat + "").commit();
        MApplication.mainSp.edit().putString("lng", MApplication.lng + "").commit();
        DBUtils.DeleteTable(PointState.class, WhereBuilder.b("isZyd","=","0"));
        for (int i = 0, size = stack.size(); i < size; i++)
        {
            if (null != stack.get(i))
            {
                if(cls.isInstance(stack.get(i)))
                {
                    continue;
                }
                stack.get(i).finish();
            }
        }
    }
}
