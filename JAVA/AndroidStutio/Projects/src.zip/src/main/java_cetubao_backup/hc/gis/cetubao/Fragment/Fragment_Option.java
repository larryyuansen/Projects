package hc.gis.cetubao.Fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.SpannableString;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Activity.Activity_Login;
import hc.gis.cetubao.Bean.AreaData;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.Bean.User;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/3.
 */
@ContentView(R.layout.fragment_option)
public class Fragment_Option extends Fragment
{
    View mView;
    @ViewInject(R.id.profile_image)
    CircleImageView profile_image;
    @ViewInject(R.id.tv_my_name)
    TextView tv_my_name;
    @ViewInject(R.id.ll_upload)
    LinearLayout ll_upload;
    @ViewInject(R.id.ll_satellite_state)
    LinearLayout ll_satellite_state;
    @ViewInject(R.id.textView)
    TextView textView;
    @ViewInject(R.id.ll_update)
    LinearLayout ll_update;
    @ViewInject(R.id.ll_about)
    LinearLayout ll_about;
    @ViewInject(R.id.ll_change_password)
    LinearLayout ll_change_password;
    @ViewInject(R.id.ll_signout)
    LinearLayout ll_signout;
    View view_content;
    AlertDialog tipDialog;
    User user;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mView = x.view().inject(this, inflater, container);
        initView();
        view_content =LayoutInflater.from(getActivity()).inflate(R.layout.dialog_upload_all,null);
        tipDialog = new AlertDialog.Builder(getActivity()).setMessage("").create();
        return mView;
    }

    private void initView()
    {
        user = DBUtils.getCurrentUser();
        tv_my_name.setText(user.getAreaName() + "\n" + user.getRealName());

    }

    @Event(R.id.ll_signout)
    private void signout(View view)
    {
        DBUtils.signout();
        MApplication.mainSp.edit().remove("area").commit();
        MApplication.area_Points = null;
        MApplication.mainSp.edit().remove("lastTownID").commit();
        MApplication.mainSp.edit().remove("lastVillageID").commit();
        ActivityManager.getAppManager().finishAllActivityWithout(Activity_Login.class);
    }



    TextView tv_upload,tv_result;
    Button btn_cancle;
    @Event(R.id.ll_upload)
    private void upload(View view)
    {

        tv_upload = view_content.findViewById(R.id.tv_upload);
        tv_result = view_content.findViewById(R.id.tv_result);
        btn_cancle = view_content.findViewById(R.id.btn_cancle);
        tv_result.setText("");
        btn_cancle.setText("");
        btn_cancle.setVisibility(View.GONE);
        tipDialog.setCanceledOnTouchOutside(false);
        tipDialog.show();
        Window window = tipDialog.getWindow();
        window.setContentView(view_content);
        window.setLayout(900,800);
        uploadPoint();

    }

    @Event(R.id.ll_about)
    private void about(View view)
    {
        String version;
        try
        {
            version = getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e)
        {
            e.printStackTrace();
            version = "1.0";
        }
        Dialog dialog = new AlertDialog.Builder(getActivity()).setMessage("当前版本：" + version).setNegativeButton("确定", null).create();
        dialog.show();
    }

    /**
     * 第一步，上传自采点
     */
    private void uploadPoint()
    {
        final List<PointState> pointStates = DBUtils.getList(PointState.class, WhereBuilder.b("hasUpload", "=", 0).and("creatorID", "=", DBUtils.getCurrentUser().getId()));
        if (pointStates.size() == 0)
        {

            tv_result.append(Utils.getSpannString("无采集点需要上传",Color.GREEN));
            uploadLables();
            return;
        }

        tv_result.append(Utils.getSpannString("采集点上传中...",Color.BLACK));
        String point_json = JSON.toJSONString(pointStates);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addBodyParameter("action", "InsertZyCyd");
        params.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
        params.addBodyParameter("json", point_json);
        params.setConnectTimeout(1000 * 30);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                Log.i(TAG, "onSuccess: " + result);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if (result.indexOf("\"Result\":true") != -1)
                    {

                     tv_result.append(Utils.getSpannString("成功",Color.GREEN));
                        x.task().run(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                for (PointState pointState : pointStates)
                                {
                                    pointState.setHasUpload(1);
                                }
                                DBUtils.insertOrUpdateData(pointStates);
                            }
                        });
                        uploadLables();
                    } else
                    {
                       tv_result.setText(Utils.getSpannString("失败，请重试",Color.RED));
                       setResult(false);
                    }
                }

            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {

                Log.i(TAG, "onError: " + ex.toString());
                tv_result.append(Utils.getSpannString("失败",Color.RED));
                setResult(false);

            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });

    }


    String TAG = "option_load";


    /**
     * 第二步，上传标签
     */
    private void uploadLables()
    {
        final List<Lable> lables = DBUtils.getList(Lable.class, WhereBuilder.b("hasUpload", "is", false).and("creatorID", "=", DBUtils.getCurrentUser().getId()));
        if (lables.size() == 0)
        {

            tv_result.append(Utils.getSpannString("\n无标签需要上传",Color.GREEN));
            uploadAreadata();
            return;
        }
        tv_result.append(Utils.getSpannString("\n标签上传中...",Color.BLACK));
        String lables_json = JSON.toJSONString(lables);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addBodyParameter("action", "InsertCybq");
        params.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
        params.addBodyParameter("json", lables_json);
        params.setConnectTimeout(1000 * 30);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                Log.i(TAG, "onSuccess: " + result);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if (result.indexOf("\"Result\":true") != -1)
                    {

                        tv_result.append(Utils.getSpannString("成功",Color.GREEN));
                        x.task().run(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                for (Lable lable : lables)
                                {
                                    lable.setHasUpload(true);
                                }
                                DBUtils.insertOrUpdateData(lables);

                            }
                        });
                        uploadAreadata();
                    } else
                    {
                        tv_result.append(Utils.getSpannString("失败",Color.RED));
                        setResult(false);
                    }
                }

            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.i(TAG, "onError: " + ex.toString());
                tv_result.append(Utils.getSpannString("失败",Color.RED));
                setResult(false);
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });
    }

    /**
     * 第三步，上传采样表
     */
    private void uploadAreadata()
    {
        final List<AreaData> areaDatas = DBUtils.getList(AreaData.class, WhereBuilder.b("hasUpload", "is", false).and("creatorID", "=", DBUtils.getCurrentUser().getId()));
        if (areaDatas.size() == 0)
        {
            tv_result.append(Utils.getSpannString("\n无采集表需要上传",Color.GREEN));
            uploadFiles();
            return;
        }
        tv_result.append(Utils.getSpannString("\n采集表上传中...",Color.BLACK));
        String areadata_json = JSON.toJSONString(areaDatas);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
        params.addBodyParameter("action", "InsertCydc");
        params.addBodyParameter("json", areadata_json);
        params.setConnectTimeout(1000 * 30);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                Log.i(TAG, "onSuccess: " + result);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if (result.indexOf("\"Result\":true") != -1)
                    {

                        tv_result.append(Utils.getSpannString("成功",Color.GREEN));
                        for (AreaData areaData : areaDatas)
                        {
                            areaData.setHasUpload(true);
                        }
                        DBUtils.insertOrUpdateData(areaDatas);
                        uploadFiles();

                    } else
                    {
                        tv_result.append(Utils.getSpannString("失败",Color.RED));
                        setResult(false);
                    }
                }

            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                tv_result.append(Utils.getSpannString("失败",Color.RED));
                setResult(false);
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });
    }


    List<MediaAsset> mediaAssets;
    int assetCount;
    int failCount, successCount;

    /**
     * 第四步，上传附件
     */
    private void uploadFiles()
    {
        failCount = 0;
        successCount = 0;
        mediaAssets = DBUtils.getList(MediaAsset.class, WhereBuilder.b("hasUpload", "is", false).and("creatorID", "=", DBUtils.getCurrentUser().getId()));
        assetCount = mediaAssets.size();
        if (assetCount == 0)
        {
            tv_result.append(Utils.getSpannString("\n无上传文件",Color.GREEN));
            setResult(true);
            return;
        }
        tv_result.append(Utils.getSpannString("\n文件上传中...",Color.BLACK));
        for (final MediaAsset asset : mediaAssets)
        {
            File file = new File(asset.getFilepath());
            RequestParams requestParams = new RequestParams(APPConfig.MainUrl);
            requestParams.addQueryStringParameter("action", "UpLoadFile");
            requestParams.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
            requestParams.setMultipart(true);
            requestParams.addBodyParameter("fileName", file.getName());
            requestParams.addBodyParameter("fileData", file);
            requestParams.addBodyParameter("createDate", Utils.getDate(true));
            requestParams.addBodyParameter("traceNumber", asset.getTraceNumber());
            requestParams.addBodyParameter("scrID", DBUtils.getCurrentUser().getId());
            requestParams.addBodyParameter("scrMc", DBUtils.getCurrentUser().getRealName());
            requestParams.addBodyParameter("lableId", asset.getLable_Id());
            requestParams.setConnectTimeout(60 * 1000);
            x.http().post(requestParams, new Callback.CommonCallback<String>()
            {
                @Override
                public void onSuccess(String result)
                {
                    Log.i(TAG, "onSuccess: " + result);
                    MResult mResult = JSON.parseObject(result, MResult.class);
                    assetCount--;
                    if (mResult.getResultCode().equals("200"))
                    {
                        if (result.indexOf("\"Result\":true") != -1)
                        {
                            asset.setHasUpload(true);
                            successCount++;
                        } else
                        {
                            failCount++;
                        }
                    } else
                    {
                        failCount++;
                    }
                    if (assetCount == 0)
                    {
                        tv_result.append(Utils.getSpannString("\n上传文件数量-成功:",Color.BLACK));
                        tv_result.append(Utils.getSpannString(successCount+"",Color.GREEN));
                        tv_result.append(Utils.getSpannString(" 失败:",Color.BLACK));
                        tv_result.append(Utils.getSpannString(failCount+"",Color.RED));
                        setResult(failCount==0);
                        x.task().run(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                DBUtils.insertOrUpdateData(mediaAssets);
                            }
                        });
                    }
                }

                @Override
                public void onError(Throwable ex, boolean isOnCallback)
                {
                    assetCount--;
                    failCount++;
                    if (assetCount == 0)
                    {
                        tv_result.append(Utils.getSpannString("\n上传文件数量-成功:",Color.BLACK));
                        tv_result.append(Utils.getSpannString(successCount+"",Color.GREEN));
                        tv_result.append(Utils.getSpannString(" 失败:",Color.BLACK));
                        tv_result.append(Utils.getSpannString(failCount+"",Color.RED));
                        setResult(failCount==0);
                            x.task().run(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                DBUtils.insertOrUpdateData(mediaAssets);
                            }
                        });
                    }
                    Log.i(TAG, "onError: " + ex.toString());
                }

                @Override
                public void onCancelled(CancelledException cex)
                {

                }

                @Override
                public void onFinished()
                {

                }
            });
        }


    }
    private void setResult(Boolean result)
    {
        btn_cancle.setVisibility(View.VISIBLE);
        if(!result)
        {
            btn_cancle.setText("重试");

            btn_cancle.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    upload(null);
                }
            });
        }
        else
        {
            btn_cancle.setText("完成");
            btn_cancle.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    if(null!=tipDialog&&tipDialog.isShowing())
                        tipDialog.dismiss();
                }
            });
        }
    }
}
