package hc.gis.cetubao.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.squareup.picasso.Picasso;

import java.util.List;

import hc.gis.cetubao.Bean.News;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/5.
 */

public class Adapter_News extends RecyclerView.Adapter<Adapter_News.Holder_News>
{

    Context mContext;
    List<News> list_new;
    public Adapter_News(Context context, List<News> list_new)
    {
        this.mContext = context;
        this.list_new = list_new;
    }


    @Override
    public Holder_News onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_specification, parent, false);
        Holder_News holder_news = new Holder_News(view);
        return holder_news;
    }

    @Override
    public void onBindViewHolder(Holder_News holder, int position)
    {
        final News aNew = list_new.get(position);
        holder.tv_title.setText(aNew.getTitle());
        holder.tv_istop.setVisibility(aNew.getTop() == 1 ? View.VISIBLE : View.INVISIBLE);
        holder.tv_author.setText(aNew.getAuthor());
        holder.tv_date.setText(aNew.getDate());
        Picasso.with(mContext).load(aNew.getThumb_url()).into(holder.iv_thumb);
        holder.ll_news_main.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(mContext, "点击了新闻", Toast.LENGTH_LONG).show();
            }
        });
    }

//

    @Override
    public int getItemCount()
    {
        return list_new.size();
    }

    public Boolean hasData()
    {
        return null == list_new;
    }



    class Holder_News extends RecyclerView.ViewHolder
    {

        TextView tv_title, tv_author, tv_date, tv_istop;
        ImageView iv_thumb;
        LinearLayout ll_news_main;

        public Holder_News(View itemView)
        {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_author = itemView.findViewById(R.id.tv_author);
            tv_date = itemView.findViewById(R.id.tv_date);
            tv_istop = itemView.findViewById(R.id.tv_istop);
            iv_thumb = itemView.findViewById(R.id.iv_thumn_news);
            ll_news_main = itemView.findViewById(R.id.ll_news_main);

        }



    }
}
