package hc.gis.cetubao.Bean;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/12/5.
 */
@Table(name = "area")
public class Area implements Serializable
{
    public Area()
    {
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getAreaName()
    {
        return areaName;
    }

    public void setAreaName(String areaName)
    {
        this.areaName = areaName;
    }

    public String getAreaCode()
    {
        return areaCode;
    }

    public void setAreaCode(String areaCode)
    {
        this.areaCode = areaCode;
    }

    public String getParentID()
    {
        return parentID;
    }

    public void setParentID(String parentID)
    {
        this.parentID = parentID;
    }

    public String getIsDeleted()
    {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted)
    {
        this.isDeleted = isDeleted;
    }

    public String getRemark()
    {
        return remark;
    }

    public void setRemark(String remark)
    {
        this.remark = remark;
    }

    public String getArealevel()
    {
        return arealevel;
    }

    public void setArealevel(String arealevel)
    {
        this.arealevel = arealevel;
    }

    public String getCityName()
    {
        return cityName;
    }

    public void setCityName(String cityName)
    {
        this.cityName = cityName;
    }

    public String getCountyName()
    {
        return countyName;
    }

    public void setCountyName(String countyName)
    {
        this.countyName = countyName;
    }

    public String getTownName()
    {
        return townName;
    }

    public void setTownName(String townName)
    {
        this.townName = townName;
    }

    public String getVillageName()
    {
        return villageName;
    }

    public void setVillageName(String villageName)
    {
        this.villageName = villageName;
    }

    public String getChariotName()
    {
        return chariotName;
    }

    public void setChariotName(String chariotName)
    {
        this.chariotName = chariotName;
    }

    @Column(name = "id", isId = true)
    String id;
    @Column(name = "areaName")
    String areaName;
    @Column(name = "areaCode")
    String areaCode;
    @Column(name = "parentID")
    String parentID;
    @Column(name = "isDeleted")
    String isDeleted;
    @Column(name = "remark")
    String remark;
    @Column(name = "arealevel")
    String arealevel;
    @Column(name = "cityName")
    String cityName;
    @Column(name = "countyName")
    String countyName;
    @Column(name = "townName")
    String townName;
    @Column(name = "villageName")
    String villageName;
    @Column(name = "chariotName")
    String chariotName;


    public Boolean isSelected = false;

}
