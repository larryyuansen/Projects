package hc.gis.cetubao.Bean;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

import java.io.Serializable;

import hc.gis.cetubao.Other.Utils;

/**
 * Created by Administrator on 2017/12/13.
 */
@Table(name = "MediaAsset")
public class MediaAsset implements Serializable
{
    @Column(name = "id",isId = true)
    public  String assetId;//资源ID

    @Column(name = "lable_id")
    public   String lable_Id;//标签ID

    @Column(name = "traceNumber")
    public   String traceNumber;

    @Column(name = "isPhoto")
    public boolean isPhoto;//是否照片

    @Column(name = "filepath")
    public  String filepath;//本地路径
    @Column(name = "date")
    public  String date;//记录时间(非添加时间)
    @Column(name = "creatorID")
    public  String creatorID;
    @Column(name = "createDate")
    public String createDate;
    //上传人姓名 添加时间 2018年4月4日 16:21:39 添加版本：4
    @Column(name="scrmc")
    public String scrmc;

    public String getScrmc()
    {
        return scrmc;
    }

    public void setScrmc(String scrmc)
    {
        this.scrmc = scrmc;
    }

    public String getAssetId()
    {
        return assetId;
    }

    public void setAssetId(String assetId)
    {
        this.assetId = assetId;
    }

    public String getTraceNumber()
    {
        return traceNumber;
    }

    public void setTraceNumber(String traceNumber)
    {
        this.traceNumber = traceNumber;
    }

    public String getCreatorID()
    {
        return creatorID;
    }

    public void setCreatorID(String creatorID)
    {
        this.creatorID = creatorID;
    }

    public String getCreateDate()
    {
        return createDate;
    }

    public void setCreateDate(String createDate)
    {
        this.createDate = createDate;
    }

    public String getassetId()
    {
        return assetId;
    }

    public void setassetId(String assetId)
    {
        this.assetId = assetId;
    }

    public String getLable_Id()
    {
        return lable_Id;
    }

    public void setLable_Id(String lable_Id)
    {
        this.lable_Id = lable_Id;
    }

    public boolean isPhoto()
    {
        return isPhoto;
    }

    public void setPhoto(boolean photo)
    {
        isPhoto = photo;
    }

    public String getFilepath()
    {
        return filepath;
    }

    public void setFilepath(String filepath)
    {
        this.filepath = filepath;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public MediaAsset(String id, String lable_Id, boolean isPhoto, String filepath, String date)
    {
        this.assetId = id;
        this.lable_Id = lable_Id;
        this.isPhoto = isPhoto;
        this.filepath = filepath;
        this.date = date;
        hasUpload =false;
    }

    public MediaAsset()
    {
        hasUpload =false;
        this.assetId = Utils.getUUID();
    }

    @Column(name = "hasUpload")
    Boolean hasUpload;

    public Boolean getHasUpload()
    {
        return hasUpload;
    }

    public void setHasUpload(Boolean hasUpload)
    {
        this.hasUpload = hasUpload;
    }
}
