package hc.gis.cetubao.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.Adapter.Adapter_News;
import hc.gis.cetubao.Adapter.Decoration.NewsDecoration;
import hc.gis.cetubao.Bean.News;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/3.
 */
@ContentView(R.layout.fragment_specification)
public class Fragment_Specification extends Fragment
{
    View mView;
    @ViewInject(R.id.rcy_specification)
    RecyclerView rcy_speci;
    List<News> list_new;
    Adapter_News adapter_news;
    LinearLayoutManager llManager;
    @ViewInject(R.id.rg_article)
    RadioButton rb_article;
    @ViewInject(R.id.rg_file)
    RadioButton rg_file;
    @ViewInject(R.id.rg_spci)
    RadioGroup rg_speci;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mView = x.view().inject(this, inflater, container);
        initView();
        return mView;
    }


    private void initView()
    {
        list_new = new ArrayList<>();
        llManager = new LinearLayoutManager(getActivity());
        adapter_news = new Adapter_News(getActivity(), list_new);
        rcy_speci.addItemDecoration(new NewsDecoration(2));
        rcy_speci.setLayoutManager(llManager);
        rcy_speci.setAdapter(adapter_news);
        for (int i = 0; i < 20; i++)
        {
            list_new.add(new News("这是第" + i + "条新闻标题", i + "号作者", "2017-12-20", "https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=624916024,80316301&fm=173&s=C2A392456000654F028554E30300E010&w=218&h=146&img.JPEG", i % 2 == 0 ? 1 : 0));
        }
        rb_article.setChecked(true);
    }

    Thread thread_GetNews;

    private void initData()
    {
        if (thread_GetNews == null)
            thread_GetNews = new Thread(new Runnable()
            {
                @Override
                public void run()
                {

                    //此处从接口获取数据

                    //刷新数据
                    getActivity().runOnUiThread(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            refreshData();
                        }
                    });
                }
            });
        if (thread_GetNews.isAlive())
            return;
        else
            thread_GetNews.start();

    }

    private void refreshData()
    {
        if (adapter_news.hasData())
            adapter_news.notifyDataSetChanged();
        else
            initData();
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();

    }
}
