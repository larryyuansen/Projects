package hc.gis.cetubao.Activity;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.maps.model.LatLng;

import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Activity.Library.Activity_SelectMedia;
import hc.gis.cetubao.Activity.Library.MediaChooser;
import hc.gis.cetubao.Bean.AreaData;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.BuildConfig;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.MarkerDrawUtils;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;
import hc.gis.cetubao.widget.MyDialog;
import hc.gis.cetubao.widget.TimePickerDialog;

@ContentView(R.layout.activity_lable)
public class Activity_Lable extends MBaseActivity
{

    PointState pointState;
    Lable lable;
    @ViewInject(R.id.tv_area_name)
    TextView tv_area_name;
    @ViewInject(R.id.tv_zipcode)
    TextView tv_zipcode;
    @ViewInject(R.id.tv_area_bearing)
    TextView tv_area_bearing;
    @ViewInject(R.id.line)
    ImageView line;
    @ViewInject(R.id.tv_date)
    TextView tv_date;
    @ViewInject(R.id.rg_collect_deep)
    RadioGroup rg_collect_deep;
    @ViewInject(R.id.et_deep_input)
    EditText et_deep_input;
    @ViewInject(R.id.tv_latlng)
    TextView tv_latlng;
    @ViewInject(R.id.et_collecter)
    EditText et_collector;
    @ViewInject(R.id.et_pohne)
    EditText et_phone;
    @ViewInject(R.id.ll_pic)
    LinearLayout ll_pic;
    @ViewInject(R.id.et_remark)
    EditText et_remark;
    @ViewInject(R.id.rb_collect_input)
    RadioButton rb_collect_input;
    @ViewInject(R.id.rb_collect_normal)
    RadioButton rb_collect_normal;
    @ViewInject(R.id.et_group)
    EditText et_group;
    @ViewInject(R.id.et_number)
    EditText et_number;
    @ViewInject(R.id.et_obj)
    EditText et_obj;
    @ViewInject(R.id.tv_height)
    TextView tv_height;
    @ViewInject(R.id.btn_getheight)
    Button btn_getheight;
    private LatLng latlng_lable;
    AreaData areaData_Local;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        x.view().inject(this);
        this.pointState = (PointState) getIntent().getSerializableExtra("pointState");
        super.onCreate(savedInstanceState);
        areaData_Local = DBUtils.getSingleObj(AreaData.class, WhereBuilder.b("dk_bh", "=", pointState.getCydNumber()), "tv_cyrq", true);

        setListener();
        initView();
        lable = new Lable();
        lable.setRegYear(getIntent().getStringExtra("year"));
        lable.setLableID(Utils.getUUID());
        lable.setCreatorID(DBUtils.getCurrentUser().getId());
        lable.setCreateDate(Utils.getDate(true));
        latlng_lable = new LatLng(Double.valueOf(pointState.getLat()), Double.valueOf(pointState.getLon()));
        lable.setCydnumber(pointState.getCydNumber());
        registerReceiver(imageBroadcastReceiver, new IntentFilter(MediaChooser.IMAGE_SELECTED_ACTION_FROM_MEDIA_CHOOSER));
    }

    @Override
    protected void onDestroy()
    {
        unregisterReceiver(imageBroadcastReceiver);
        super.onDestroy();
    }

    private void setListener()
    {
        rg_collect_deep.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                if (checkedId == R.id.rb_collect_normal)
                {
                    et_deep_input.setFocusable(false);
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
// hide virtual keyboard
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(et_deep_input.getWindowToken(), 0);
                }
            }
        });
        et_deep_input.setOnFocusChangeListener(new View.OnFocusChangeListener()
        {
            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                if (hasFocus)
                {
                    rg_collect_deep.check(R.id.rb_collect_input);
                }

            }
        });
        et_deep_input.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (!et_deep_input.hasFocus())
                {
                    et_deep_input.setFocusable(true);
                    et_deep_input.setFocusableInTouchMode(true);
                    rg_collect_deep.check(R.id.et_deep_input);
                }
                return false;
            }

        });
    }

    private void initView()
    {
        tv_date.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        et_deep_input.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        tv_latlng.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        tv_height.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        //  et_collector.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        tv_area_name.setText(Utils.getFullName(pointState));
        tv_zipcode.setText(getResources().getString(R.string.postCode) + pointState.getPostCode());
        tv_area_bearing.setText(getResources().getString(R.string.area_bearing) + pointState.getCydArea());
        tv_date.setText(Utils.getDate(true));
        tv_latlng.setText("（" + Utils.getScale(Double.valueOf(pointState.getLat()), 5) + "，" + Utils.getScale(Double.valueOf(pointState.getLon()), 5) + "）");
        if (null == areaData_Local||TextUtils.isEmpty(areaData_Local.getDk_hbgd()))
        {
            tv_height.setText(Utils.getScale(MApplication.aMapLocation.getAltitude(),5)+"");
        } else
            tv_height.setText(areaData_Local.getDk_hbgd());
        rg_collect_deep.check(R.id.rb_collect_normal);
        if (areaData_Local != null)
        {
            et_obj.setText(areaData_Local.getDk_cymd());
            et_number.setText(areaData_Local.getDk_cyxh());
            et_group.setText(areaData_Local.getDk_dczh());
        }

    }

    // R.id.tv_collecter
    @Event(value = {R.id.btn_getheight, R.id.ll_exit, R.id.tv_save, R.id.tv_date, R.id.ll_collect_input, R.id.btn_getlatlng, R.id.btn_addpic, R.id.btn_save_lable})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.ll_exit:
                ActivityManager.getAppManager().finishActivity(this);
                break;
            case R.id.tv_save:
                break;
            case R.id.tv_date:
//                MyDatepicker mydatepicker = new MyDatepicker(this, tv_date);
//                mydatepicker.getDialog().show();
                TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.TimePickerDialogInterface()
                {

                    @Override
                    public void positiveListener(String dateHasTime, String dateNoTime)
                    {
                        tv_date.setText(dateHasTime);
                    }

                    @Override
                    public void negativeListener()
                    {

                    }
                });
                timePickerDialog.showDateAndTimePickerDialog("采集时间");
                break;
            case R.id.ll_collect_input:
                rb_collect_input.callOnClick();
                break;
            case R.id.btn_getlatlng:
                latlng_lable = MarkerDrawUtils.GCJ2WGS.delta(MApplication.lat, MApplication.lng);
                tv_latlng.setText("（" + Utils.getScale(latlng_lable.latitude, 5) + "，" + Utils.getScale(latlng_lable.longitude, 5) + "）");

                Toast.makeText(this, "已为您重新定位", Toast.LENGTH_SHORT).show();
                break;
//            case R.id.tv_collecter:
//                getContact();
//                break;
            case R.id.btn_getheight:
                if (MApplication.aMapLocation.getAltitude() == 0d)
                    tv_height.setText("0");
                tv_height.setText(Utils.getScale(MApplication.aMapLocation.getAltitude(), 5) + "");
                break;
            case R.id.btn_addpic:
                Intent intent = new Intent(this, Activity_SelectMedia.class);
                intent.putExtra("type", "picture");
                intent.putExtra("From", "plant");
                startActivity(intent);
                break;
            case R.id.btn_save_lable:
                saveLable();
                break;
        }
    }

    AlertDialog alert;

    /*private void getContact()
    {
        final MyList<Contacts> contacts = new MyList<>();

        contacts.add(new Contacts("张三", "18633333333"));
        contacts.add(new Contacts("李四", "15677777777"));
        contacts.add(new Contacts("王五", "18944013312"));


        AlertDialog.Builder Builder;
        Builder = new AlertDialog.Builder(this)
                .setTitle("请选择联系人");
        Builder.setItems(contacts.getArray(), new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                alert.dismiss();
                et_collector.setText(contacts.get(which).getName());
                et_phone.setText(contacts.get(which).getPhone());

            }
        });
        alert = Builder.create();
        alert.show();

    }*/

    private void saveLable()
    {
//        if (!rb_collect_input.isChecked() && !rb_collect_normal.isChecked())
//        {
//            Toast.makeText(this, "请填写或选择采样深度！", Toast.LENGTH_SHORT).show();
//        }
//        if (rb_collect_input.isChecked() && TextUtils.isEmpty(et_deep_input.getText().toString().trim()))
//        {
//            Toast.makeText(this, "请填写或选择采样深度！", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (TextUtils.equals(et_collector.getText().toString().trim(), "请选择采样人"))
//        {
//            Toast.makeText(this, "请选择采样人！", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (TextUtils.isEmpty(et_phone.getText().toString().trim()))
//        {
//            Toast.makeText(this, "请填写手机号！", Toast.LENGTH_SHORT).show();
//            return;
//        }
        lable.setPostCode(pointState.getPostCode());
        lable.setRegDate(Utils.getDate(true));
        lable.setRegDate(Utils.getStringOrNull(tv_date.getText().toString()));
        if (rb_collect_input.isChecked())
            lable.setCollectDeep(Utils.getStringOrNull(et_deep_input.getText()));
        else
            lable.setCollectDeep(20 + "");
        lable.setGroupNumber(Utils.getStringOrNull(et_group.getText()));
        lable.setCollectObj(Utils.getStringOrNull(et_obj.getText()));
        lable.setCollectNumber(Utils.getStringOrNull(et_number.getText()));
        lable.setLat(Utils.getScale(latlng_lable.latitude, 5));
        lable.setLon(Utils.getScale(latlng_lable.longitude, 5));
        lable.setRegistrar(Utils.getStringOrNull(et_collector.getText()));
        lable.setTelephone(Utils.getStringOrNull(et_phone.getText()));
        lable.setCreatorID(DBUtils.getCurrentUser().getId());
        lable.setRemark(Utils.getStringOrNull(et_remark.getText()));
        lable.setCreateDate(Utils.getDate(true));
        lable.setHeight(tv_height.getText().toString().trim());
        String date = lable.getRegDate().substring(0, lable.getRegDate().indexOf(" ")).replace("/", "");

        lable.setTraceNumber((pointState.getPostCode() + lable.getCollectObj() + date + lable.getGroupNumber() + lable.getCollectNumber()).replace("null", ""));
        DBUtils.insertOrUpdateData(lable);
        for (MediaAsset asset : mediaAssets)
        {
            asset.setLable_Id(lable.getLableID());
            asset.setTraceNumber(lable.getTraceNumber());
        }
        DBUtils.insertOrUpdateData(mediaAssets);
        Intent intent = new Intent(this, Activity_LableHistory.class);
        intent.putExtra("cydNumber", lable.getCydnumber());
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed()
    {
        ActivityManager.getAppManager().finishActivity(this);
        super.onBackPressed();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case 101:
            {
                if (resultCode == RESULT_OK)
                {

                }
            }
            break;
            case 102:
            {
                if (resultCode == RESULT_OK)
                {
                    // ContentProvider展示数据类似一个单个数据库表
                    // ContentResolver实例带的方法可实现找到指定的ContentProvider并获取到ContentProvider的数据
                    ContentResolver reContentResolverol = getContentResolver();
                    // URI,每个ContentProvider定义一个唯一的公开的URI,用于指定到它的数据集
                    Uri contactData = data.getData();
                    // 查询就是输入URI等参数,其中URI是必须的,其他是可选的,如果系统能找到URI对应的ContentProvider将返回一个Cursor对象.
                    Cursor cursor = reContentResolverol.query(contactData, null, null, null, null);

                    if (null != cursor && cursor.moveToFirst())
                    {
                        int nameFieldIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        String name = cursor.getString(nameFieldIndex);
                        int phoneFieldindex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                        String phone = cursor.getString(phoneFieldindex);
                        et_collector.setText(name);
                        et_phone.setText(phone);

                    }

                    cursor.close();
                }
            }
            break;

        }
    }

    ArrayList<MediaAsset> mediaAssets = new ArrayList<>();
    BroadcastReceiver imageBroadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            List<String> list = intent.getStringArrayListExtra("list");

            addPicture(list, mediaAssets, ll_pic);

        }
    };
    MyDialog myDialog;

    @Event(R.id.tv_select_contact)
    private void select_Contact(View view)
    {
        startActivityForResult(new Intent(Intent.ACTION_PICK,
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI), 102);
    }

    public void addPicture(List<String> list, final List<MediaAsset> list_media, final LinearLayout ll_pic)
    {

        for (int i = 0; i < list.size(); i++)
        {
            for (MediaAsset mediaAsset : mediaAssets)
            {
                if (TextUtils.equals(list.get(i), mediaAsset.getFilepath()))
                {
                    continue;
                }
            }

            //加载图片，并设置tag
            String FJBDLJ = list.get(i);
            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.MATCH_PARENT, 0);
            lp.setMargins(25, 4, 0, 4);
            imageView.setLayoutParams(lp);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            x.image().bind(imageView, FJBDLJ);
            imageView.setTag(FJBDLJ);
            ll_pic.addView(imageView);
            MediaAsset mediaAsset = new MediaAsset();
            mediaAsset.setCreateDate(Utils.getDate(true));
            mediaAsset.setCreatorID(DBUtils.getCurrentUser().getId());
            mediaAsset.setFilepath(FJBDLJ);
            mediaAsset.setScrmc(DBUtils.getCurrentUser().getRealName());
            list_media.add(mediaAsset);
            try
            {
                mediaAsset.setDate(Utils.formatDate(new File(mediaAsset.getFilepath()).lastModified(), false));
            } catch (Exception e)
            {
                mediaAsset.setDate(Utils.getDate(false));
            }
            imageView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    final int index_zp = ll_pic.indexOfChild(v);
                    View dialog_layout = (LinearLayout) getLayoutInflater().inflate(R.layout.customdialog_callback, null);
                    myDialog = new MyDialog(Activity_Lable.this,
                            R.style.MyDialog,
                            dialog_layout,
                            "选择操作",
                            "查看该图片?",
                            "查看", "删除", new MyDialog.CustomDialogListener()
                    {
                        @Override
                        public void OnClick(View v)
                        {
                            switch (v.getId())
                            {
                                case R.id.btn_sure:
                                    File file = new File(list_media.get(index_zp).getFilepath());
                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                    if (Build.VERSION.SDK_INT < 24)
                                        intent.setDataAndType(Uri.fromFile(file), "image/*");
                                    else
                                    {
                                        intent.setData(FileProvider.getUriForFile(Activity_Lable.this, BuildConfig.APPLICATION_ID + ".provider", file));
                                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    }
                                    startActivity(intent);
                                    break;
                                case R.id.btn_cancle://移除图片控件、图片附件信息
                                    ll_pic.removeViewAt(index_zp);
                                    list_media.remove(index_zp);
                                    myDialog.dismiss();
                                    break;
                            }
                        }
                    });
                    myDialog.show();
                }
            });
        }
    }


}
