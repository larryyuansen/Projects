package hc.gis.cetubao.Activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.FileProvider;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.amap.api.maps.model.LatLng;

import org.xutils.common.Callback;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Activity.Library.Activity_SelectMedia;
import hc.gis.cetubao.Activity.Library.MediaChooser;
import hc.gis.cetubao.Bean.AreaData;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.BuildConfig;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.MarkerDrawUtils;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;
import hc.gis.cetubao.widget.MyDialog;
import hc.gis.cetubao.widget.TimePickerDialog;

@ContentView(R.layout.activity_lable_lablewrite)
public class Activity_LableWirte extends MBaseActivity
{

    PointState pointState;
    Lable lable;
    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;
    @ViewInject(R.id.tv_delete)
    TextView tv_delete;
    @ViewInject(R.id.title)
    LinearLayout title;
    @ViewInject(R.id.tv_area_name)
    TextView tv_area_name;
    @ViewInject(R.id.tv_zipcode)
    TextView tv_zipcode;
    @ViewInject(R.id.tv_area_bearing)
    TextView tv_area_bearing;
    @ViewInject(R.id.line)
    ImageView line;
    @ViewInject(R.id.layout_topinfo)
    RelativeLayout layout_topinfo;
    @ViewInject(R.id.btn_gethl)
    Button btn_gethl;
    @ViewInject(R.id.tv_latlng)
    TextView tv_latlng;
    @ViewInject(R.id.tv_height)
    TextView tv_height;
    @ViewInject(R.id.tv_date)
    TextView tv_date;
    @ViewInject(R.id.et_collecter)
    EditText et_collecter;
    @ViewInject(R.id.et_phone)
    EditText et_phone;
    @ViewInject(R.id.tv_select_contact)
    TextView tv_select_contact;
    @ViewInject(R.id.et_cygoup)
    EditText et_cygoup;
    @ViewInject(R.id.et_cynumber)
    EditText et_cynumber;
    @ViewInject(R.id.et_cyorder)
    EditText et_cyorder;
    @ViewInject(R.id.rb_collect_normal)
    RadioButton rb_collect_normal;
    @ViewInject(R.id.rb_collect_input)
    RadioButton rb_collect_input;
    @ViewInject(R.id.rg_collect_deep)
    RadioGroup rg_collect_deep;
    @ViewInject(R.id.et_deep_input)
    EditText et_deep_input;
    @ViewInject(R.id.ll_collect_input)
    LinearLayout ll_collect_input;
    @ViewInject(R.id.ll_pic)
    LinearLayout ll_pic;
    @ViewInject(R.id.btn_addpic)
    ImageButton btn_addpic;
    @ViewInject(R.id.rl_addpic)
    RelativeLayout rl_addpic;
    @ViewInject(R.id.tv_rkinfo)
    TextView tv_rkinfo;
    @ViewInject(R.id.ll_img2)
    LinearLayout ll_img2;
    @ViewInject(R.id.btn_lable_save)
    Button btn_lable_save;
    @ViewInject(R.id.btn_lable_print)
    Button btn_lable_print;
    @ViewInject(R.id.rl_save)
    LinearLayout rl_save;
    @ViewInject(R.id.activity_lable_history)
    RelativeLayout activity_lable_history;
    private  static final  int REQUEST_WRITE_REMARK=998;
    private LatLng latlng_lable;
    AreaData areaData_Local;
    String remarkData;
   /* String phone;
    String name;*/
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        x.view().inject(this);
        this.pointState = (PointState) getIntent().getSerializableExtra("pointState");
        remarkData = getIntent().getStringExtra("remark");
      /*  name = getIntent().getStringExtra("name");
        phone = getIntent().getStringExtra("phone");*/
        super.onCreate(savedInstanceState);
        areaData_Local = DBUtils.getSingleObj(AreaData.class, WhereBuilder.b("dk_bh", "=", pointState.getCydNumber()), "tv_cyrq", true);
        initView();
        setListener();
        lable = new Lable();
        lable.setRegYear(getIntent().getStringExtra("year"));
        lable.setLableID(Utils.getUUID());
        lable.setCreatorID(DBUtils.getCurrentUser().getId());
        lable.setCreateDate(Utils.getDate(true));
        lable.setYear(pointState.getStartYear());
        latlng_lable = new LatLng(Double.valueOf(pointState.getLat()), Double.valueOf(pointState.getLon()));
        lable.setCydnumber(pointState.getCydNumber());
        registerReceiver(imageBroadcastReceiver, new IntentFilter(MediaChooser.IMAGE_SELECTED_ACTION_FROM_MEDIA_CHOOSER));
        ActivityManager.getAppManager().addActivity(this);
    }


    private void setListener()
    {
        rg_collect_deep.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                if (checkedId == R.id.rb_collect_normal)
                {
                    et_deep_input.setFocusable(false);
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
// hide virtual keyboard
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(et_deep_input.getWindowToken(), 0);
                    et_deep_input.setEnabled(false);
                    et_deep_input.setFocusable(false);
                    et_deep_input.setFocusableInTouchMode(false);
                }
                else
                {
                    et_deep_input.setEnabled(true);
                    et_deep_input.setFocusable(true);
                    et_deep_input.setFocusableInTouchMode(true);
                    et_deep_input.requestFocusFromTouch();
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
// hide virtual keyboard
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(et_deep_input, 0);
                }
            }
        });
//        et_deep_input.setOnFocusChangeListener(new View.OnFocusChangeListener()
//        {
//            @Override
//            public void onFocusChange(View v, boolean hasFocus)
//            {
//                if (hasFocus)
//                {
//                    rg_collect_deep.check(R.id.rb_collect_input);
//                }
//
//            }
//        });
//        et_deep_input.setOnTouchListener(new View.OnTouchListener()
//        {
//            @Override
//            public boolean onTouch(View v, MotionEvent event)
//            {
//
//                    et_deep_input.setFocusable(true);
//                    et_deep_input.setFocusableInTouchMode(true);
//                    rg_collect_deep.check(R.id.et_deep_input);
//
//                return false;
//            }
//        });
//

        tv_rkinfo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }
        });

        tv_rkinfo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               Intent intent = new Intent(Activity_LableWirte.this, Activity_remark.class);
               intent.putExtra("remark",lable.getRemark());
               startActivityForResult(intent,REQUEST_WRITE_REMARK);
            }
        });

    }

    private void initView()
    {
        tv_area_name.setText(Utils.getFullName(pointState).trim());
        tv_zipcode.setText(getResources().getString(R.string.postCode) + pointState.getPostCode());
        tv_area_bearing.setText(getResources().getString(R.string.area_bearing) + pointState.getCydArea());
        if (MApplication.aMapLocation.getAltitude() == 0d)
            tv_height.setText("0");
        tv_height.setText(Utils.getScale(MApplication.aMapLocation.getAltitude(), 5) + "");
        //tv_select_contact.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG); //添加下划线
                tv_select_contact.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               /* startActivityForResult(new Intent(Intent.ACTION_PICK,
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI), 102);*/
               Intent intent = new Intent(getApplicationContext(),ActivityDialog_ChooseContacts.class);
               startActivityForResult(intent,102);
            }
        });

        if (null == areaData_Local|| TextUtils.isEmpty(areaData_Local.getDk_hbgd()))
        {
            tv_height.setText(Utils.getScale(MApplication.aMapLocation.getAltitude(),5)+"");
        } else
            tv_height.setText(areaData_Local.getDk_hbgd());
        rg_collect_deep.check(R.id.rb_collect_normal);
        if (areaData_Local != null)
        {
            et_cyorder.setText(areaData_Local.getDk_cymd());
            et_cynumber.setText(areaData_Local.getDk_cyxh());
            et_cygoup.setText(areaData_Local.getDk_dczh());
        }
        tv_date.setText(Utils.getDate(true));
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case 101:
            {
                if (resultCode == RESULT_OK)
                {

                }
            }
            break;
           case 102:
           {
               if (resultCode == RESULT_OK)
               {
               /*     // ContentProvider展示数据类似一个单个数据库表
                    // ContentResolver实例带的方法可实现找到指定的ContentProvider并获取到ContentProvider的数据
                    ContentResolver reContentResolverol = getContentResolver();
                    // URI,每个ContentProvider定义一个唯一的公开的URI,用于指定到它的数据集
                    Uri contactData = data.getData();
                    // 查询就是输入URI等参数,其中URI是必须的,其他是可选的,如果系统能找到URI对应的ContentProvider将返回一个Cursor对象.
                    Cursor cursor = reContentResolverol.query(contactData, null, null, null, null);

                    if (null != cursor && cursor.moveToFirst())
                    {
                        int nameFieldIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        String name = cursor.getString(nameFieldIndex);
                        int phoneFieldindex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                        String phone = cursor.getString(phoneFieldindex);
                        et_collecter.setText(name);
                        et_phone.setText(phone);

                    }

                    cursor.close();

            }*/
               String phone = data.getStringExtra("phone");
               String name = data.getStringExtra("name");
               et_collecter.setText(name);
               et_phone.setText(phone);
               break;
               }
           }
            case REQUEST_WRITE_REMARK:
            {
                if (resultCode == RESULT_OK)
                {
                    String remark = data.getStringExtra("remark");
                    tv_rkinfo.setText(remark);
                    lable.setRemark(remark);
                }

            }
            break;

        }


    }


    @Override
    protected void onDestroy()
    {
        unregisterReceiver(imageBroadcastReceiver);
        super.onDestroy();
    }

    @Event(value = {R.id.btn_gethl, R.id.tv_date, R.id.btn_addpic, R.id.btn_lable_save, R.id.btn_lable_print,R.id.ll_exit,})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.btn_gethl:
                latlng_lable = MarkerDrawUtils.GCJ2WGS.delta(MApplication.lat, MApplication.lng);
                tv_latlng.setText("（" + Utils.getScale(latlng_lable.longitude, 5) + "，" + Utils.getScale(latlng_lable.latitude, 5) + "）");

                Toast.makeText(this, "已为您重新定位", Toast.LENGTH_SHORT).show();
                break;
            case R.id.tv_date:
                TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.TimePickerDialogInterface()
                {


                    @Override
                    public void positiveListener(String dateHasTime, String dateNoTime)
                    {
                        tv_date.setText(dateHasTime);
                    }

                    @Override
                    public void negativeListener()
                    {

                    }
                });
                timePickerDialog.showDateAndTimePickerDialog("采集时间");
                break;
            case R.id.btn_addpic:
                Intent intent = new Intent(this, Activity_SelectMedia.class);
                intent.putExtra("type", "picture");
                intent.putExtra("From", "plant");
                startActivity(intent);
                break;
            case R.id.btn_lable_save:
                savaLable();
                break;
            case R.id.btn_lable_print:
                savaLable();
                //intent = new Intent(this, Activity_LableHistory.class);
                intent = new Intent(this, Activity_LablePrint.class);
               //原 intent.putExtra("cydNumber", lable.getCydnumber());
                intent.putExtra("lable", lable);
                startActivity(intent);
                break;
            case R.id.ll_exit:
                ActivityManager.getAppManager().finishActivity(this);
                break;

        }
    }

    ArrayList<MediaAsset> mediaAssets = new ArrayList<>();
    BroadcastReceiver imageBroadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            List<String> list = intent.getStringArrayListExtra("list");

            addPicture(list, mediaAssets, ll_pic);

        }
    };
    private void savaLable()
    {
        lable.setPostCode(pointState.getPostCode());
        lable.setRegDate(Utils.getDate(true));
        lable.setRegDate(Utils.getStringOrNull(tv_date.getText().toString()));
        if (rb_collect_input.isChecked())
            lable.setCollectDeep(Utils.getStringOrNull(et_deep_input.getText()));
        else
            lable.setCollectDeep(20 + "");
        lable.setGroupNumber(Utils.getStringOrNull(et_cygoup.getText()));
        lable.setCollectObj(Utils.getStringOrNull(et_cyorder.getText()));
        lable.setCollectNumber(Utils.getStringOrNull(et_cynumber.getText()));
        lable.setLat(Utils.getScale(latlng_lable.latitude, 5));
        lable.setLon(Utils.getScale(latlng_lable.longitude, 5));
        lable.setRegistrar(Utils.getStringOrNull(et_collecter.getText()));
        lable.setTelephone(Utils.getStringOrNull(et_phone.getText()));
        lable.setRemark(Utils.getStringOrNull(tv_rkinfo.getText()));
        lable.setCreatorID(DBUtils.getCurrentUser().getId());
        lable.setCjrmc(DBUtils.getCurrentUser().getRealName());
        lable.setYear(pointState.getStartYear());
        lable.setCreateDate(Utils.getDate(true));
        lable.setProvinceName(pointState.getProvinceName());
        lable.setCityName(pointState.getCityName());
        lable.setCountyName(pointState.getCountyName());
        lable.setTownName(pointState.getTownName());
        lable.setVillageName(pointState.getVillageName());
        lable.setCydname(pointState.getCydName());
        lable.setHeight(tv_height.getText().toString().trim());
        String date = lable.getRegDate().substring(0, lable.getRegDate().indexOf(" ")).replace("/", "");
        lable.setTraceNumber((pointState.getPostCode() + lable.getCollectObj() + date + lable.getGroupNumber() + lable.getCollectNumber()).replace("null", ""));
        DBUtils.insertOrUpdateData(lable);
        for (MediaAsset asset : mediaAssets)
        {
            asset.setLable_Id(lable.getLableID());
            asset.setTraceNumber(lable.getTraceNumber());
        }
        DBUtils.insertOrUpdateData(mediaAssets);
       // uploadLable();
        ActivityManager.getAppManager().finishActivity(this);
    }


    MyDialog myDialog;

    public void addPicture(List<String> list, final List<MediaAsset> list_media, final LinearLayout ll_pic)
    {

        for (int i = 0; i < list.size(); i++)
        {
            for (MediaAsset mediaAsset : mediaAssets)
            {
                if (TextUtils.equals(list.get(i), mediaAsset.getFilepath()))
                {
                    continue;
                }
            }

            //加载图片，并设置tag
            String FJBDLJ = list.get(i);
            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.MATCH_PARENT, 0);
            lp.setMargins(25, 4, 0, 4);
            imageView.setLayoutParams(lp);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            x.image().bind(imageView, FJBDLJ);
            imageView.setTag(FJBDLJ);
            ll_pic.addView(imageView);
            MediaAsset mediaAsset = new MediaAsset();
            mediaAsset.setCreateDate(Utils.getDate(true));
            mediaAsset.setCreatorID(DBUtils.getCurrentUser().getId());
            mediaAsset.setFilepath(FJBDLJ);
            list_media.add(mediaAsset);
            try
            {
                mediaAsset.setDate(Utils.formatDate(new File(mediaAsset.getFilepath()).lastModified(), false));
            } catch (Exception e)
            {
                mediaAsset.setDate(Utils.getDate(true));
            }
            imageView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    final int index_zp = ll_pic.indexOfChild(v);
                    View dialog_layout = (LinearLayout) getLayoutInflater().inflate(R.layout.customdialog_callback, null);
                    myDialog = new MyDialog(Activity_LableWirte.this,
                            R.style.MyDialog,
                            dialog_layout,
                            "选择操作",
                            "查看该图片?",
                            "查看", "删除", new MyDialog.CustomDialogListener()
                    {
                        @Override
                        public void OnClick(View v)
                        {
                            switch (v.getId())
                            {
                                case R.id.btn_sure:
                                    File file = new File(list_media.get(index_zp).getFilepath());
                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                    if (Build.VERSION.SDK_INT < 24)
                                        intent.setDataAndType(Uri.fromFile(file), "image/*");
                                    else
                                    {
                                        intent.setData(FileProvider.getUriForFile(Activity_LableWirte.this, BuildConfig.APPLICATION_ID + ".provider", file));
                                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    }
                                    startActivity(intent);
                                    break;
                                case R.id.btn_cancle://移除图片控件、图片附件信息
                                    ll_pic.removeViewAt(index_zp);
                                    list_media.remove(index_zp);
                                    myDialog.dismiss();
                                    break;
                            }
                        }
                    });
                    myDialog.show();
                }
            });

        }
    }


    //上传标签
    String TAG = "option_load";
    private void uploadLable()
    {
        List<Lable> lables = new ArrayList<>();
        lables.add(lable);
        String lables_json = JSON.toJSONString(lables);
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addBodyParameter("action", "InsertCybq");
        params.addQueryStringParameter("userId", DBUtils.getCurrentUser().getId());
        params.addBodyParameter("json", lables_json);
        params.setConnectTimeout(1000 * 30);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                Log.i(TAG, "onSuccess: " + result);
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if (result.indexOf("\"Result\":true") != -1)
                    {
                        x.task().run(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                lable.setHasUpload(true);
                                DBUtils.insertOrUpdateData(lable);
                            }
                        });
                    }
                }

            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.i(TAG, "onError: " + ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });
    }


    @Override
    public void onBackPressed()
    {
        ActivityManager.getAppManager().finishActivity(this);
        super.onBackPressed();
    }




}
