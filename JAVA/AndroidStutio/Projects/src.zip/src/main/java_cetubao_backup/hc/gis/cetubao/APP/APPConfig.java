package hc.gis.cetubao.APP;

import android.Manifest;
import android.os.Environment;

/**
 * Created by Administrator on 2017/12/5.
 */

public class APPConfig
{
    public static final String LOCATION_REFRESHED = "HCGIS_LOCATION_REFRESHED";
    public static final String[] permissionNeed = new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE,android.Manifest.permission.READ_CONTACTS};
   // public static  String MainUrl = "http://192.168.1.116/DataApprove/webServices.ashx";
    public static  String MainUrl = "http://122.14.210.73:12000/DataApprove/webServices.ashx";
    public static final String ACTION_GETAREA = "GetNextAreaName";
    public static final String ACTION_GETAllCYD = "GetAllCyd";
    public static final String Get_AllCYD_BYLEVEL = "GetAllCydByLevel";

    public static final String ACTION_GETLGOIN = "GetLogin";
    public static final String ACTION_GETALLCYDDATA = "AppGetAllCybqData";
    public static String MEDIA_PATH = Environment.getExternalStorageDirectory().getPath();
    public static String ACTION_CHANGE_MAINPAGE = "ACTION_CHANGE_MAINPAGE";
}
