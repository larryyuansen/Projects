package hc.gis.cetubao.Bean;

/**
 * Created by Administrator on 2017/12/13.
 */

public class Contacts
{
        /**
         * id : 4
         * realname : App使用
         * telephone : 13729855685
         * code : A
         */
        private String id;
        private String realname;
        private String telephone;
        private String code;

    public Contacts(String id, String realname, String telephone, String code)
    {
        this.id = id;
        this.realname = realname;
        this.telephone = telephone;
        this.code = code;
    }

    public Contacts()
    {
    }

    public String getId()
        {
            return id;
        }

        public void setId(String id)
        {
            this.id = id;
        }

        public String getRealname()
        {
            return realname;
        }

        public void setRealname(String realname)
        {
            this.realname = realname;
        }

        public String getTelephone()
        {
            return telephone;
        }

        public void setTelephone(String telephone)
        {
            this.telephone = telephone;
        }

        public String getCode()
        {
            return code;
        }

        public void setCode(String code)
        {
            this.code = code;
        }
}
