package hc.gis.cetubao.Bean; /**
 * Copyright 2017 bejson.com
 */

import com.alibaba.fastjson.serializer.BeforeFilter;

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

import java.io.Serializable;
import java.util.Date;

import hc.gis.cetubao.Activity.Library.LuYinFragment;
import hc.gis.cetubao.Other.Utils;

@Table(name = "PointState")
public class PointState implements Serializable
{
    public PointState()
    {
        isZyd="false";
        hasUpload = 2;
    }
    @Column(name = "cydNumber", isId = true)
    public String cydNumber;
    @Column(name = "unitCode")
    public String unitCode;
    @Column(name = "area")
    public String area;
    @Column(name = "tybh")//统一编号 添加于 2018年2月27日 18:09:06 添加版本:3
    public  String tybh;
    @Column(name = "lon")
    public String lon;
    @Column(name = "lat")
    public String lat;
    @Column(name = "year")
    public String startYear;
    @Column(name = "areaID")
    public String areaID;
    @Column(name = "isDeleted")
    public String isDeleted;
    @Column(name = "deletedDate")
    public String deletedDate;
    @Column(name = "regDate")
    public String regDate;
    @Column(name = "isZyd")
    public String isZyd;
    @Column(name = "cityID")
    public String cityID;
    @Column(name = "countyID")
    public String countyID;
    @Column(name = "townID")
    public String townID;
    @Column(name = "villageID")
    public String villageID;
    @Column(name = "chariotID")
    public String chariotID;
    @Column(name = "postCode")
    public String postCode;
    @Column(name = "nhName")
    public String nhName;
    @Column(name = "cydName")
    public String cydName;
    @Column(name = "cydArea")
    public String cydArea;
    @Column(name = "distance")
    public String distance;
    @Column(name = "hasSampling")
    public String hasSampling;//是否包含数据
    @Column(name = "creatorID")
    public String creatorID;
    @Column(name = "creatDate")
    public String creatDate;
    @Column(name = "provinceid")
    public String provinceid;
    @Column(name = "provinceName")
    public String provinceName;
    @Column(name = "cityName")
    public String cityName;
    @Column(name = "countyName")
    public String countyName;
    @Column(name = "townName")
    public String townName;
    @Column(name = "villageName")
    public String villageName;
    @Column(name = "newtybh")
    public String newtybh;

    public String getNewtybh()
    {
        return newtybh;
    }

    public void setNewtybh(String newtybh)
    {
        this.newtybh = newtybh;
    }

    public String getProvinceName()
    {
        return provinceName;
    }

    public void setProvinceName(String provinceName)
    {
        this.provinceName = provinceName;
    }

    public String getCityName()
    {
        return cityName;
    }

    public void setCityName(String cityName)
    {
        this.cityName = cityName;
    }

    public String getCountyName()
    {
        return countyName;
    }

    public void setCountyName(String countyName)
    {
        this.countyName = countyName;
    }

    public String getTownName()
    {
        return townName;
    }

    public void setTownName(String townName)
    {
        this.townName = townName;
    }

    public String getVillageName()
    {
        return villageName;
    }

    public void setVillageName(String villageName)
    {
        this.villageName = villageName;
    }

    public String getProvinceid()
    {
        return provinceid;
    }

    public void setProvinceid(String provinceid)
    {
        this.provinceid = provinceid;
    }

    //创建人名称 2018年4月4日 15:53:10 添加版本：4
    @Column(name="cjrmc")
    String cjrmc;

    public String getCjrmc()
    {
        return cjrmc;
    }

    public void setCjrmc(String cjrmc)
    {
        this.cjrmc = cjrmc;
    }

    public String getCreatDate()
    {
        return creatDate;
    }

    public void setCreatDate(String creatDate)
    {
        this.creatDate = creatDate;
    }

    public String getCreatorID()
    {
        return creatorID;
    }

    public void setCreatorID(String creatorID)
    {
        this.creatorID = creatorID;
    }

    public int getHasUpload()
    {
        return hasUpload;
    }

    public void setHasUpload(int hasUpload)
    {
        this.hasUpload = hasUpload;
    }
    public String getTybh()
    {
        return tybh;
    } public void setTybh(String tybh)
{
    this.tybh = tybh;
}
    /**
     * 2,服务器获取，默认设为服务器获取
     * 1.已上传
     * 0.未上传
     */
    @Column(name = "hasUpload")
    private int hasUpload;

    public void setCydNumber(String cydNumber)
    {
        this.cydNumber = cydNumber;
    }

    public String getCydNumber()
    {
        return cydNumber;
    }

    public void setUnitCode(String unitCode)
    {
        this.unitCode = unitCode;
    }

    public String getUnitCode()
    {
        return unitCode;
    }

    public void setArea(String area)
    {
        this.area = area;
    }

    public String getArea()
    {
        return area;
    }

    public void setLon(String lon)
    {
        this.lon = lon;
    }

    public String getLon()
    {
        return lon;
    }

    public void setLat(String lat)
    {
        this.lat = lat;
    }

    public String getLat()
    {
        return lat;
    }

    public void setStartYear(String startYear)
    {
        this.startYear = startYear;
    }

    public String getStartYear()
    {
        return startYear;
    }


    public void setAreaID(String areaID)
    {
        this.areaID = areaID;
    }

    public String getAreaID()
    {
        return areaID;
    }

    public void setIsDeleted(String isDeleted)
    {
        this.isDeleted = isDeleted;
    }

    public String getIsDeleted()
    {
        return isDeleted;
    }

    public void setDeletedDate(String deletedDate)
    {
        this.deletedDate = deletedDate;
    }

    public String getDeletedDate()
    {
        return deletedDate;
    }

    public String getRegDate()
    {
        return regDate;
    }

    public void setRegDate(String regDate)
    {
        this.regDate = regDate;
    }

    public void setIsZyd(String isZyd)
    {
        this.isZyd = isZyd;
    }

    public String getIsZyd()
    {
        return isZyd;
    }

    public void setCityID(String cityID)
    {
        this.cityID = cityID;
    }

    public String getCityID()
    {
        return cityID;
    }

    public void setCountyID(String countyID)
    {
        this.countyID = countyID;
    }

    public String getCountyID()
    {
        return countyID;
    }

    public void setTownID(String townID)
    {
        this.townID = townID;
    }

    public String getTownID()
    {
        return townID;
    }

    public void setVillageID(String villageID)
    {
        this.villageID = villageID;
    }

    public String getVillageID()
    {
        return villageID;
    }

    public void setChariotID(String chariotID)
    {
        this.chariotID = chariotID;
    }

    public String getChariotID()
    {
        return chariotID;
    }

    public void setPostCode(String postCode)
    {
        this.postCode = postCode;
    }

    public String getPostCode()
    {
        return postCode;
    }

    public void setNhName(String nhName)
    {
        this.nhName = nhName;
    }

    public String getNhName()
    {
        return nhName;
    }

    public void setCydName(String cydName)
    {
        this.cydName = cydName;
    }

    public String getCydName()
    {
        return cydName;
    }

    public void setCydArea(String cydArea)
    {
        this.cydArea = cydArea;
    }

    public String getCydArea()
    {
        return cydArea;
    }

    public void setDistance(String distance)
    {
        this.distance = distance;
    }

    public String getDistance()
    {
        return distance;
    }

    public void setHasSampling(String hasSampling)
    {
        this.hasSampling = hasSampling;
    }

    public String getHasSampling()
    {
        return hasSampling;
    }

    @Override
    public String toString()
    {
        return Utils.getFullName(this);

    }
}