package hc.gis.cetubao.Activity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.GnssStatus;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdate;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Bean.PointState;
import hc.gis.cetubao.Other.CompassManager;
import hc.gis.cetubao.Other.MarkerDrawUtils;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;

@ContentView(R.layout.activity_navigation)
public class    Activity_Navigation extends MBaseActivity implements AMap.OnMyLocationChangeListener, CompassManager.OrientationChangeListener, GpsStatus.Listener
{

    @ViewInject(R.id.mapView_navi)
    MapView mapView;
    AMap aMap;
    UiSettings mUisettings;
    CameraUpdate mCameraUpdate;
    @ViewInject(R.id.tv_distance)
    TextView tv_distance;
    @ViewInject(R.id.tv_angle)
    TextView tv_angle;
    @ViewInject(R.id.tv_st_count)
    TextView tv_st_count;
    @ViewInject(R.id.tv_st_accuracy)
    TextView tv_st_accuracy;
    PointState pointState;
    Marker marker_target;
    LatLng latlng_target;
    CompassManager compassManager;
    PolylineOptions polylineOptions;
    Polyline line_guide;
    List<LatLng> latLngs;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        x.view().inject(this);
        mapView.onCreate(savedInstanceState);
        this.pointState = (PointState) getIntent().getSerializableExtra("pointState");
        latlng_target = MarkerDrawUtils.convertPoint(Double.valueOf(pointState.getLat()), Double.valueOf(pointState.getLon()),this);
        checkPermiss();
        initMapView();
        addTargerMarker();
        initCompassManager();
    }

    private void checkPermiss()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
        {
            initGpsChangeCallback();
        } else
        {
            initGpsChangeListener();
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initGpsChangeCallback()
    {
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityManager.getAppManager().finishActivity(this);
            return;
        }
        locationManager.registerGnssStatusCallback(new GnssStatus.Callback()
        {
            @Override
            public void onSatelliteStatusChanged(GnssStatus status)
            {
                int count = status.getSatelliteCount();
                tv_st_count.setText(count + "");
                int statellite_used = 0;
                for (int i = 0; i < count; i++)
                {
                    if (status.usedInFix(i))
                        statellite_used++;
                }
                //tv_st_accuracy.setText(""+statellite_used);
                if (Currentlocation != null)
                    tv_st_accuracy.setText(Utils.getScale(Currentlocation.getAccuracy(), 2) + "m");
                super.onSatelliteStatusChanged(status);
            }
        });
    }

    private void initGpsChangeListener()
    {


        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityManager.getAppManager().finishActivity(this);
            return;
        } else
        {
            locationManager.addGpsStatusListener(this);
        }


    }


    private void initCompassManager()
    {
        compassManager = CompassManager.getInstance(this);
        compassManager.startCompass(this);

    }

    private void addTargerMarker()
    {
        MarkerOptions options = MarkerDrawUtils.getMarkerByState(pointState, this);
        options.title(Utils.getFullName(pointState));
        options.snippet(null);
        marker_target = aMap.addMarker(options);
        marker_target.showInfoWindow();
        aMap.animateCamera(CameraUpdateFactory.newLatLngBounds(Utils.getBound(new LatLng(MApplication.lat, MApplication.lng), latlng_target), 14));
        latLngs = new ArrayList<>();
    }

    private void initMapView()
    {
        if (mapView != null)
        {
            if (aMap == null)
            {
                aMap = mapView.getMap();
            }
        } else
        {
            finish();
        }
        MyLocationStyle myLocationStyle;
        myLocationStyle = new MyLocationStyle();//初始化定位蓝点样式类myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE);//连续定位、且将视角移动到地图中心点，定位点依照设备方向旋转，并且会跟随设备移动。（1秒1次定位）如果不设置myLocationType，默认也会执行此种模式。
        myLocationStyle.interval(2000); //设置连续定位模式下的定位间隔，只在连续定位模式下生效，单次定位模式下不会生效。单位为毫秒。
        myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE_NO_CENTER);
        myLocationStyle.anchor(0.5f, 0.5f);
        myLocationStyle.myLocationIcon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.icon_myself)));
        aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
        aMap.setMyLocationEnabled(true);// 设置为true表示启动显示定位蓝点，false表示隐藏定位蓝点并不进行定位，默认是false。
        mUisettings = aMap.getUiSettings();
        mUisettings.setCompassEnabled(true);
        mUisettings.setZoomControlsEnabled(false);
        mUisettings.setTiltGesturesEnabled(false);
        ;//设置禁止倾斜
        mUisettings.setRotateGesturesEnabled(false);//设置禁止旋转
        //参数依次是：视角调整区域的中心点坐标、希望调整到的缩放级别、俯仰角0°~45°（垂直与地图时为0）、偏航角 0~360° (正北方为0)
        mCameraUpdate = CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(MApplication.lat, MApplication.lng), 18, 0, 0));
        aMap.moveCamera(mCameraUpdate);
        aMap.setOnMyLocationChangeListener(this);

    }

    @Event(value = {R.id.btn_image, R.id.btn_location})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.btn_image:
                if (aMap.getMapType() == AMap.MAP_TYPE_NORMAL)
                    aMap.setMapType(AMap.MAP_TYPE_SATELLITE);
                else
                    aMap.setMapType(AMap.MAP_TYPE_NORMAL);
                break;
            case R.id.btn_location:
                mCameraUpdate = CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(MApplication.lat, MApplication.lng), 18, 0, 0));
                aMap.moveCamera(mCameraUpdate);
                break;
        }
    }


    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        mapView.onDestroy();
        if (Build.VERSION.SDK_INT <24)
            locationManager.removeGpsStatusListener(this);
        compassManager.stopCompass();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    float[] result_dis = new float[1];
    long time_dis_last = 0;
    Location Currentlocation;

    @Override
    public void onMyLocationChange(Location location)
    {
        //double distance = Utils.getDistance(location.getLatitude(), location.getLongitude(),latlng_target.longitude,latlng_target.latitude);
//        if(Utils.isBetterLocation(location,Currentlocation))
//        {
        Currentlocation = location;
//        }
//        tv_st_accuracy.setText(Utils.getScale(Currentlocation.getAccuracy(),2)+"");
        long gap = System.currentTimeMillis() - time_dis_last;
        if (gap < 2000)
            return;
        Location.distanceBetween(Currentlocation.getLatitude(), Currentlocation.getLongitude(), latlng_target.latitude, latlng_target.longitude, result_dis);
        double distance = result_dis[0];
        String str_dis;
        if (distance > 10000)
            str_dis = Utils.getScale(distance / 1000l, 1) + "公里";
        else
            str_dis = Utils.getScale(distance, 0) + "米";
        tv_distance.setText(str_dis);
        latLngs = new ArrayList<LatLng>();
        latLngs.add(new LatLng(Currentlocation.getLatitude(), Currentlocation.getLongitude()));
        latLngs.add(latlng_target);

        if (line_guide != null)
            line_guide.remove();
        polylineOptions = new PolylineOptions();
        polylineOptions.setPoints(latLngs);
        polylineOptions.aboveMaskLayer(false);
        polylineOptions.setUseTexture(true);
        polylineOptions.useGradient(true);
        polylineOptions.width(12f);
        polylineOptions.color(ContextCompat.getColor(this, R.color.blue));
        line_guide = aMap.addPolyline(polylineOptions);
        time_dis_last = System.currentTimeMillis();
    }


    @Override
    public void onListenerStart()
    {
        //null
    }

    long lastchange = 0;
    float last_angle = 999f;

    @Override
    public void onAngleChanged(float degree)
    {
        if (/*last_angle != 999f && (Math.abs(degree - last_angle) > 0.5 &&*/ System.currentTimeMillis() - lastchange < 200)
        {
            return;
        }
        float angle_Azimuth = (float) Utils.GetAzimuth(MApplication.lat, MApplication.lng, latlng_target.latitude, latlng_target.longitude);
        float angle_face_target = degree - angle_Azimuth;
        if (angle_face_target < 0)
            angle_face_target = 360 - angle_Azimuth + degree;
        String str_angle = Utils.getScale(angle_face_target, 0).toString().replace(".0", "°");
        tv_angle.setText(str_angle);
        last_angle = degree;
        lastchange = System.currentTimeMillis();
    }

    @Override
    public void onListenerStop()
    {
        //null
    }


    @Override
    public void onGpsStatusChanged(int event)
    {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityManager.getAppManager().finishActivity(this);
            return;
        }
        GpsStatus status = locationManager.getGpsStatus(null); //取当前状态
        updateGpsState(event, status);
    }

    private List<GpsSatellite> numSatelliteList = new ArrayList<GpsSatellite>(); // 卫星信

    private void updateGpsState(int event, GpsStatus status)
    {
        if (event == GpsStatus.GPS_EVENT_SATELLITE_STATUS)
        {
            int maxSatellites = status.getMaxSatellites();
            Iterator<GpsSatellite> it = status.getSatellites().iterator();
            numSatelliteList.clear();
            int count = 0;
            int statellite_used = 0;
            while (it.hasNext() && count <= maxSatellites)
            {
                GpsSatellite s = it.next();

                numSatelliteList.add(s);
                count++;
//                if (s.getSnr() != 0)//只有信躁比不为0的时候才算搜到了星
//                {
//                    statellite_used++;
//                }
                if (s.usedInFix())
                {//使用中的卫星数量
                    statellite_used++;
                }

            }
            tv_st_count.setText(count + "");
            if (Currentlocation != null)
                tv_st_accuracy.setText(Utils.getScale(Currentlocation.getAccuracy(), 2) + "m");
//            tv_st_accuracy.setText(statellite_used + "");
        }
    }

    @Event(R.id.btn_quit)
    private void exit(View view)
    {
        ActivityManager.getAppManager().finishActivity(this);
    }


    @Override
    public void onBackPressed()
    {
        ActivityManager.getAppManager().finishActivity(this);
        super.onBackPressed();
    }
}



