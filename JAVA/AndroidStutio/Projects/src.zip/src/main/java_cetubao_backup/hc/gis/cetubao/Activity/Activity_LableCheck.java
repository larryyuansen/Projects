package hc.gis.cetubao.Activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.List;

import HPRTAndroidSDKA300.HPRTPrinterHelper;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.Activity.Bluetooth.Activity_DeviceList;
import hc.gis.cetubao.Bean.Lable;
import hc.gis.cetubao.Bean.MediaAsset;
import hc.gis.cetubao.BuildConfig;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2018/4/12.
 */
@ContentView(R.layout.activity_lable_lablecheck)
public class Activity_LableCheck extends MBaseActivity
{


    Boolean bleConnected = false;
    Lable lable;
    List<Lable> lables;
    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;
    @ViewInject(R.id.tv_delete)
    TextView tv_delete;
    @ViewInject(R.id.title)
    LinearLayout title;
    @ViewInject(R.id.tv_area_name)
    TextView tv_area_name;
    @ViewInject(R.id.tv_zipcode)
    TextView tv_zipcode;
    @ViewInject(R.id.tv_area_bearing)
    TextView tv_area_bearing;
    @ViewInject(R.id.line)
    ImageView line;
    @ViewInject(R.id.layout_topinfo)
    RelativeLayout layout_topinfo;
    @ViewInject(R.id.tv_latlng)
    TextView tv_latlng;
    @ViewInject(R.id.tv_height)
    TextView tv_height;
    @ViewInject(R.id.tv_time)
    TextView tv_time;
    @ViewInject(R.id.tv_collecter)
    TextView tv_collecter;
    @ViewInject(R.id.tv_phone)
    TextView tv_phone;
    @ViewInject(R.id.tv_cygoup)
    TextView tv_cygoup;
    @ViewInject(R.id.tv_cynumber)
    TextView tv_cynumber;
    @ViewInject(R.id.tv_cyrder)
    TextView tv_cyrder;
    @ViewInject(R.id.tv_cyhigh)
    TextView tv_cyhigh;
    @ViewInject(R.id.ll_pic)
    LinearLayout ll_pic;
    @ViewInject(R.id.ll_img)
    LinearLayout ll_img;
    @ViewInject(R.id.tv_rkinfo)
    TextView tv_rkinfo;
    @ViewInject(R.id.tv_tybm)
    TextView tv_tybm;
    @ViewInject(R.id.ll_img2)
    LinearLayout ll_img2;
    @ViewInject(R.id.btn_lable_print)
    Button btn_lable_print;
    @ViewInject(R.id.activity_lable_history)
    RelativeLayout activity_lable_history;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        x.view().inject(this);
        super.onCreate(savedInstanceState);
        try
        {
            lable = (Lable) getIntent().getSerializableExtra("lable");
            if (null == lable)
                finish();
        } catch (Exception e)
        {
            finish();
        }
        // getDate();
        initView();
    }



   /* public void getDate()
    {
        lables = new ArrayList<>();
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("action", APPConfig.ACTION_GETALLCYDDATA);
        params.addQueryStringParameter("cydNumber", cydNumber);
        params.setCacheMaxAge(1000 * 10);//默认使用10秒内的缓存
        x.http().get(params, new Callback.CacheCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                List<Lable> lables_local = DBUtils.getList(Lable.class, WhereBuilder.b("cydNumber", "=", cydNumber).and("hasUpload", "is", false), "createDate", true);
                MResult mresult = JSON.parseObject(result, MResult.class);
                if (null != mresult && TextUtils.isEmpty(mresult.getException()))
                {
                    lables = JSON.parseArray(mresult.getResult(), Lable.class);

                }
                lables.addAll(0, lables_local);
                if (lables.size() == 0)
                {

                    return;
                } else
                    initView();
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {

                return;
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }

            @Override
            public boolean onCache(String result)
            {
                return false;
            }
        });

    }*/

    private void initView()
    {

        tv_area_name.setText(lable.getAreaname());
        tv_zipcode.setText(getString(R.string.postCode) + lable.getPostCode());
        tv_latlng.setText("（" + lable.getLat() + "，" + lable.getLon() + "）");
        tv_height.setText(lable.getHeight() + "米");
        tv_time.setText(lable.getRegDate());
        tv_tybm.setText(lable.getTraceNumber());
        tv_collecter.setText(lable.getRegistrar());
        tv_phone.setText(lable.getTelephone());
        tv_cygoup.setText(lable.getGroupNumber());
        tv_cynumber.setText(lable.getCollectNumber());
        tv_cyrder.setText(lable.getCollectObj());
        tv_cyhigh.setText(lable.getCollectDeep() == null || lable.getCollectDeep().equals("-1") ? "0~20cm" : lable.getCollectDeep() + "cm");
        tv_rkinfo.setText(lable.getRemark());
        List<MediaAsset> assets = DBUtils.getList(MediaAsset.class, WhereBuilder.b("lable_id", "=", lable.getLableID()));
        addPicture(assets);
    }


    public void addPicture(final List<MediaAsset> list_media)
    {
        ll_pic.removeAllViews();
        for (int i = 0; i < list_media.size(); i++)
        {

            //加载图片，并设置tag
            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.MATCH_PARENT, 0);
            lp.setMargins(25, 4, 0, 4);
            imageView.setLayoutParams(lp);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            x.image().bind(imageView, list_media.get(i).getFilepath());
            imageView.setTag(list_media.get(i).getFilepath());
            ll_pic.addView(imageView);
            final int finalIndex = i;
            imageView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    File file = new File(list_media.get(finalIndex).getFilepath());
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    if (Build.VERSION.SDK_INT < 24)
                        intent.setDataAndType(Uri.fromFile(file), "image/*");
                    else
                    {
                        intent.setData(FileProvider.getUriForFile(Activity_LableCheck.this, BuildConfig.APPLICATION_ID + ".provider", file));
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }
                    startActivity(intent);
                }
            });
        }
    }






    @Event(value = {R.id.iv_pic, R.id.btn_lable_print,R.id.ll_exit})
    private void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.iv_pic:
                break;
            case R.id.btn_lable_print:
                Intent intent = new Intent(this,Activity_LablePrint.class);
                intent.putExtra("lable",lable);
                startActivity(intent);
                break;
            case R.id.ll_exit:
                ActivityManager.getAppManager().finishActivity(this);
                break;
        }
    }
}
