package hc.gis.cetubao.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.Adapter.Adapter_Contacts;
import hc.gis.cetubao.Adapter.Decoration.NewsDecoration;
import hc.gis.cetubao.Bean.Contacts;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.R;

@ContentView(R.layout.activity_contacts)
public class Activity_LocalContacts extends AppCompatActivity
{

    @ViewInject(R.id.rv_contacts)
    RecyclerView rvContacts;
    Contacts mContact;
    @ViewInject(R.id.iv_empty)
    ImageView iv_empty;
    @ViewInject(R.id.tv_empty)
    TextView tv_empty;
    @ViewInject(R.id.rl_nocontact)
    RelativeLayout rl_nocontact;
    @ViewInject(R.id.rv_contacts)
    RecyclerView rv_contacts;
    @ViewInject(R.id.et_search)
    EditText et_search;
    Adapter_Contacts adapter_contacts;
    @ViewInject(R.id.rl_search)
    RelativeLayout rl_search;
    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;

    private List<Contacts> mContacts;
    private List<Contacts> mSearchContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initData();
        initListen();
    }

    private void initListen()
    {
        et_search.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                mSearchContacts.clear();
                if (!s.toString().trim().equals(""))
                {
                    for (Contacts contacts : mContacts)
                    {
                        if (contacts.getRealname().contains(s.toString().trim()) || contacts.getTelephone().contains(s.toString().trim()))
                        {
                            mSearchContacts.add(contacts);
                            if (!contacts.getRealname().contains(s.toString().trim()) || contacts.getTelephone().contains(s.toString().trim()))
                            {
                                rl_nocontact.setVisibility(View.GONE);
                                rv_contacts.setVisibility(View.VISIBLE);
                                adapter_contacts.notifyDataSetChanged();
                            }
                        }
                    }

                    if (mSearchContacts.size() == 0)
                    {   tv_empty.setText("无查询联系人");
                        rl_nocontact.setVisibility(View.VISIBLE);
                        rv_contacts.setVisibility(View.GONE);
                    } else
                    {
                        adapter_contacts.notifyDataSetChanged();
                    }
                } else
                {
                    tv_empty.setText("无在线联系人");
                    mSearchContacts.addAll(mContacts);
                    rl_nocontact.setVisibility(View.GONE);
                    rv_contacts.setVisibility(View.VISIBLE);
                    adapter_contacts.notifyDataSetChanged();
                }
            }
        });

    }

    private void initView()
    {
        rvContacts = (RecyclerView) findViewById(R.id.rv_contacts);
        rvContacts.setLayoutManager(new LinearLayoutManager(this));
        adapter_contacts = new Adapter_Contacts(this, mSearchContacts);
        rvContacts.addItemDecoration(new NewsDecoration(1));
        rvContacts.setAdapter(adapter_contacts);
        adapter_contacts.notifyDataSetChanged();

    }

    private void initData()
    {
        mContacts = new ArrayList<>();
        mSearchContacts = new ArrayList<>();
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("action", "GetContacts");
        params.addQueryStringParameter("areaid", DBUtils.getCurrentUser().getAreaID());
        params.addQueryStringParameter("userid", DBUtils.getCurrentUser().getId());
        params.addQueryStringParameter("realname", DBUtils.getCurrentUser().getRealName());
        x.http().get(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    mContacts = JSON.parseArray(mResult.getResult(), Contacts.class);
                    mSearchContacts.addAll(mContacts);
                    if (mContacts.size() == 0)
                    {
                        rl_nocontact.setVisibility(View.VISIBLE);
                        rl_search.setVisibility(View.GONE);
                        rv_contacts.setVisibility(View.GONE);
                    } else
                    {
                        rl_search.setVisibility(View.VISIBLE);
                        rl_nocontact.setVisibility(View.GONE);
                        rv_contacts.setVisibility(View.VISIBLE);
                        initView();
                    }
                }
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.w("服务器错误", ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }

        });
    }

    @Event(R.id.ll_exit)
    private void onClick(View view)
    {
        switch (view.getId())
        {   case R.id.ll_exit:
            ActivityManager.getAppManager().finishActivity(this);
            break;

        }
    }





    /*@Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after)
    {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count)
    {


    }

    @Override
    public void afterTextChanged(Editable s)
    {
        for (Contacts contacts : mContacts)
        {
            if (s.toString().trim().contains(contacts.getRealname()))
            {
                mSearchContacts.add(contacts);
                continue;
            }
            if (s.toString().trim().contains(contacts.getTelephone()))
            {
                mSearchContacts.add(contacts);
                continue;
            }

            Adapter_Contacts contactsAdapter = new Adapter_Contacts(this, mSearchContacts);
            rvContacts.setAdapter(contactsAdapter);
            contactsAdapter.notifyDataSetChanged();
        }
    }*/
}
