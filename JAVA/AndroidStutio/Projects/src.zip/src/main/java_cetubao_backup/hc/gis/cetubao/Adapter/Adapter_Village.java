package hc.gis.cetubao.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;

import java.util.List;

import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Activity.ActivityDialog_CiitySelect;
import hc.gis.cetubao.Bean.Area;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/9.
 */

public class Adapter_Village extends RecyclerView.Adapter<Adapter_Village.Holder_Village>
{
    public final static String TAG = "Adapter_Village";
    Context mContext;
    List<Area> list_area;
    int lastIndex = -1;
    public Area selectArea;
    public String lastSelectID = "";

    public Adapter_Village(Context mContext, List<Area> list_area, String lastSelectID)
    {
        this.lastSelectID = lastSelectID;
        this.mContext = mContext;
        this.list_area = list_area;
    }

    @Override
    public Adapter_Village.Holder_Village onCreateViewHolder(ViewGroup parent, int viewType)
    {
        Adapter_Village.Holder_Village holder_Village = new Adapter_Village.Holder_Village(LayoutInflater.from(mContext).inflate(R.layout.item_village, parent, false));
        holder_Village.setIsRecyclable(false);

        return holder_Village;
    }

    @Override
    public void onBindViewHolder(final Adapter_Village.Holder_Village holder, final int position)
    {
        if (TextUtils.equals(list_area.get(position).getId(), lastSelectID)&&lastIndex==-1)
        {
            list_area.get(position).isSelected = true;
        }
        Log.i(TAG, "绑定" + position + list_area.get(position).getAreaName());
        holder.rb_name.setChecked(list_area.get(position).isSelected);
        holder.rb_name.setText(list_area.get(position).getAreaName());
        if (list_area.get(position).isSelected)
            holder.iv_tick.setVisibility(View.VISIBLE);
        else
            holder.iv_tick.setVisibility(View.GONE);
        holder.rl_item_village.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                holder.rb_name.setChecked(!holder.rb_name.isChecked());
            }

        });
        holder.rb_name.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (isChecked)
                {
                    holder.iv_tick.setVisibility(View.VISIBLE);
                    if (lastIndex == position)
                        return;
                    for (Area area : list_area)
                    {
                        area.isSelected = false;
                    }

                    lastIndex = position;
                    list_area.get(position).isSelected = true;
                    selectArea = list_area.get(position);
                    ((ActivityDialog_CiitySelect) mContext).refreshList(false);

                } else
                {
                    holder.iv_tick.setVisibility(View.INVISIBLE);
                    list_area.get(position).isSelected = isChecked;
                }

            }
        });

    }

    @Override
    public int getItemCount()
    {
        return list_area.size();
    }


    class Holder_Village extends RecyclerView.ViewHolder
    {

        RadioButton rb_name;
        RelativeLayout rl_item_village;
        ImageView iv_tick;

        public Holder_Village(View itemView)
        {
            super(itemView);
            rb_name = itemView.findViewById(R.id.rb_village_name);
            rl_item_village = itemView.findViewById(R.id.rl_item_village);
            iv_tick = itemView.findViewById(R.id.iv_tick);
        }
    }

}
