package hc.gis.cetubao.Activity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.Date;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Fragment.Fragment_Option;
import hc.gis.cetubao.Fragment.Fragment_Point;
import hc.gis.cetubao.Fragment.Fragment_Space;
import hc.gis.cetubao.Fragment.Fragment_Specification;
import hc.gis.cetubao.Fragment.Fragment_main;
import hc.gis.cetubao.Fragment.Fragment_year;
import hc.gis.cetubao.Other.Utils;
import hc.gis.cetubao.R;

import static android.content.pm.PackageManager.PERMISSION_DENIED;
import static hc.gis.cetubao.APP.APPConfig.ACTION_CHANGE_MAINPAGE;

@ContentView(R.layout.activity_main)
public class Activity_Main extends MBaseActivity implements AMapLocationListener
{
    public Fragment mContent = new Fragment();
    public Fragment_Point fragment_point = new Fragment_Point();
    public Fragment_Option fragment_option = new Fragment_Option();
    public Fragment_Specification fragment_specification = new Fragment_Specification();
    public Fragment_Space fragment_space = new Fragment_Space();
    public Fragment_year fragment_year = new Fragment_year();
    public Fragment_main fragment_main = new Fragment_main();
    @ViewInject(R.id.rg_main)
    RadioGroup rg_main;


    private FragmentManager mfragmentManager;

    //声明mlocationClient对象
    public AMapLocationClient mlocationClient;
    //声明mLocationOption对象
    public AMapLocationClientOption mLocationOption = null;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        checkSelfPermission();
      /*Contacts contacts = new Contacts();
        contacts.setUid("131");
        contacts.setName("名字");
        contacts.setPhone("165165166854");
        ArrayList<Contacts> arrayList = new ArrayList<>();
        arrayList.add(contacts);
        Log.i("jsonstring",JSON.toJSONString(arrayList));*/


    }

    protected void initAll()
    {
        startLocation();
        mfragmentManager = getSupportFragmentManager();

        rg_main.setOnCheckedChangeListener(mainPageChanged);
        rg_main.check(R.id.rb_caitu);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter(APPConfig.ACTION_CHANGE_MAINPAGE));

    }


    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        if (null != mlocationClient)
            mlocationClient.onDestroy();
    }

    boolean isFist = true;
    RadioGroup.OnCheckedChangeListener mainPageChanged = new RadioGroup.OnCheckedChangeListener()
    {

        @Override
        public void onCheckedChanged(RadioGroup group, int i)
        {
            switch (i)
            {
                case R.id.rb_caitu:
                    if (isFist)
                    {
                        switchContent(mContent, fragment_year);
                    } else
                    {
                        switchContent(mContent, fragment_point);
                    }


                  /*  switchContent(mContent, fragment_year);

                    if (!isFist){
                        switchContent(mContent,fragment_point);
                    }*/
                    break;
                case R.id.rb_gf:
                    switchContent(mContent, fragment_specification);
                    break;
                case R.id.rb_option:
                    switchContent(mContent, fragment_option);
                    break;
                case R.id.rb_space:
                    switchContent(mContent, fragment_space);
                    break;
            }
        }
    };


    public void switchContent(Fragment from, Fragment to)
    {
        if (mContent != to)
        {
            mContent = to;
            FragmentTransaction fragmentTransaction = mfragmentManager.beginTransaction();
            if (!to.isAdded())
            { // 先判断是否被add过
                fragmentTransaction.hide(from).add(R.id.layout_main, to).commitAllowingStateLoss(); // 隐藏当前的fragment，add下一个到Activity中
            } else
            {
                fragmentTransaction.hide(from).show(to).commitAllowingStateLoss(); // 隐藏当前的fragment，显示下一个
            }
        }
    }


    private void startLocation()
    {
        mlocationClient = new AMapLocationClient(this);
        //初始化定位参数
        mLocationOption = new AMapLocationClientOption();
        //设置定位监听
        mlocationClient.setLocationListener(this);
        //设置定位模式为高精度模式，Battery_Saving为低功耗模式，Device_Sensors是仅设备模式
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        //设置定位间隔,单位毫秒,默认为2000ms
        mLocationOption.setInterval(2000);
        //设置定位参数
        mlocationClient.setLocationOption(mLocationOption);
        // 此方法为每隔固定时间会发起一次定位请求，为了减少电量消耗或网络流量消耗，
        // 注意设置合适的定位时间的间隔（最小间隔支持为1000ms），并且在合适时间调用stopLocation()方法来取消定位请求
        // 在定位结束后，在合适的生命周期调用onDestroy()方法
        // 在单次定位情况下，定位无论成功与否，都无需调用stopLocation()方法移除请求，定位sdk内部会移除
        //启动定位
        mlocationClient.startLocation();

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture)
    {

    }


    @Override
    public void onBackPressed()
    {
        AlertDialog alertDialog = new AlertDialog.Builder(this).setTitle("提示").setMessage("是否退出" + getString(R.string.app_name)).setNegativeButton("否", null).setPositiveButton("是", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                Activity_Main.super.onBackPressed();
                ActivityManager.getAppManager().finishAllActivity();
            }
        }).create();
        alertDialog.show();
    }

    @Override
    public void onLocationChanged(AMapLocation amapLocation)
    {
        if (amapLocation != null)
        {

            if (amapLocation.getErrorCode() == 0)
            {
                MApplication.aMapLocation = amapLocation;
                MApplication.lat = amapLocation.getLatitude();
                MApplication.lng = amapLocation.getLongitude();

                //定位成功回调信息，设置相关消息
                LocalBroadcastManager.getInstance(this).sendBroadcast(new Intent(APPConfig.LOCATION_REFRESHED));
                SimpleDateFormat df = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                {
                    df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                }
                Date date = new Date(amapLocation.getTime());
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                {
                    df.format(date);//定位时间
                }
                fragment_point.setLocationName(amapLocation.getDistrict());
            } else
            {
                //显示错误信息ErrCode是错误码，errInfo是错误信息，详见错误码表。
                Log.e("AmapError", "location Error, ErrCode:"
                        + amapLocation.getErrorCode() + ", errInfo:"
                        + amapLocation.getErrorInfo());
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults)
    {

        if (requestCode == 104)
        {
            if (grantResults.length > 0)
            {
                for (int result : grantResults)
                {
                    if (result == PERMISSION_DENIED)
                    {
                        Toast.makeText(this, "请允许所需权限", Toast.LENGTH_LONG).show();
                        checkSelfPermission();
                        return;
                    }
                }
                initAll();
            } else
            {
                Toast.makeText(this, "请允许所需权限", Toast.LENGTH_LONG).show();
                checkSelfPermission();
                return;
            }
        }

    }


    public void checkSelfPermission()
    {
        List<Integer> permissions_index = Utils.checkPermission(this, APPConfig.permissionNeed);
        String[] permissions_Need = new String[permissions_index.size()];
        int count = 0;
        for (Integer index : permissions_index)
        {
            permissions_Need[count] = APPConfig.permissionNeed[index];
            count++;
        }
        if (permissions_Need.length == 0)
            initAll();
        else
            ActivityCompat.requestPermissions(this, permissions_Need, 104);

    }

    BroadcastReceiver receiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if (intent.getAction().equals(ACTION_CHANGE_MAINPAGE))
            {
                int i = intent.getIntExtra("pageIndex", 0);
                isFist = intent.getBooleanExtra("isFirst",true);
                if (i == 0 && isFist == true)
                {
                    switchContent(mContent, fragment_year);
                } else
                {
                    switchContent(mContent, fragment_point);
                    fragment_point.year = intent.getStringExtra("year");
                }
            }
        }
    };
}
