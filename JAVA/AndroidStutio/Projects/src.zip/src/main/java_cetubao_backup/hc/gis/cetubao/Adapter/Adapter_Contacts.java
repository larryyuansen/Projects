package hc.gis.cetubao.Adapter;


// * Created by gjz on 9/4/16.

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import hc.gis.cetubao.Activity.Activity_LocalContacts;
import hc.gis.cetubao.Bean.Contacts;
import hc.gis.cetubao.R;

public class Adapter_Contacts extends RecyclerView.Adapter<Adapter_Contacts.Holder_Contacts>
{
    private List<Contacts> mContacts;
    private Context mContext;
    public LinearLayout ll_contacts;

    public Adapter_Contacts(Context mContext, List<Contacts> contacts)
    {
        this.mContext = mContext;
        this.mContacts = contacts;
    }

    @Override
    public Holder_Contacts onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_contacts, parent, false);
        Holder_Contacts holder_contacts = new Holder_Contacts(view);
        return holder_contacts;

    }

    @Override
    public void onBindViewHolder(final Holder_Contacts holder, int position)
    {

        Contacts contact = mContacts.get(position);
        Picasso.with(mContext).load(R.drawable.ic_avatar).into(holder.ivAvatar);
        holder.tvName.setText(contact.getRealname());
        holder.tvPhone.setText(contact.getTelephone());

        ll_contacts.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //Intent intent = new Intent(mContext, ActivityDialog_ChooseContacts.class);
                Intent intent = new Intent();
                intent.putExtra("name",holder.tvName.getText());
                intent.putExtra("phone",holder.tvPhone.getText());
                ((Activity_LocalContacts)mContext).setResult(Activity.RESULT_OK,intent);
                ((Activity_LocalContacts)mContext).finish();
            }
        });

    }

    @Override
    public int getItemCount()
    {
        return mContacts.size();
    }

    class Holder_Contacts extends RecyclerView.ViewHolder
    {
        public ImageView ivAvatar;
        public TextView tvName;
        public TextView tvPhone;


        public Holder_Contacts(View itemView)
        {
            super(itemView);
            ivAvatar = (ImageView) itemView.findViewById(R.id.iv_avatar);
            tvName = (TextView) itemView.findViewById(R.id.tv_name);
            tvPhone = (TextView) itemView.findViewById(R.id.tv_phone);
            ll_contacts = itemView.findViewById(R.id.ll_contacts);
        }
    }
}
