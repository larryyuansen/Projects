package hc.gis.cetubao.widget;

import android.content.Context;
import android.widget.PopupWindow;

/**
 * Created by Administrator on 2017/12/7.
 */

public class PopWindow_City
{
    PopupWindow mPopwindow;
    Context mContext;
    public PopWindow_City(Context context,int height,int width)
    {
        mPopwindow= new PopupWindow(mContext);
        mPopwindow.setWidth(width);
        mPopwindow.setHeight(height);
    }

    


}
