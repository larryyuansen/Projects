package hc.gis.cetubao.widget;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import org.xutils.view.annotation.ContentView;

import java.util.Calendar;

public class MyDatepicker
{

    private TextView mDateDisplay;
    private Button mPickDate;

    private int mYear;
    private int mMonth;
    private int mDay;

    TextView textView = null;
    EditText editText = null;

    static final int DATE_DIALOG_ID = 0;
    Context context;

    public MyDatepicker(Context context, View view)
    {
        this.context = context;
        if (view instanceof EditText)
        {
            this.editText = (EditText) view;
        }
        if (view instanceof TextView)
        {
            this.textView = (TextView) view;
        }
    }

    public MyDatepicker(Context context, TextView textView)
    {
        this.context = context;
        this.textView = textView;
    }

    public MyDatepicker(Context context, EditText editText)
    {
        this.context = context;
        this.editText = editText;
    }

    public Dialog getDialog()
    {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        return new DatePickerDialog(context, mDateSetListener, mYear, mMonth, mDay);
    }

    // updates the date we display in the TextView
    public void updateDisplay(TextView textView,StringBuilder builder)
    {
        textView.setText(builder.toString());
    }

    public void updateDisplay(EditText editText,StringBuilder builder)
    {
        editText.setText(builder.toString());
    }

    public DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener()
    {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth)
        {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            StringBuilder builder = new StringBuilder("");
            builder.append(mYear).append("-").append((mMonth + 1) > 9 ? (mMonth + 1) : ("0" + (mMonth+ 1))).append("-").append(mDay > 9 ? mDay : "0" + mDay).append(" ");
            if (textView == null)
            {
                updateDisplay(editText, builder);
            } else
            {
                updateDisplay(textView,builder);
            }

        }
    };

}