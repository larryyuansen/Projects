package hc.gis.cetubao.Other;

/**
 * Created by Administrator on 2017/3/6.
 */

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.View;

import static android.content.Context.SENSOR_SERVICE;

/**
 * 指南针管理类
 */
public class CompassManager implements SensorEventListener
{
    private static CompassManager manager;
    SensorEventListener listener;

    // 定义真机的Sensor管理器
    private static SensorManager mSensorManager;

    //记录rotationMatrix矩阵值
    private float[] r = new float[9];
    //记录通过getOrientation()计算出来的方位横滚俯仰值
    private float[] values = new float[3];
    private float[] gravity = null;
    private float[] geomagnetic = null;


    private static Activity mContext;

    private CompassManager(Activity context)
    {
        this.mContext = context;
    }

    public static CompassManager getInstance(Activity context)
    {
        if (manager == null)
        {
            manager = new CompassManager(context);
            mSensorManager = (SensorManager) mContext.getSystemService(SENSOR_SERVICE);
        }
        return manager;
    }

    OrientationChangeListener oListener;

    public void startCompass(OrientationChangeListener listener)
    {
        oListener = listener;
        oListener.onListenerStart();
        //注册加速度传感器监听
        Sensor acceleSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mSensorManager.registerListener(this, acceleSensor, SensorManager.SENSOR_DELAY_NORMAL);
        //注册磁场传感器监听
        Sensor magSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        mSensorManager.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void stopCompass()
    {
        if (oListener == null || mSensorManager == null)
        {
            Log.e("Compass Error", "OrientationChangeListener or SensorManager has not initialization");
            return;
        }
        oListener.onListenerStop();
        mSensorManager.unregisterListener(this);

    }

    float count = 0f;

    @Override
    public void onSensorChanged(final SensorEvent event)
    {
        mContext.runOnUiThread(new Runnable()
        {
            @Override
            public void run()
            {
                switch (event.sensor.getType())
                {
                    case Sensor.TYPE_ACCELEROMETER: //加速度传感器
                        gravity = event.values;
                        break;
                    case Sensor.TYPE_MAGNETIC_FIELD://磁场传感器
                        geomagnetic = event.values;
                        if (gravity != null && geomagnetic != null)
                        {
                            if (SensorManager.getRotationMatrix(r, null, gravity, geomagnetic))
                            {
                                SensorManager.getOrientation(r, values);
                                float degree = (float) ((360f + values[0] * 180f / Math.PI) % 360);
                                count++;
                                if (count > 10)
                                {
                                    oListener.onAngleChanged(degree);
                                    count = 0;
                                }
                            }
                        }
                        break;
                }
            }
        });
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }


    public interface OrientationChangeListener
    {
        public void onListenerStart();

        /**
         * 角度变化时
         * @param degree 当前角度
         */
        public void onAngleChanged(float degree);
        public void onListenerStop();
    }

}
