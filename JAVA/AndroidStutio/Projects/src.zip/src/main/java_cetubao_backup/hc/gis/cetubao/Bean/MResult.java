package hc.gis.cetubao.Bean;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/12/8.
 */

public class MResult implements Serializable
{
    public MResult()
    {
    }


    public String ResultCode;
    public String Exception;
    String result;


    public String getResultCode()
    {
        return ResultCode;
    }

    public void setResultCode(String resultCode)
    {
        ResultCode = resultCode;
    }

    public String getException()
    {
        return Exception;
    }

    public void setException(String exception)
    {
        Exception = exception;
    }

    public String getResult()
    {
        return result;
    }

    public void setResult(String result)
    {
        this.result = result;
    }


}
