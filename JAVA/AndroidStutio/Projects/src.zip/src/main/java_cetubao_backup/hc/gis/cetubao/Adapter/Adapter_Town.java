package hc.gis.cetubao.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import java.util.List;
import hc.gis.cetubao.Activity.ActivityDialog_CiitySelect;
import hc.gis.cetubao.Bean.Area;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/8.
 */

public class Adapter_Town extends RecyclerView.Adapter<Adapter_Town.Holder_town>
{
    public final static String TAG = "Adapter_Town";
    Context mContext;
    List<Area> list_area;
    int lastIndex = -1;
    public Area selectArea;
    public String lastSelectID = "";

    public Adapter_Town(Context mContext, List<Area> list_area, String lastSelectID)
    {
        this.lastSelectID = lastSelectID;
        this.mContext = mContext;
        this.list_area = list_area;
    }

    @Override
    public Holder_town onCreateViewHolder(ViewGroup parent, int viewType)
    {
        Holder_town holder_town = new Holder_town(LayoutInflater.from(mContext).inflate(R.layout.item_town, parent, false));
        holder_town.setIsRecyclable(false);
        return holder_town;
    }

    @Override
    public void onBindViewHolder(final Holder_town holder, final int position)
    {
        if (TextUtils.equals(list_area.get(position).getId().toString(), lastSelectID.toString()) && lastIndex == -1)
        {
            list_area.get(position).isSelected = true;
            //    ((ActivityDialog_CiitySelect) mContext).getMainCityList(false, list_area.get(position).getAreaID());
        }
        Log.i(TAG, "绑定" + position + list_area.get(position).getAreaName());
        holder.rb_name.setChecked(list_area.get(position).isSelected);
        holder.rb_name.setText(list_area.get(position).getAreaName());
        holder.rl_item_town.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                holder.rb_name.setChecked(!holder.rb_name.isChecked());
            }

        });
        holder.rb_name.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (isChecked)
                {
                    //   Holder_Point.tv_dot.setVisibility(View.VISIBLE);
                    if (lastIndex == position)
                        return;
                    for (Area area : list_area)
                    {
                        area.isSelected = false;
                    }
                    lastIndex = position;
                    list_area.get(position).isSelected = true;
                    selectArea = list_area.get(position);
                    ((ActivityDialog_CiitySelect) mContext).getMainCityList(false, list_area.get(position).getId());
                    ((ActivityDialog_CiitySelect) mContext).refreshList(true);
                } else
                {
                    // Holder_Point.tv_dot.setVisibility(View.INVISIBLE);
                    list_area.get(position).isSelected = isChecked;
                }


            }
        });

    }

    @Override
    public int getItemCount()
    {
        return list_area.size();
    }


    class Holder_town extends RecyclerView.ViewHolder
    {

        // TextView tv_dot;
        RadioButton rb_name;
        RelativeLayout rl_item_town;

        public Holder_town(View itemView)
        {
            super(itemView);
//            tv_dot = itemView.findViewById(R.id.tv_dot);
            rb_name = itemView.findViewById(R.id.rb_town_name);
            rl_item_town = itemView.findViewById(R.id.ll_item_town);
        }
    }
}
