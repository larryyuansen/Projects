package hc.gis.cetubao.Bean;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/12/5.
 */

/**
 * 新闻/规范
 */
public class News implements Serializable
{
    String title;
    String author;
    String date;
    String thumb_url;
    int isTop;

    public News()
    {
    }

    public News(String title, String author, String date, String thumb_url, int isTop)
    {
        this.title = title;
        this.author = author;
        this.date = date;
        this.thumb_url = thumb_url;
        this.isTop = isTop;
    }

    public String getThumb_url()
    {
        return thumb_url;
    }

    public void setThumb_url(String thumb_url)
    {
        this.thumb_url = thumb_url;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getAuthor()
    {
        return author;
    }

    public void setAuthor(String author)
    {
        this.author = author;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public int getTop()
    {
        return isTop;
    }

    public void setTop(int TOP)
    {
        isTop = TOP;
    }


}
