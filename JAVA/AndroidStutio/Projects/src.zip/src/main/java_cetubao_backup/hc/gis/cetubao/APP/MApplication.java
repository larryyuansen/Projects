package hc.gis.cetubao.APP;

import android.app.Application;
import android.content.SharedPreferences;

import com.alibaba.fastjson.JSON;
import com.amap.api.location.AMapLocation;

import org.xutils.x;

import hc.gis.cetubao.Bean.Area;
import hc.gis.cetubao.DB.DBUtils;

/**
 * Created by Administrator on 2017/12/3.
 */

public class MApplication extends Application
{
    public static double lat = 39.977290;
    public static double lng = 116.337000;
    public static AMapLocation aMapLocation;
    public static SharedPreferences mainSp;
    public static Area area_Points;//当前显示的点所在区域

    @Override
    public void onCreate()
    {
        mainSp = getSharedPreferences("mainSp", MODE_PRIVATE);
        super.onCreate();
        x.Ext.init(this);
        DBUtils.initDB();
        initObj();
    }
    private void initObj()
    {
        lat = Double.valueOf(mainSp.getString("lat", "39.977290"));
        lng = Double.valueOf(mainSp.getString("lng", "116.337000"));
//        APPConfig.MainUrl = mainSp.getString("server_addr",APPConfig.MainUrl);
        String area = mainSp.getString("area", "");
        area_Points = JSON.parseObject(area, Area.class);
    }


}
