package hc.gis.cetubao.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.db.DbModelSelector;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.Bean.User;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.MD5Utils;
import hc.gis.cetubao.R;

@ContentView(R.layout.activity_login)
public class Activity_Login extends MBaseActivity
{

    @ViewInject(R.id.iv_tip1)
    ImageView iv_tip1;
    @ViewInject(R.id.et_name)
    EditText et_name;
    @ViewInject(R.id.et_psw)
    EditText et_psw;
    @ViewInject(R.id.cb_autologin)
    CheckBox cb_autologin;
    @ViewInject(R.id.ll_login)
    LinearLayout ll_login;
    @ViewInject(R.id.cb_remb_username)
    CheckBox cb_remb_username;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
        //  initInput();
    }

    private void initView()
    {
        pd = new ProgressDialog(this);
        pd.setTitle("登陆中");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);
        cb_autologin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (isChecked)
                {
                    cb_remb_username.setChecked(true);
                }

            }
        });
        cb_remb_username.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (!isChecked)
                {
                    cb_autologin.setChecked(false);
                }
            }
        });
    }

    private void initInput()
    {
        User user = DBUtils.getCurrentUser();
        if (null != user)
        {
            ll_login.setVisibility(View.GONE);
            cb_autologin.setChecked(true);
            startlogin(user.getName(), user.getPassword());
        } else
        {
            ll_login.setVisibility(View.VISIBLE);
            et_psw.getText().clear();
            et_name.getText().clear();
            String username = MApplication.mainSp.getString("username", "");
            if (!TextUtils.isEmpty(username))
            {
                cb_remb_username.setChecked(true);
                cb_autologin.setChecked(false);
                et_name.setText(username);
            } else
            {
                cb_remb_username.setChecked(false);
                cb_autologin.setChecked(false);
            }
        }
    }

    @Override
    protected void onResume()
    {

        super.onResume();
        initInput();
    }

    @Event(R.id.btn_login)
    private void login(View view)
    {
        if(TextUtils.isEmpty(et_psw.getText().toString().trim())||TextUtils.isEmpty(et_name.getText().toString().trim()))
        {
            Toast.makeText(this,"请完整填写用户名与密码",Toast.LENGTH_LONG).show();
            return;
        }
        String PSW = MD5Utils.makeMD5(et_psw.getText().toString());
        String User = et_name.getText().toString();
        startlogin(User, PSW);

    }

    ProgressDialog pd;

    private void startlogin(String user, final String psw)
    {

        pd.show();
        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("action", APPConfig.ACTION_GETLGOIN);
        params.addBodyParameter("userName", user);
        params.addBodyParameter("passWord", psw);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                pd.dismiss();
                MResult mResult = JSON.parseObject(result, MResult.class);
                if (mResult.getResultCode().equals("200"))
                {
                    if(TextUtils.isEmpty(mResult.getException()))
                    try
                    {
                        User user = JSON.parseObject(mResult.getResult().replace("[", "").replace("]", ""), User.class);
                        user.setPassword(psw);
                        DBUtils.LoginSuccess(user);
                        MApplication.mainSp.edit().putBoolean("autoLogin", cb_autologin.isChecked()).commit();
                        if (cb_remb_username.isChecked())
                        {
                            MApplication.mainSp.edit().putString("username", user.getName()).commit();
                        } else
                        {
                            MApplication.mainSp.edit().remove("username").commit();
                        }
                        startActivity(new Intent(Activity_Login.this, Activity_Main.class));
                    } catch (Exception e)
                    {
                        Toast.makeText(Activity_Login.this, "登录失败", Toast.LENGTH_LONG).show();
                        ll_login.setVisibility(View.VISIBLE);
                    }
                    else
                    {
                        Toast.makeText(Activity_Login.this, mResult.getException(), Toast.LENGTH_LONG).show();
                        ll_login.setVisibility(View.VISIBLE);
                    }

                } else
                {
                    Toast.makeText(Activity_Login.this, "服务器错误", Toast.LENGTH_LONG).show();
                    ll_login.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                pd.dismiss();
                Toast.makeText(Activity_Login.this, "连接失败", Toast.LENGTH_LONG).show();
                cb_autologin.setChecked(false);
                ll_login.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(CancelledException cex)
            {

            }

            @Override
            public void onFinished()
            {

            }
        });
    }

    String TAG = "login";

    @Override
    protected void onRestart()
    {
        super.onRestart();
        Log.i(TAG, "onRestart: ");
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i(TAG, "onRestoreInstanceState: ");
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState, PersistableBundle persistentState)
    {
        super.onRestoreInstanceState(savedInstanceState, persistentState);
        Log.i(TAG, "onRestoreInstanceState: ");
    }

    public void changeIP(View view)
    {
        final  EditText et_addr = new EditText(this);
        et_addr.setText("http://");
      AlertDialog alertDialog =   new AlertDialog.Builder(this).setTitle("修改服务器IP").setPositiveButton("确定", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                APPConfig.MainUrl = et_addr.getText().toString();
//                Toast.makeText(Activity_Login.this,"连接地址修改为"+et_addr.getText().toString(),Toast.LENGTH_LONG).show();
//                MApplication.mainSp.edit().putString("server_addr",APPConfig.MainUrl).commit();
                dialog.dismiss();
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            }
        }).create();
        alertDialog.setView(et_addr);
        alertDialog.show();
    }
}
