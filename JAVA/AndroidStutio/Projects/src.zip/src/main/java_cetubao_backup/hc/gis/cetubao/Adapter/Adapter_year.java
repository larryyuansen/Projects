package hc.gis.cetubao.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.Bean.PointPeriod;
import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2018/4/13.
 */

public class Adapter_year extends RecyclerView.Adapter<Adapter_year.Holder>
{
    Context mContext;
    List<PointPeriod> periods;
    public Adapter_year(Context mContext, List<PointPeriod> periods)
    {
        this.mContext = mContext;
        this.periods = periods;
    }


    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        return new Holder(LayoutInflater.from(mContext).inflate(R.layout.item_year,parent,false));
    }

    @Override
    public void onBindViewHolder(Holder holder, final int position)
    {
        PointPeriod pointPeriod = periods.get(position);
        holder.tv_mission.setText(pointPeriod.getYear()+mContext.getString(R.string.year_mission));
        holder.tv_count.setText(mContext.getString(R.string.lable_count)+pointPeriod.getCoun());
        holder.ll_item.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent();
                intent.putExtra("year",periods.get(position).getYear());
                intent.putExtra("pageIndex",1);
                intent.putExtra("isFirst",false);
                intent.setAction(APPConfig.ACTION_CHANGE_MAINPAGE);
                LocalBroadcastManager.getInstance(mContext).sendBroadcast(intent);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return periods.size();
    }

    class Holder extends RecyclerView.ViewHolder
    {
        TextView tv_count;
        TextView tv_mission;
        LinearLayout ll_item;
        public Holder(View itemView)
        {
            super(itemView);
            ll_item = itemView.findViewById(R.id.ll_item);
            tv_count = itemView.findViewById(R.id.tv_lable_count);
            tv_mission = itemView.findViewById(R.id.tv_year_mission);
        }
    }
}

