package hc.gis.cetubao.Bean;

/**
 * Created by Administrator on 2017/12/13.
 */

import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;

/**
 * 软件使用者
 */
@Table(name = "user")
public class User
{

    @Column(name = "id",isId = true)
    public String id;
    @Column(name = "realName")
    public String realName;
    @Column(name = "areaName")
    public String areaName;
    @Column(name = "userName")
    public String name;
    @Column(name = "areaID")
    public String areaID;
    @Column(name = "psd")
    public String password;
    @Column(name = "userlevel")
    public String userlevel;

    public User() {
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getRealName()
    {
        return realName;
    }

    public void setRealName(String realName)
    {
        this.realName = realName;
    }

    public String getAreaName()
    {
        return areaName;
    }

    public void setAreaName(String areaName)
    {
        this.areaName = areaName;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getAreaID()
    {
        return areaID;
    }

    public void setAreaID(String areaID)
    {
        this.areaID = areaID;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getUserlevel()
    {
        return userlevel;
    }

    public void setUserlevel(String userlevel)
    {
        this.userlevel = userlevel;
    }
}
