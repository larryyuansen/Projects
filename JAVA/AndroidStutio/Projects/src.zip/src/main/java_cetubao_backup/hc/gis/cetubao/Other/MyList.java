package hc.gis.cetubao.Other;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/12/5.
 */

public class MyList<E> extends ArrayList  implements List
{

    public String[] getArray()
    {
        String[] strings = new String[size()];
        for(int i=0;i<size();i++)
        {
            strings[i]=get(i).toString();
        }
        return strings;
    }


    @Override
    public E get(int index)
    {
        if (index >= size())
        {
            if(size()==0)
                return null;
            else
                return (E)super.get(size()-1);
        }
        return (E)super.get(index);
    }
}
