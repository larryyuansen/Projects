package hc.gis.cetubao.Fragment;

import android.graphics.drawable.Drawable;
import android.opengl.ETC1;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.davemorrissey.labs.subscaleview.ImageSource;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

import org.xutils.common.Callback;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import hc.gis.cetubao.R;

/**
 * Created by Administrator on 2017/12/14.
 */
@ContentView(R.layout.fragment_space)
public class Fragment_Space extends Fragment
{
    View mView;
    @ViewInject(R.id.ll_exit)
    LinearLayout ll_exit;
    @ViewInject(R.id.tv_delete)
    TextView tv_delete;
    @ViewInject(R.id.title)
    LinearLayout title;
    @ViewInject(R.id.imageView)
    SubsamplingScaleImageView iv_space;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        mView = x.view().inject(this, inflater, container);
        iv_space.setImage( ImageSource.asset("space.jpg"));
        iv_space.setZoomEnabled(false);
        iv_space.setPanEnabled(false);
        return mView;
    }


    @Event(R.id.ll_exit)
    private void onClick(View view)
    {

    }
}
