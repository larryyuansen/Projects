package hc.gis.cetubao.Activity;

/**
 * Created by Administrator on 2017/12/7.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.test.mock.MockApplication;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;

import org.w3c.dom.Text;
import org.xutils.common.Callback;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.Event;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.APP.ActivityManager;
import hc.gis.cetubao.APP.MApplication;
import hc.gis.cetubao.Adapter.Adapter_Town;
import hc.gis.cetubao.Adapter.Adapter_Village;
import hc.gis.cetubao.Bean.Area;
import hc.gis.cetubao.Bean.MResult;
import hc.gis.cetubao.DB.DBUtils;
import hc.gis.cetubao.Other.MyList;
import hc.gis.cetubao.R;

@ContentView(R.layout.activity_dialog_city_select)
public class ActivityDialog_CiitySelect extends Activity
{

    String parentid;
    List<Area> list_town;
    List<Area> list_vg;
    LinearLayoutManager llmanager;
    @ViewInject(R.id.lv_town)
    RecyclerView rcv_town;
    @ViewInject(R.id.lv_village)
    RecyclerView rcv_village;
    Adapter_Town adapter_town;
    Adapter_Village adapter_village;
    @ViewInject(R.id.tv_cancle)
    TextView tv_cancle;
    @ViewInject(R.id.tv_select)
    Text tv_select;

    public void onCreate(Bundle savedInstanceState)
    {
        x.view().inject(this);
        ActivityManager.getAppManager().addActivity(this);
        initManager();
        parentid = getIntent().getStringExtra("parentid");
        super.onCreate(savedInstanceState);
        intiList();
    }

    private void intiList()
    {
        list_town = new MyList<Area>();
        list_vg = new MyList<Area>();
        llmanager = new LinearLayoutManager(this);
        adapter_town = new Adapter_Town(this, list_town, MApplication.mainSp.getString("lastTownID", "-1"));
        adapter_village = new Adapter_Village(this, list_vg, MApplication.mainSp.getString("lastVillageID", "-1"));
        rcv_town.setLayoutManager(llmanager);
        rcv_town.setAdapter(adapter_town);
        rcv_village.setLayoutManager(new LinearLayoutManager(this));
        rcv_village.setAdapter(adapter_village);
        getMainCityList(true, parentid + "");
        getMainCityList(false, MApplication.mainSp.getString("lastTownID", DBUtils.getCurrentUser().getAreaID()));
    }

    String TAG = "CITY_SELECT";

    public void getMainCityList(final boolean isTown, final String PID)
    {


        RequestParams params = new RequestParams(APPConfig.MainUrl);
        params.addQueryStringParameter("action", APPConfig.ACTION_GETAREA);
        params.addBodyParameter("parentID", PID);
        x.http().post(params, new Callback.CommonCallback<String>()
        {
            @Override
            public void onSuccess(String result)
            {
                if (TextUtils.isEmpty(result))
                {
                    //此时使用缓存数据
                    return;
                }
                MResult mresult = JSON.parseObject(result, MResult.class);
                if (isTown)
                {
                    list_town.clear();
                    list_town.addAll(JSON.parseArray(mresult.getResult(), Area.class));
                    Area area = new Area();
                    area.setAreaName("全部");
                    area.setId(PID);
                    area.setArealevel((Integer.valueOf(list_town.get(0).getArealevel()) - 1) + "");
                    list_town.add(0, area);
                    DBUtils.insertOrUpdateData(list_town);
                } else
                {
                    list_vg.clear();
                    list_vg.addAll(JSON.parseArray(mresult.getResult(), Area.class));
                    Area area = new Area();
                    area.setAreaName("全部");
                    area.setArealevel(list_vg.size() != 0 ? (Integer.valueOf(list_vg.get(0).getArealevel()) - 1) + "" : adapter_town.selectArea.getArealevel());
                    area.setId(PID);
                    Log.i(TAG, "onSuccess: json" + result);
                    list_vg.add(0, area);
                    DBUtils.insertOrUpdateData(list_vg);
                }
                String str = "";
                for (Area area : list_vg)
                    str += area.getAreaName() + "--" + area.getId() + "||";
                Log.i(TAG, "onSuccess: " + PID + "===" + str);
                refreshList(isTown);

            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback)
            {
                Log.i("sync_eror", ex.toString());
            }

            @Override
            public void onCancelled(CancelledException cex)
            {
                Log.i("sync_eror", cex.toString());
            }

            @Override
            public void onFinished()
            {
                Log.i("sync_eror", "finish");
            }


        });
    }


    public void refreshList(final Boolean isTown)
    {
        try
        {


            if (isTown)
            {
                if (rcv_town.getScrollState() == RecyclerView.SCROLL_STATE_IDLE || !rcv_town.isComputingLayout())
                    adapter_town.notifyDataSetChanged();
                else
                    x.task().postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            refreshList(isTown);
                        }
                    }, 500);
            } else
            {
                if (rcv_village.getScrollState() == RecyclerView.SCROLL_STATE_IDLE || !rcv_village.isComputingLayout())
                    adapter_village.notifyDataSetChanged();
                else
                    x.task().postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            refreshList(isTown);
                        }
                    }, 500);
            }
        } catch (Exception e)
        {
            x.task().postDelayed(new Runnable()
            {
                @Override
                public void run()
                {
                    refreshList(isTown);
                }
            }, 500);
        }
    }


    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        setResult(RESULT_CANCELED);
        ActivityManager.getAppManager().finishActivity(this);
        return true;
    }

    @Override
    public void onBackPressed()
    {
        ActivityManager.getAppManager().finishActivity(this);
        super.onBackPressed();
    }

    private void initManager()
    {
        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay();  //为获取屏幕宽、高
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        WindowManager.LayoutParams p = getWindow().getAttributes();  //获取对话框当前的参数值
        p.height = (int) (dm.heightPixels * 1.0);   //高度设置为屏幕的1.0
        p.width = (int) (dm.widthPixels * 1.0);    //宽度设置为屏幕的1.0
        p.alpha = 1.0f;      //设置本身透明度
        p.dimAmount = 0.0f;      //设置黑暗度
        getWindow().setAttributes(p);     //设置生效
        getWindow().setGravity(Gravity.TOP);       //设置靠上对齐
    }

    @Event(value = {R.id.tv_cancle, R.id.tv_select})
    private void click(View view)
    {
        setResult(RESULT_CANCELED);
        if (view.getId() == R.id.tv_select)
        {

            /**
             * 储存上次选中的镇/村编号，下次进入时直接选中
             */
            MApplication.mainSp.edit().putString("lastTownID", adapter_town.selectArea == null ? adapter_town.lastSelectID : adapter_town.selectArea.getId()).commit();
            MApplication.mainSp.edit().putString("lastVillageID", adapter_village.selectArea == null ? adapter_village.lastSelectID : adapter_village.selectArea.getId()).commit();
            for (Area area : list_vg)
            {
                if (area.isSelected)
                    MApplication.area_Points = area;

            }
            if (MApplication.area_Points == null)
            {
                Toast.makeText(this, "请选择一个区域！", Toast.LENGTH_LONG).show();
                return;
            }
            String name = MApplication.area_Points.getAreaName();
            for (Area area : list_town)
            {
                if (area.isSelected)
                {
                    if (!area.getAreaName().equals("全部") && MApplication.area_Points.getAreaName().equals("全部"))
                    {
                        name =area.getAreaName()+"-"+name;
                    }
                }
            }
            Intent intent = new Intent();
            intent.putExtra("townName", name);
            setResult(RESULT_OK, intent);
        }
        ActivityManager.getAppManager().finishActivity(this);
    }
}