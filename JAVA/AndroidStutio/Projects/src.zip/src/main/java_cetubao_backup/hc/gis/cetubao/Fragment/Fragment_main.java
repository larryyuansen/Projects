package hc.gis.cetubao.Fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.amap.api.maps.MapView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import hc.gis.cetubao.APP.APPConfig;
import hc.gis.cetubao.R;

import static hc.gis.cetubao.APP.APPConfig.ACTION_CHANGE_MAINPAGE;

/**
 * Created by Administrator on 2018/4/13.
 */
@ContentView(R.layout.layout_main)
public class Fragment_main extends Fragment
{
    @ViewInject(R.id.rl_content)
    RelativeLayout rl_content;
    FragmentManager manager;
    Fragment_year fragment_year = new Fragment_year();
    Fragment_Point fragment_Point= new Fragment_Point();
    Fragment mContent = new Fragment();
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = x.view().inject(this,inflater,container);
        manager = getActivity().getSupportFragmentManager();
        switchContent(mContent,fragment_year);
        return super.onCreateView(inflater, container, savedInstanceState);
    }


    public void switchContent(Fragment from, Fragment to)
    {
        if (mContent != to)
        {
            mContent = to;
            FragmentTransaction fragmentTransaction = manager.beginTransaction();
            if (!to.isAdded())
            { // 先判断是否被add过
                fragmentTransaction.hide(from).add(R.id.rl_content, to).commit(); // 隐藏当前的fragment，add下一个到Activity中
            } else
            {
                fragmentTransaction.hide(from).show(to).commit(); // 隐藏当前的fragment，显示下一个
            }
        }
    }

}
