package hc.gis.cetubao.Activity;

import android.support.v7.app.AppCompatActivity;

import hc.gis.cetubao.APP.ActivityManager;

/**
 * Created by Administrator on 2018/1/7.
 */

public class MBaseActivity extends AppCompatActivity
{
    public MBaseActivity()
    {
        ActivityManager.getAppManager().addActivity(this);
    }
}
